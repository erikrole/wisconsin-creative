import { PageSkeleton } from "@/components/PageSkeleton";
export default function Loading() { return <PageSkeleton title="Labels" rows={6} />; }
