# QR Print audit and direct-print proof

State: local, uncommitted; approved 21 px physical layout, all six label kinds and four QR scans accepted; stop check physically confirmed; authenticated/migration/release gates remain separate.

## Approved integration slice

The user approved attempt 4 and requested this default layout plus direct USB printing. Add a shared exact-Gotham bitmap renderer for all six label kinds, the verified PT-D610BT transport, media checks, exclusive printing, per-label completion/uncertainty receipts, and primary USB controls. Preserve deliberate printed/applied confirmation and keep CSV as an optional secondary export. Verify renderer/transport failure boundaries, matched fixture UI, and one integrated physical label. No commit, push, or deployment is authorized.

## Scope and contracts

- Baseline: `3cf4a1f302b3a1e1276dbb50394daf7aed86ad20` on `claude/project-thread-k77b71`, PR #590.
- Preserve the unrelated primary checkout. Work only in the attached `qr-print-audit` worktree. No stage, commit, push, deployment, or production mutations requested.
- Owner: `docs/AREA_ITEMS.md`; D-022 keeps unit QR identity derived from family QR plus the unit number and keeps physical printed/applied state separate from downloads.
- User direction: balanced, centered labels every time; Medium Small QR cells; the existing Gotham font. Printer: Brother PT-D610BT, 12 mm white-on-black tape.
- Files: labels cart/helper/sheet/preview, `label-sheet.ts`, `brother-label-csv.ts`, six bundled `.lbx` templates, focused tests and owner docs. The prototype was promoted into a browser-local product path; no backend or production-data mutations were added.

## Implemented locally

- [x] Bound unit picks and number runs; invalid, unknown, retired, pending, or failed unit selections block partial downloads.
- [x] Validate unit response shape and expose retry. Preserve edits/focus when changing templates.
- [x] Bind download state to exact CSV contents; retain the union of downloaded unit batches for deliberate printed-state marking.
- [x] Repair all six native template/database mappings and portable CSV references.
- [x] Center every object frame, separate text/QR, and use Medium Small (`1.2pt`) cells in all four QR templates. Constrain text independently of the QR.
- [x] Reject QR payloads exceeding version 1 / M at this size, checking the complete derived unit identity without shortening it.
- [x] Prevent global reduced-motion transitions from invalidating text-fit measurements.

## Verification and physical evidence

- Final verification passes: 62 focused tests, TypeScript, touched-file ESLint, `npm run build:app`, `npm run verify:docs`, and `git diff --check`. The fixture browser checks pass after the reduced-motion correction; number text measures 13.257 CSS px inside its 13.344 CSS px frame. Existing stale codemaps were regenerated for docs verification. The app build restored its generated Next type reference automatically.
- Baseline regression extraction demonstrated eight failures in the original helper. Browser fixture checks cover exact CSV contents, invalid selection blocking, download freshness, cumulative unit marking, failed-response recovery, edit persistence, fixed-frame fitting, keyboard access, and phone/tablet widths.
- Authenticated feature-route proof is unavailable: PR #590 has no hosted managed preview environment. A normal signed-in production read confirmed the real item `FB FX3 1` and QR `c62a82d7`; it did not modify the item or prove the local route.
- P-touch merged record changes correctly, and native-screen QR decodes succeeded. A physical initial label clipped and failed scanning. A smaller subsequent code was rejected by the user, so it is not the accepted size.
- P-touch rejects a CSV with only one actual record, including an extra terminal blank line. Do not manufacture duplicate item rows as a workaround. A standalone prefilled label file or direct printing still needs an implemented product path.
- Medium Small V1 needs 63 core dots at 180 dpi. Full four-module quiet zones would total 87 dots (about 12.28 mm), exceeding 12 mm tape; physical scanning remains an acceptance gate even when centered. Do not silently shrink the requested code.
- Bluetooth: Chrome discovered the exact paired SPP service, but opening failed twice, then once more after fully closing P-touch. Discovery is not transport/print proof.
- USB: after the user connected a data cable, hardware registry found `04f9:20e1`. Chrome WebUSB claimed interface 0 / IN 1 / OUT 2 directly. A status-only `1b 69 53` request returned a valid 32-byte response with no errors and 12 mm tape, with P-touch closed. This proves direct communication without Brother software.
- Direct USB attempt 1 stopped before label pixels because a zero-length raster-mode drain was treated as an invalid status frame. Attempt 2 sent one complete raster job; the user reported that the font was wrong. That rendering path is rejected.
- Replaced font lookup with glyph outlines read directly from the installed `GothamXNarrow-Bold.otf` through CoreText, requiring the exact `GothamXNarrow-Bold` PostScript name. Attempt 3 used 19 px text and 43/44-dot outer ink margins. The user confirmed the font, centering, unclipped output and production scan: “Everything looks good. Font can be a little bigger.” This approves that exact direct USB label, not every template or the unintegrated product flow.
- Empty USB packets also precede completion. Earlier attempts stopped waiting too early and remain recorded without automatic retries. The revised receiver waits within an elapsed-time deadline, validates complete status frames, and closes on timeout. Mock transport checks pass for many empty packets plus printing/completion notifications and for short-write stop/no retry. Attempt 4 now proves real completion: 123 empty packets preceded a type-1 no-error completion frame, about 6.4 seconds after the raster job was sent; USB then closed.
- Attempt 4 enlarges the same exact Gotham outlines from 19 to 21 px (about 10.5%), with both text and QR core 63 dots high and balanced 42/43-dot ink margins. The QR remains version 1 / M with 3-dot Medium Small cells and the same `c62a82d7` identity. Printer-confirmed completion and the larger physical text are user-approved.

## Remaining gates

- [x] One direct USB raster label physically scans to the production item at Medium Small size, with centered Gotham text and acceptable feed/cut margins (user-approved attempt 3); real printer completion acknowledgement verified on attempt 4.
- [x] User approved the slightly larger 21 px Gotham comparison (attempt 4) and requested it as the default.
- [x] Product integration: shared exact-outline bitmap renderer/preview, PT-D610BT media preflight, cross-tab exclusive jobs, immutable 500-label batches, per-label completion receipts, reload/uncertain recovery without automatic retry, stop after current label, and user-driven applied confirmation.
- [x] USB supplies the single-label path. Optional CSV export documents the P-touch one-record limitation; it does not manufacture duplicate records.
- [ ] Authenticated feature-route proof on its own managed environment.
- [ ] User review and separately authorized shipping.

Proof: [local review](archive/proofs/qr-print-2026-10-22/review.html), matched PNG receipts/source patches, final check logs, device attempt logs, exact glyph outlines, raster round-trip and mock transport results under `tasks/archive/proofs/qr-print-2026-10-22/`. Temporary running prototype: `/private/tmp/qr-print-audit-evidence/direct-print-probe/`. The exact font outline map and its macOS regeneration script are bundled; browser fallback fonts are never used for print output.

## Integrated verification and acceptance

- Shared renderer defaults to exact GothamXNarrow-Bold at 21 px for body/lens three-line labels. Medium Small QR cells stay 3 dots; FB FX3 1 is 194×76 dots, with 42/43-dot outer margins and unchanged `c62a82d7`. The browser differs from the accepted Sharp prototype by eight edge pixels in the text only; QR pixels and placement match. Alpha thresholding uses the same mask for bounds and printing. Independent review measured all six representative label kinds centered to at most one rounding dot.
- USB is enabled by Permissions Policy only for `/labels` and the development fixture (the fixture exception is absent from the production build manifest). Desktop Chrome/Edge, exact PT-D610BT, 12 mm laminated white-on-black tape are the bounded support scope.
- The first integrated attempt stopped at readiness with no raster setup. The user confirmed no output and explicitly authorized clearing it and retrying after automatic approval review required physical-output confirmation. Re-selecting the already-active alternate was removed to preserve endpoint state. The next integrated job completed 1/1, and the user confirmed: “Yes, it looks right and scans.” This closes the one-label integrated physical gate.
- Final source verification: 76 focused tests (including 14 transport cases), TypeScript, touched-file ESLint, `npm run build:app`, docs verification and diff whitespace checks pass. The local runtime is Node 24.22; CI's Node 22 environment is not claimed verified. Existing unrelated build warnings remain.
- Browser fixture verifies exact raster QR decode, complete-batch render preflight, one completed / one unknown / one unsent label, cross-tab delayed-chooser blocking, persisted receipts after reload, explicit applied marking for completed unit 37 only, safe stop, existing CSV freshness/cumulative export behavior, failed-response retry, edit persistence, keyboard access and 1440/768/390 CSS-pixel layouts. No page errors. Mocks do not establish native transfer cancellation or every physical failure mode.
- No stage, commit, push, deployment or production printed-state mutation. The feature route's authenticated preview gate remains open. Other template/media physical acceptance remains outside the one validated body-label proof.

Current proof: [USB integration review](archive/proofs/qr-print-2026-10-22/usb-integration/review.html), matched captures and source receipts, source snapshot, quality/build logs, browser harnesses, production policy manifest, and hardware completion screenshot/state.

## Requested full-page refinement

The user requested bigger/better previews and refinement of the whole page after approving the integrated physical label. Preserve the accepted renderer and USB lifecycle. Increase previews to a crisp 1:1 printer-dot view, add an enlarged inspection dialog, center each preview in a consistent tray, replace native-template filenames with product names in normal controls, improve picker/sheet/printer hierarchy, and refine custom-label forms. Verify matched fixture captures, dialog/keyboard behavior, wide/tablet/phone layouts, USB/CSV regressions, quality gates and owner docs. No shipping action is authorized.

Refinement proof: normal previews are exactly 194×76 CSS px for the accepted sample, up from 112.31×44; the inspection dialog is 388×152 at desktop width and preserves aspect when constrained. Bitmap PNG bytes match the pre-refinement source exactly. Preview ink is centered in its tray. Browser checks cover accessible dialog naming, Escape/focus return, all three custom generators, valid selection state, four viewport widths and the 1024 px app-sidebar width constraint. USB and CSV regression browser checks still pass; 76 focused tests and TypeScript pass. Final build and review are recorded in the visual-refinement proof folder.

- [x] Requested full-page refinement complete locally; final app build, 76 focused tests, TypeScript and lint pass. Matched source-bound review: [larger previews and page refinement](archive/proofs/qr-print-2026-10-22/ui-refinement/review.html). Print pixels remain unchanged.

The combined review and refined helper are opened locally. Dark appearance was checked in the user’s actual Chrome window. Final docs/codemaps and whitespace checks pass. The isolated baseline review server is stopped; the current database-free helper remains on loopback port 3145 for review.

## Print journal, recovery and operator history (authorized follow-up)

1. Add a strict print-job state machine and durable, authenticated operator history; immutable per-copy identities, timestamps, active index, optimistic concurrency and idempotent log writes. Stop output on persistence failure and preserve acknowledged progress.
2. Recover unreadable/legacy local journals explicitly, keep the shared-browser unresolved-job guard across accounts, reconcile uncertain output, and continue only remaining copies with linked history.
3. Use one template-ordered prepared queue for USB/CSV/display, visible whole-sheet renderer preflight, responsive preparation, and exact generated-QR checks.
4. Scope drafts to the account, surface persistence/conflict failures, and add undo for remove/clear. Separate device, storage, domain and presentation responsibilities.
5. Verify regression tests, browser recovery/keyboard/layout, source-bound visual evidence, type/lint/build/docs and independent recovery review. Prepare a bounded all-template and device-fault acceptance checklist; physical outcomes require actual observation. Keep migration/live/authenticated/release boundaries explicit.

Ownership: this worktree only; primary checkout and pre-existing edits preserved. No commit, push, deployment or production mutation is included.


### Recovery implementation and verification state

- Implemented a validated command state machine, versioned local outbox/CAS fencing, explicit in-flight copy identity, one-checkpoint final completion, no device replay on log retry, immutable per-copy snapshots and exact remaining-only child batches.
- Added migration 0198 and authenticated print-history endpoints. Operator identity comes from the session; device acknowledgement, explicit physical review and applied state remain distinct. Server checkpoints and audit events are atomic; create/body-bound checkpoint retries and the shared-browser unique reservation are covered by real disposable PostgreSQL tests. No migration was applied to an application database.
- Independent review found and fixed stale begin authorization, passive-tab outbox overwrite, foreign-operator pending-log recovery, account history leakage, corrupt raw-record disclosure, and reviewed-outbox recovery outside the first history page.
- Canonical template ordering drives the sheet, CSV and USB; full bitmap/font/text/QR preflight is responsive and retryable. Approved preview PNG bytes remain identical. Draft save failures/conflicts are visible, drafts belong to the account, and Undo preserves later edits/selections.
- Focused tests, real PostgreSQL cases, source checks and browser evidence are recorded in `archive/proofs/qr-print-2026-10-22/recovery/`. Final totals/build/docs status are recorded with the proof.
- Hardware: the fixture sent six layouts and received six no-error acknowledgements. The user accepted all layouts and four production scans, then clarified that six good labels plus six blank offcuts came out. This closes the six-kind layout/scan gate. The existing transport pre-cuts the blank leader and finalizes each label separately: one leader offcut per label is now a known tape-cost limitation. Chained printing is not enabled; its final feed and stop/completion semantics need a separate physical test. The controlled stop then recorded two completed copies and four unsent; the user confirmed exactly two printed labels and two blank offcuts. No automatic continuation was sent.
- Disconnect/reload proof: after the user unplugged USB, Continue became disabled. Reload restored exactly two completed/four unsent; nothing resumed. The stopped test batch was explicitly finished without its remaining labels and the pre-test sheet restored. Both test batches remain in local fixture history. This is a between-job disconnect check, not a mid-transfer cable-pull test.
- Open: authenticated branch-owned feature-route proof, application migration/release. Mid-transfer disconnect and tape-out remain outside physical acceptance. No stage, commit, push, merge or deployment.


Final local gates: 92 focused tests plus 9 real disposable PostgreSQL service/migration cases (101 total); app build, TypeScript, touched-file ESLint, Prisma validation/prefix checks, codemaps/docs and whitespace checks pass. The Prisma schema diff contains only the new job table, indexes and user relation; the forward SQL adds checked revision/browser invariants. The real database cases exercise concurrent reservation, exact retries, audit rollback, student/foreign-account boundaries, exact child lineage, atomic failed-child rollback, explicit staff physical reconciliation, and retained operator attribution. Browser evidence covers partial/unknown/reload/remaining-only recovery, all six kinds with simulated USB, failed logging, safe stop, changed media, corrupt journals, failed batch creation, stale reviewed outbox, draft conflict/undo and viewport widths. Independent review reports no remaining P1/P2 in reviewed source. Node 24.22 was used locally; the configured CI Node 22 gate remains separate.

`preview:status` confirms this branch has no managed preview. No authenticated feature-route or live application migration proof is claimed. The six-label physical job is accepted after the user clarified that all six printed labels were present alongside six blank leader offcuts. A second job stopped at two acknowledged labels and preserved four unsent, matching the user's physical count. The cable was then unplugged for a no-output recovery check. No tape-out or mid-transfer cable-pull test is claimed.

Current follow-up proof: [journal and safe recovery review](archive/proofs/qr-print-2026-10-22/recovery/review.html), retained source snapshots, matching capture receipts, 101-test logs, build/source checks, and actual USB completion/stop/disconnect UI evidence. The original combined UI review is preserved as `review-through-ui-refinement.html`.
