import { afterEach, describe, expect, it, vi } from "vitest";
import { BrotherUsbPrinter, type BrotherUsbDevice } from "@/lib/brother-usb";
import type { LabelBitmap } from "@/lib/brother-label-render";

const status = (type = 0, patch: Record<number, number> = {}) => {
  const bytes = new Uint8Array(32);
  bytes.set([0x80, 0x20, 0x42]);
  bytes[10] = 12; bytes[11] = 1; bytes[18] = type; bytes[24] = 8; bytes[25] = 1;
  Object.entries(patch).forEach(([key, value]) => { bytes[Number(key)] = value; });
  return bytes;
};
class Usb implements BrotherUsbDevice {
  vendorId = 0x04f9; productId = 0x20e1; opened = false;
  configuration = { interfaces: [{ interfaceNumber: 0, alternates: [{ alternateSetting: 0, interfaceClass: 7, endpoints: [{ direction: "in" as const, endpointNumber: 1, type: "bulk" }, { direction: "out" as const, endpointNumber: 2, type: "bulk" }] }] }] };
  writes: number[][] = [];
  incoming: Uint8Array[] = [];
  ready = status();
  completion = [status(6, { 19: 1 }), status(1)];
  drain = new Uint8Array();
  shortRaster = false;
  hangRaster = false;
  closes = 0;
  async open() { this.opened = true; }
  async close() { this.opened = false; this.closes++; }
  async selectConfiguration() {}
  async claimInterface() {}
  async selectAlternateInterface() {}
  async clearHalt() {}
  async transferOut(_endpoint: number, data: Uint8Array) {
    const bytes = Array.from(data); this.writes.push(bytes);
    if (bytes.join() === "27,105,83") this.incoming.push(this.ready);
    if (bytes.join() === "27,105,97,1") this.incoming.push(this.drain);
    if (bytes.join() === "26") this.incoming.push(...this.completion);
    if (data[0] === 0x47 && this.hangRaster) return new Promise<{ status: string; bytesWritten: number }>(() => {});
    return { status: "ok", bytesWritten: this.shortRaster && data[0] === 0x47 ? 2 : data.length };
  }
  async transferIn() {
    const bytes = this.incoming.shift();
    if (!bytes) return new Promise<{ status: string; data?: DataView }>(() => {});
    return { status: "ok", data: new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength) };
  }
}
const image = (): LabelBitmap => {
  const ink = new Uint8Array(3 * 76); ink[0] = 1; ink[75 * 3 + 2] = 1;
  return { width: 3, height: 76, ink, preview: "" };
};
afterEach(() => { vi.useRealTimers(); });
describe("PT-D610BT USB job boundary", () => {
  it("prints the bitmap in printer-pin order and waits through empty packets/phase notifications for completion", async () => {
    vi.useFakeTimers();
    const usb = new Usb();
    usb.completion = [...Array.from({ length: 123 }, () => new Uint8Array()), status(6, { 19: 1 }), status(1).slice(0, 11), status(1).slice(11)];
    const printer = new BrotherUsbPrinter(usb); await printer.open();
    const started = vi.fn(); let completed = false;
    const job = printer.print(image(), started).then(() => { completed = true; });
    await vi.advanceTimersByTimeAsync(1000); expect(completed).toBe(false);
    await vi.runAllTimersAsync(); await job;
    expect(started).toHaveBeenCalledOnce(); expect(completed).toBe(true);
    const columns = usb.writes.filter((bytes) => bytes[0] === 0x47);
    expect(columns).toHaveLength(3);
    expect(columns[0]!.filter(Boolean)).toEqual([0x47, 16, 32]);
    expect(columns[0]![6]).toBe(32); expect(columns[2]![15]).toBe(4);
    expect(usb.writes.filter((bytes) => bytes.join() === "26")).toHaveLength(1);
    await printer.close(); expect(usb.opened).toBe(false);
  });
  it("preserves an already-selected interface instead of resetting its USB endpoints", async () => {
    const usb = new Usb();
    Object.assign(usb.configuration.interfaces[0]!, { alternate: usb.configuration.interfaces[0]!.alternates[0] });
    usb.selectAlternateInterface = async () => { throw new Error("Active endpoint state was reset"); };
    const printer = new BrotherUsbPrinter(usb); await printer.open();
    await printer.print(image(), vi.fn());
    expect(usb.writes.filter((bytes) => bytes.join() === "26")).toHaveLength(1);
    await printer.close();
  });
  it.each<Record<number, number>>([{ 10: 18 }, { 11: 0 }, { 24: 1 }, { 25: 8 }, { 8: 1 }, { 9: 1 }, { 19: 1 }])("blocks setup and pixels for wrong media, printer errors or a busy printer: %j", async (patch) => {
    const usb = new Usb(); usb.ready = status(0, patch);
    const printer = new BrotherUsbPrinter(usb); await printer.open(); const started = vi.fn();
    await expect(printer.print(image(), started)).rejects.toThrow();
    expect(started).not.toHaveBeenCalled(); expect(usb.writes).toEqual([[27, 105, 83]]);
    await printer.close();
  });
  it("does not treat an old completion as readiness, and validates a mode-drain status before the fresh query", async () => {
    const usb = new Usb(); usb.incoming.push(status(1)); usb.drain = status(0, { 9: 1 });
    const printer = new BrotherUsbPrinter(usb); await printer.open();
    await expect(printer.print(image(), vi.fn())).rejects.toThrow("printer reported an error");
    expect(usb.writes.filter((bytes) => bytes[0] === 0x47)).toHaveLength(0);
    expect(usb.writes.filter((bytes) => bytes.join() === "27,105,83")).toHaveLength(2);
    await printer.close();
  });
  it("checks fresh readiness for each consecutive label on the same connection", async () => {
    const usb = new Usb();
    usb.completion = [status(1), status(6)];
    const printer = new BrotherUsbPrinter(usb); await printer.open();
    await printer.print(image(), vi.fn());
    usb.ready = status(0, { 8: 1 });
    await expect(printer.print(image(), vi.fn())).rejects.toThrow("printer reported an error");
    expect(usb.writes.filter((bytes) => bytes.join() === "26")).toHaveLength(1);
    expect(usb.writes.filter((bytes) => bytes[0] === 0x47)).toHaveLength(3);
    await printer.close();
  });
  it("rejects an error received in the same transfer as completion", async () => {
    const usb = new Usb(); usb.completion = [new Uint8Array([...status(1), ...status(2, { 8: 1 })])];
    const printer = new BrotherUsbPrinter(usb); await printer.open();
    await expect(printer.print(image(), vi.fn())).rejects.toThrow("printer reported an error");
    await printer.close();
  });
  it("never retries a short write or finalizes a partial raster", async () => {
    const usb = new Usb(); usb.shortRaster = true;
    const printer = new BrotherUsbPrinter(usb); await printer.open();
    await expect(printer.print(image(), vi.fn())).rejects.toThrow("full label");
    expect(usb.writes.filter((bytes) => bytes[0] === 0x47)).toHaveLength(1);
    expect(usb.writes.some((bytes) => bytes.join() === "26")).toBe(false);
    await printer.close();
  });
  it("returns an uncertain transfer timeout without sending another command, allowing close to abort the pending transfer", async () => {
    vi.useFakeTimers();
    const usb = new Usb(); usb.hangRaster = true;
    const printer = new BrotherUsbPrinter(usb); await printer.open();
    const result = printer.print(image(), vi.fn()).catch((error: unknown) => error);
    await vi.runAllTimersAsync(); expect(await result).toBeInstanceOf(Error);
    expect(usb.writes.at(-1)![0]).toBe(0x47);
    await printer.close(); expect(usb.closes).toBe(1);
  });
});
