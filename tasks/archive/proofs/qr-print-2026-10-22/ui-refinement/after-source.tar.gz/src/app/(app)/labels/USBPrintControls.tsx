"use client";

import { useEffect, useRef, useState } from "react";
import { Check, CircleAlert, Loader2, Printer, Usb } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { LabelRow } from "@/lib/brother-label-csv";
import { renderBrotherLabel, type LabelBitmap } from "@/lib/brother-label-render";
import { BROTHER_USB_LOCK, BrotherUsbPrinter, brotherUsbAccess, chooseBrotherUsb, type BrotherUsbDevice } from "@/lib/brother-usb";

export type UsbPrintLabel = { row: LabelRow; unit?: { skuId: string; number: number } };
type Receipt = {
  version: 1; id: string; labels: UsbPrintLabel[]; completed: number;
  state: "printing" | "completed" | "stopped" | "uncertain" | "failed"; error?: string;
};
const RECEIPT_KEY = "wc-qr-usb-last-batch-v1";
function readReceipt(): Receipt | null {
  try {
    const value = JSON.parse(localStorage.getItem(RECEIPT_KEY) ?? "null") as Receipt | null;
    if (!value || value.version !== 1 || !Array.isArray(value.labels) || value.labels.length > 500 || !Number.isInteger(value.completed) || value.completed < 0 || value.completed > value.labels.length || !["printing", "completed", "stopped", "uncertain", "failed"].includes(value.state)) return null;
    if (!value.labels.every((label) => label.row && typeof label.row.qrCodeValue === "string" && (!label.unit || typeof label.unit.skuId === "string" && Number.isSafeInteger(label.unit.number) && label.unit.number > 0) && [label.row.dept, label.row.model, label.row.number].every((part) => typeof part === "string"))) return null;
    return value;
  } catch { return null; }
}
function labelName(label: UsbPrintLabel) {
  return [label.row.dept, label.row.model, label.row.number].filter(Boolean).join(" ") || label.row.qrCodeValue;
}
async function exclusive(action: () => Promise<void>) {
  await navigator.locks.request(BROTHER_USB_LOCK, { ifAvailable: true }, async (lock) => {
    if (!lock) throw new Error("Another tab is using the printer. Finish that batch first.");
    await action();
  });
}

export function USBPrintControls({ labels, total, blocked, onCompleted }: {
  labels: UsbPrintLabel[]; total: number; blocked: boolean; onCompleted: (label: UsbPrintLabel) => void;
}) {
  const [supported, setSupported] = useState(false);
  const [device, setDevice] = useState<BrotherUsbDevice>();
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [receipt, setReceipt] = useState<Receipt | null>(null);
  const guard = useRef(false), stop = useRef(false);
  const completedCallback = useRef(onCompleted);
  completedCallback.current = onCompleted;
  useEffect(() => {
    setSupported(Boolean(brotherUsbAccess() && navigator.locks && window.isSecureContext));
    const previous = readReceipt();
    if (previous) {
      setReceipt(previous.state === "printing" ? { ...previous, state: "uncertain" } : previous);
      previous.labels.slice(0, previous.completed).forEach((label) => completedCallback.current(label));
    }
    const storage = (event: StorageEvent) => {
      if (event.key !== RECEIPT_KEY || guard.current) return;
      const latest = readReceipt();
      setReceipt(latest?.state === "printing" ? { ...latest, state: "uncertain" } : latest);
      latest?.labels.slice(0, latest.completed).forEach((label) => completedCallback.current(label));
    };
    window.addEventListener("storage", storage);
    const usb = brotherUsbAccess();
    const disconnect = () => { setDevice(undefined); };
    const unload = (event: BeforeUnloadEvent) => { if (guard.current) { event.preventDefault(); event.returnValue = ""; } };
    usb?.addEventListener("disconnect", disconnect);
    window.addEventListener("beforeunload", unload);
    return () => { stop.current = true; window.removeEventListener("storage", storage); usb?.removeEventListener("disconnect", disconnect); window.removeEventListener("beforeunload", unload); };
  }, []);

  const connect = async () => {
    if (guard.current) return;
    guard.current = true; setBusy(true); setMessage("");
    try {
      // Open the browser chooser directly in the user gesture, before waiting for a lock.
      const chosen = await chooseBrotherUsb();
      await exclusive(async () => {
        const latest = readReceipt();
        if (latest && ["printing", "uncertain"].includes(latest.state)) {
          setReceipt({ ...latest, state: "uncertain" });
          throw new Error("Check the previous physical label and review its batch before reconnecting.");
        }
        const printer = new BrotherUsbPrinter(chosen);
        try { await printer.open(); await printer.checkReady(); }
        finally { await printer.close(); }
      });
      setDevice(chosen); setMessage("Ready · 12 mm white-on-black tape");
    } catch (error) {
      setDevice(undefined);
      setMessage(error instanceof DOMException && error.name === "NotFoundError" ? "No printer selected. Connect when ready." : error instanceof Error ? error.message : "Could not connect to the printer.");
    } finally { guard.current = false; setBusy(false); }
  };

  const print = async () => {
    if (guard.current || !device || blocked || receipt || !labels.length || labels.length > 500) return;
    guard.current = true; stop.current = false; setBusy(true); setMessage("Preparing labels…");
    // Freeze text, QR identities, copies and unit ownership before the first await.
    const snapshot = structuredClone(labels);
    const batch: Receipt = { version: 1, id: crypto.randomUUID(), labels: snapshot, completed: 0, state: "printing" };
    let started = false;
    const save = () => { localStorage.setItem(RECEIPT_KEY, JSON.stringify(batch)); setReceipt({ ...batch }); };
    try {
      // Render the entire batch before any printer writes, so an invalid last row cannot partially print.
      const bitmaps: LabelBitmap[] = [];
      for (const label of snapshot) {
        if (stop.current) break;
        bitmaps.push(await renderBrotherLabel(label.row));
      }
      await exclusive(async () => {
        const previous = readReceipt();
        if (previous) { setReceipt(previous.state === "printing" ? { ...previous, state: "uncertain" } : previous); throw new Error("An earlier batch needs review. Check its labels before printing again."); }
        if (stop.current) { batch.state = "stopped"; save(); return; }
        // A failed storage write stops before print setup; refresh can never silently resume a batch.
        save();
        const printer = new BrotherUsbPrinter(device);
        try {
          await printer.open();
          for (let i = 0; i < snapshot.length && !stop.current; i++) {
            started = false;
            setMessage(`Printing ${i + 1} of ${snapshot.length} · ${labelName(snapshot[i]!)}`);
            await printer.print(bitmaps[i]!, () => { save(); started = true; });
            batch.completed = i + 1; started = false;
            save(); completedCallback.current(snapshot[i]!);
          }
          batch.state = batch.completed === snapshot.length ? "completed" : "stopped"; save();
        } catch (error) {
          batch.state = started ? "uncertain" : "failed";
          batch.error = error instanceof Error ? error.message : "Printing stopped.";
          save();
          throw error;
        } finally { await printer.close(); }
      });
      setMessage("");
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Printing stopped.");
    } finally { guard.current = false; setBusy(false); }
  };

  const incomplete = receipt && receipt.completed < receipt.labels.length;
  return (
    <div className="flex flex-col gap-3 rounded-lg border border-border bg-background p-3">
      <div className="flex items-center justify-between gap-2">
        <div className="min-w-0 text-xs">
          <div className="font-bold text-foreground">Brother PT-D610BT</div>
          <div className="mt-0.5 text-muted-foreground">12 mm white-on-black tape</div>
        </div>
        <Button variant="outline" size="sm" className="h-10 shrink-0" disabled={!supported || busy || Boolean(receipt && ["printing", "uncertain"].includes(receipt.state))} onClick={() => void connect()}>
          <Usb className="size-4" />{device ? "Reconnect" : "Connect USB"}
        </Button>
      </div>
      {!supported && <p className="text-xs text-muted-foreground">Open this helper in Chrome or Edge on a computer for USB printing.</p>}
      <p className="text-xs text-muted-foreground">Gotham XNarrow Bold · Medium Small QR</p>
      <Button className="h-11 w-full font-bold" disabled={!supported || !device || busy || blocked || Boolean(receipt) || !labels.length || labels.length > 500} onClick={() => void print()}>
        {busy ? <Loader2 className="size-4 animate-spin" /> : <Printer className="size-4" />}
        {busy ? "Printer in use…" : `Print ${total.toLocaleString()} ${total === 1 ? "label" : "labels"}`}
      </Button>
      {labels.length > 500 && <p role="status" className="text-xs text-destructive">Print up to 500 labels in one USB batch. Reduce the sheet first.</p>}
      {busy && <Button variant="outline" className="h-10" onClick={() => { stop.current = true; setMessage("Stopping after the current label finishes…"); }}>Stop after current label</Button>}
      {message && <p role="status" className="text-xs text-muted-foreground">{message}</p>}
      {receipt && (
        <div role="status" className="rounded-lg border border-border bg-background p-3 text-xs">
          <div className="flex items-center gap-1.5 font-bold">{receipt.state === "uncertain" || receipt.state === "failed" ? <CircleAlert className="size-4 text-destructive" /> : <Check className="size-4 text-emerald-600 dark:text-emerald-400" />}{receipt.completed} of {receipt.labels.length} labels completed</div>
          {receipt.state === "uncertain" || receipt.state === "printing" && !busy ? (
            <p className="mt-1 text-destructive">Completion of label {receipt.completed + 1} is unknown. Check the physical label before printing again. Nothing will retry automatically.</p>
          ) : !busy && incomplete ? <p className="mt-1">The batch stopped. Remaining labels were not sent.</p> : !busy ? <p className="mt-1">Check the labels and scan a QR before applying them.</p> : null}
          {receipt.error && <p className="mt-1 text-destructive">{receipt.error}</p>}
          {!busy && <>
            <details className="mt-2"><summary className="cursor-pointer py-1">Review this batch</summary><ol className="mt-1 max-h-40 overflow-auto pl-4 list-decimal">{receipt.labels.map((label, i) => <li key={i}>{labelName(label)} · {i < receipt.completed ? "completed" : i === receipt.completed && ["uncertain", "printing"].includes(receipt.state) ? "unknown" : "not sent"}</li>)}</ol></details>
            {incomplete && <p className="mt-1">Remove completed labels from the sheet before starting a new batch.</p>}
            <Button variant="outline" className="mt-2 h-10 w-full" onClick={() => {
              void exclusive(async () => { const latest = readReceipt(); if (latest && latest.id !== receipt.id) { setReceipt(latest); throw new Error("The printer batch changed in another tab. Review that batch first."); } localStorage.removeItem(RECEIPT_KEY); setReceipt(null); setMessage("Batch reviewed. The next print uses the current sheet."); }).catch((error: unknown) => { setMessage(error instanceof Error ? error.message : "Could not clear the batch receipt."); });
            }}>I checked the labels · New batch</Button>
          </>}
        </div>
      )}
    </div>
  );
}
