import UIKit
import UserNotifications

/// Delivered alerts mirror unread inbox rows. Each push carries its row's
/// `notificationId`, so reading the row in the app clears its alert.
enum DeliveredNotifications {
    /// Removes delivered alerts for these inbox rows; `nil` clears them all.
    static func clear(inboxRowIDs ids: Set<String>?) async {
        let center = UNUserNotificationCenter.current()
        guard let ids else {
            center.removeAllDeliveredNotifications()
            return
        }
        let delivered = await center.deliveredNotifications()
        let identifiers = delivered
            .filter { ($0.request.content.userInfo["notificationId"] as? String).map(ids.contains) ?? false }
            .map(\.request.identifier)
        guard !identifiers.isEmpty else { return }
        center.removeDeliveredNotifications(withIdentifiers: identifiers)
    }
}

enum PushAuthorization {
    /// `.providesAppNotificationSettings` adds a link to our own preferences
    /// on the app's page in iOS Settings.
    static let options: UNAuthorizationOptions = [.alert, .badge, .sound, .providesAppNotificationSettings]
}

enum PushTokenStorage {
    static let currentTokenKey = "WisconsinCurrentAPNsToken"
    private static let registrationAllowedKey = "WisconsinAPNsRegistrationAllowed"

    static var registrationAllowed: Bool {
        get { UserDefaults.standard.bool(forKey: registrationAllowedKey) }
        set { UserDefaults.standard.set(newValue, forKey: registrationAllowedKey) }
    }
}

@MainActor
class AppDelegate: NSObject, UIApplicationDelegate {
    func application(
        _ application: UIApplication,
        didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]? = nil
    ) -> Bool {
        UNUserNotificationCenter.current().delegate = self
        GearTrackerNotificationCategory.register()
        return true
    }

    /// SwiftUI's `WindowGroup` is scene based, so quick actions are routed by
    /// `GearTrackerSceneDelegate` for both warm and cold launches rather than
    /// through the UIApplicationDelegate-only callback.
    func application(
        _ application: UIApplication,
        configurationForConnecting connectingSceneSession: UISceneSession,
        options: UIScene.ConnectionOptions
    ) -> UISceneConfiguration {
        let configuration = UISceneConfiguration(name: nil, sessionRole: connectingSceneSession.role)
        configuration.delegateClass = GearTrackerSceneDelegate.self
        return configuration
    }

    func application(_ application: UIApplication, supportedInterfaceOrientationsFor window: UIWindow?) -> UIInterfaceOrientationMask {
        return .all
    }

    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        guard PushTokenStorage.registrationAllowed else { return }
        let hex = deviceToken.map { String(format: "%02x", $0) }.joined()
        UserDefaults.standard.set(hex, forKey: PushTokenStorage.currentTokenKey)
        Task { @MainActor in
            let mutation = pushCredentialMutations.enqueue {
                guard PushTokenStorage.registrationAllowed else { return }
                do {
                    try await APIClient.shared.registerDeviceToken(hex)
                    guard PushTokenStorage.registrationAllowed else { return }
                    sharedAppState?.pushRegistrationState = .registered
                } catch {
                    guard PushTokenStorage.registrationAllowed else { return }
                    sharedAppState?.pushRegistrationState = .failed
                    print("[APNS] Device token registration failed: \(error.localizedDescription)")
                }
            }
            await mutation.value
        }
    }

    func application(_ application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: Error) {
        guard PushTokenStorage.registrationAllowed else { return }
        sharedAppState?.pushRegistrationState = .failed
        print("[APNS] Registration failed: \(error.localizedDescription)")
    }

    /// Delivered banners sit in the system Notification Center forever unless
    /// something removes them — APNs has no built-in expiry for already-shown
    /// notifications. Called on every foreground so stale booking/trade
    /// alerts don't pile up indefinitely once their content is no longer
    /// relevant.
    static let staleDeliveredNotificationAge: TimeInterval = 24 * 60 * 60

    static func pruneStaleDeliveredNotifications() async {
        let center = UNUserNotificationCenter.current()
        let delivered = await center.deliveredNotifications()
        let staleIds = delivered
            .filter { Date().timeIntervalSince($0.date) > staleDeliveredNotificationAge }
            .map(\.request.identifier)
        guard !staleIds.isEmpty else { return }
        center.removeDeliveredNotifications(withIdentifiers: staleIds)
    }

    /// Prevents a delayed APNs callback from re-registering a token after the
    /// authenticated session ends, and removes notification content that may
    /// identify the previous user.
    @MainActor
    static func clearRemoteNotificationsForSignedOutUser() {
        PushTokenStorage.registrationAllowed = false
        UserDefaults.standard.removeObject(forKey: PushTokenStorage.currentTokenKey)
        UIApplication.shared.unregisterForRemoteNotifications()

        let center = UNUserNotificationCenter.current()
        center.removeAllDeliveredNotifications()
        center.removeAllPendingNotificationRequests()
        Task { try? await center.setBadgeCount(0) }
        sharedAppState?.pushRegistrationState = .unknown
    }
}

/// Scene lifecycle owner for Home Screen quick actions. The handoff stores the
/// destination until the SwiftUI tab shell exists, which makes cold-launch and
/// warm-launch behavior use the same routing path.
@MainActor
final class GearTrackerSceneDelegate: NSObject, UIWindowSceneDelegate {
    func windowScene(
        _ windowScene: UIWindowScene,
        performActionFor shortcutItem: UIApplicationShortcutItem,
        completionHandler: @escaping (Bool) -> Void
    ) {
        completionHandler(GearTrackerQuickAction.handle(shortcutItem))
    }

    func scene(
        _ scene: UIScene,
        willConnectTo session: UISceneSession,
        options connectionOptions: UIScene.ConnectionOptions
    ) {
        guard let shortcutItem = connectionOptions.shortcutItem else { return }
        _ = GearTrackerQuickAction.handle(shortcutItem)
    }
}

// UNUserNotificationCenterDelegate's methods aren't @MainActor in their
// protocol declaration, but UNUserNotificationCenter always calls its
// delegate on the main thread in practice. @preconcurrency tells the
// compiler to trust that instead of requiring a nonisolated conformance.
extension AppDelegate: @preconcurrency UNUserNotificationCenterDelegate {
    // Show banner + sound when notification arrives in foreground
    func userNotificationCenter(
        _ center: UNUserNotificationCenter,
        willPresent notification: UNNotification,
        withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void
    ) {
        guard PushTokenStorage.registrationAllowed else {
            completionHandler([])
            return
        }
        // A foreground banner is enough feedback while the person is already
        // using the app; avoid repeating the full sound interruption on every
        // inbox, booking, or schedule update. `.list` keeps it in Notification
        // Center afterwards, where reading it in the app clears it.
        completionHandler([.banner, .list, .badge])
    }

    // User tapped notification (foreground or background)
    func userNotificationCenter(
        _ center: UNUserNotificationCenter,
        didReceive response: UNNotificationResponse,
        withCompletionHandler completionHandler: @escaping () -> Void
    ) {
        guard PushTokenStorage.registrationAllowed else {
            completionHandler()
            return
        }
        let notificationBoundary = authSessionBoundary.capture()
        let userInfo = response.notification.request.content.userInfo

        // A dismissal is not a destination. Only delivered when a category opts
        // into `.customDismissAction`, which none of ours do — guarded anyway,
        // because the fallthrough below would otherwise treat it as a tap.
        guard response.actionIdentifier != UNNotificationDismissActionIdentifier else {
            completionHandler()
            return
        }

        // Which action, which category, and how long after delivery. Tags only.
        let telemetryAction: String = switch GearTrackerNotificationAction(rawValue: response.actionIdentifier) {
        case .snooze: "snooze"
        case .acknowledgeBlast: "acknowledge"
        case .markRead: "mark_read"
        case .approve: "approve"
        case .decline: "decline"
        case .none: "tap"
        }
        let telemetryCategory = userInfo["category"] as? String
        let deliveredAt = response.notification.date
        Task { await NotificationTelemetry.recordAction(telemetryAction, category: telemetryCategory, deliveredAt: deliveredAt) }

        switch GearTrackerNotificationAction(rawValue: response.actionIdentifier) {
        case .snooze:
            // Entirely on-device: nothing to route, nothing to write. The
            // payload is lifted off the notification here, on the delegate's
            // actor, because `UNNotification` cannot cross into the task.
            let snooze = NotificationSnooze.Payload(notification: response.notification)
            Task {
                await NotificationSnooze.schedule(snooze, sessionBoundary: notificationBoundary)
                completionHandler()
            }
            return

        case .acknowledgeBlast:
            guard let blastId = userInfo["blastId"] as? String else {
                completionHandler()
                return
            }
            Task { @MainActor in
                defer { completionHandler() }
                guard PushTokenStorage.registrationAllowed,
                      authSessionBoundary.owns(notificationBoundary) else { return }
                // Idempotent server-side, so a double press costs nothing. A
                // failure is swallowed on purpose: there is no surface left to
                // show a retry on, and the in-app banner will still be there.
                try? await APIClient.shared.acknowledgeBlast(id: blastId)
            }
            return

        case .markRead:
            let notificationId = userInfo["notificationId"] as? String
            Task { @MainActor in
                defer { completionHandler() }
                guard PushTokenStorage.registrationAllowed,
                      authSessionBoundary.owns(notificationBoundary),
                      let notificationId else { return }
                do {
                    try await APIClient.shared.markNotificationRead(id: notificationId)
                    await sharedAppState?.refreshUnread()
                } catch {
                    await NotificationActionFeedback.reportFailure("Couldn't mark it as read")
                }
            }
            return

        case .approve, .decline:
            let approve = response.actionIdentifier == GearTrackerNotificationAction.approve.rawValue
            let target = ReviewDecisionTarget(userInfo: userInfo)
            let notificationId = userInfo["notificationId"] as? String
            Task { @MainActor in
                defer { completionHandler() }
                guard PushTokenStorage.registrationAllowed,
                      authSessionBoundary.owns(notificationBoundary) else { return }
                guard let target else {
                    await NotificationActionFeedback.reportFailure(approve ? "Couldn't approve" : "Couldn't decline")
                    return
                }
                do {
                    // The same endpoints the app uses; the server rechecks the
                    // Admin role and that the request is still pending.
                    switch (target, approve) {
                    case (.trade(let id), true): try await APIClient.shared.approveShiftTrade(id: id)
                    case (.trade(let id), false): try await APIClient.shared.declineShiftTrade(id: id)
                    case (.shiftRequest(let id), true): try await APIClient.shared.approveShift(assignmentId: id)
                    case (.shiftRequest(let id), false): try await APIClient.shared.declineShift(assignmentId: id)
                    }
                    if let notificationId {
                        try? await APIClient.shared.markNotificationRead(id: notificationId)
                    }
                    await sharedAppState?.refreshUnread()
                } catch {
                    await NotificationActionFeedback.reportFailure(approve ? "Couldn't approve" : "Couldn't decline")
                }
            }
            return

        case .none:
            // The default tap opens the thing the notification is about.
            break
        }

        routeNotificationDestination(userInfo: userInfo, notificationBoundary: notificationBoundary)
        completionHandler()
    }

    /// "Notification Settings" on the app's page in iOS Settings (and the
    /// same link in a notification's options menu) opens our own
    /// preferences. Offered because authorization requests
    /// `.providesAppNotificationSettings`.
    func userNotificationCenter(
        _ center: UNUserNotificationCenter,
        openSettingsFor notification: UNNotification?
    ) {
        guard PushTokenStorage.registrationAllowed else { return }
        let notificationBoundary = authSessionBoundary.capture()
        Task { @MainActor in
            guard authSessionBoundary.owns(notificationBoundary) else { return }
            sharedAppState?.apply(.notificationSettings)
        }
    }

    /// One routing path for a tapped notification and for every `.foreground`
    /// action, so an action can never reach a destination a tap could not.
    private func routeNotificationDestination(
        userInfo: [AnyHashable: Any],
        notificationBoundary: UUID
    ) {
        let type = userInfo["type"] as? String
        let route = GearTrackerRouteParser.parseNotification(userInfo: userInfo, type: type)
        Task { @MainActor in
            guard PushTokenStorage.registrationAllowed,
                  authSessionBoundary.owns(notificationBoundary) else { return }
            sharedAppState?.apply(route)
        }
    }
}
