#if DEBUG
import SwiftUI
import UserNotifications

@MainActor
private final class PerformanceDraftPersistence: ReservationDraftPersistence {
    func bookingDrafts() async throws -> [BookingDraftSummary] { [] }
    func bookingDraft(id: String) async throws -> BookingDraftDetail { throw CancellationError() }
    func saveBookingDraft(
        id: String?,
        title: String,
        requesterUserId: String?,
        locationId: String?,
        startsAt: Date,
        endsAt: Date,
        notes: String?,
        eventIds: [String],
        serializedAssetIds: [String],
        bulkItems: [BulkReservationRequest]
    ) async throws -> String { throw CancellationError() }
    func deleteBookingDraft(id: String) async throws {}
    func createReservation(
        title: String,
        requesterUserId: String,
        locationId: String,
        startsAt: Date,
        endsAt: Date,
        notes: String?,
        eventId: String?,
        eventIds: [String],
        shiftAssignmentId: String?,
        sourceDraftId: String?,
        serializedAssetIds: [String],
        bulkItems: [BulkReservationRequest],
        kitId: String?
    ) async throws -> ReservationCreationReceipt { throw CancellationError() }
}

struct PerformanceTestRootView: View {
    let scenario: AppRuntimeMode.PerformanceScenario

    var body: some View {
        switch scenario {
        case .welcomeStudent, .welcomeStaff, .welcomeApparel:
            WelcomeHarnessView()
        case .registration:
            NavigationStack { NativeRegistrationView(initialEmail: "alex.rivera@wisc.edu") }
        case .launch:
            RootView()
        case .items:
            PerformanceItemsView()
        case .equipment:
            PerformanceEquipmentView()
        case .guide:
            PerformanceGuideView()
        case .resourcesGuides:
            GuidesView()
        case .previewChrome:
            PreviewChromeHarnessView()
        case .resourcesUsers:
            UsersView()
        case .resourcesLicenses, .resourcesLicensesOpen:
            LicensesView()
        case .schedule:
            ScheduleHarnessView()
        case .tradeBoardStaff, .tradeBoardStudent:
            TradeBoardHarnessView()
        case .home, .homeAllClear, .homeAgenda:
            HomeHarnessView()
        case .scoreboard:
            ScoreboardHarnessView()
        case .profile:
            ProfileHarnessView()
        case .login:
            LoginView()
        case .launchView:
            LaunchView()
        case .passwordSetup:
            PasswordSetupView(email: "avery.nakamura@wisc.edu")
        case .studentBookings:
            StudentBookingsHarnessView()
        case .bookingDetail, .bookingExtend, .bookingEdit, .bookingEditReservation, .bookingEditItems,
             .bookingCancel, .bookingOverdue:
            BookingDetailHarnessView()
        case .itemEdit:
            ItemDetailHarnessView()
        case .createBookingScanner, .createBookingEvents:
            CreateBookingScannerHarnessView()
        case .search, .searchPartial:
            GlobalSearchHarnessView()
        case .itemsList:
            ItemsListHarnessView()
        case .reports:
            ReportsHarnessView()
        case .accountSecurity:
            AccountSecurityHarnessView()
        case .notifications:
            NotificationSettingsHarnessView()
        }
    }
}

/// Uses the real Welcome coordinator with isolated read-only profile fixtures.
private struct WelcomeHarnessView: View {
    @Environment(SessionStore.self) private var session
    var body: some View {
        ZStack {
            Color(.systemGroupedBackground).ignoresSafeArea()
            if session.currentUser != nil { ProfileCompletionWelcomeView() }
        }
        .onAppear { session.currentUser = WelcomeHarnessFixture.user }
    }
}

private enum WelcomeHarnessFixture {
    static var role: String { AppRuntimeMode.performanceScenario == .welcomeStaff ? "STAFF" : "STUDENT" }
    static var user: CurrentUser {
        CurrentUser(id: "welcome-fixture", name: "Alex Rivera", email: "alex.rivera@wisc.edu",
                    role: role, affiliation: nil, collaboratorProfile: nil, capabilities: [],
                    collaboratorPolicy: nil, staffingType: "ST", avatarUrl: nil, forcePasswordChange: false)
    }
    static var response: Data {
        let step = AppRuntimeMode.performanceScenario == .welcomeApparel ? "APPAREL" : (role == "STAFF" ? "EMAIL" : "PHONES")
        return Data("""
        {"data":{"profile":{"id":"welcome-fixture","name":"Alex Rivera","role":"\(role)","email":"alex.rivera@wisc.edu"},
         "completion":{"profileComplete":false,"shouldPrompt":true,"firstIncompleteStep":"\(step)","completedCount":1,"totalCount":8}}}
        """.utf8)
    }
}

/// Renders the real compact app shell with the same Student preview metadata
/// the server returns. Browse → Guides gives the capture a useful content
/// surface while keeping the before/after pair focused on the preview marker.
struct PreviewChromeHarnessView: View {
    @Environment(SessionStore.self) private var session
    @Environment(AppState.self) private var appState

    var body: some View {
        AppTabView()
            .onAppear {
                session.currentUser = PreviewChromeFixtures.previewUser
                appState.selectedTab = 2
            }
    }
}

/// The real Account & Security screen against a canned passkey list, so the
/// credential rows can be reviewed without a signed-in session. Passkey
/// enrollment itself needs real hardware; the rows do not.
struct AccountSecurityHarnessView: View {
    @Environment(SessionStore.self) private var session

    var body: some View {
        NavigationStack {
            AccountSecuritySettingsView(manageAccountURL: AppEnvironment.baseURL)
                .onAppear { session.currentUser = ScheduleFixtures.staffUser }
        }
    }
}

/// Renders the real notification settings screen with an account-wide pause
/// already active. The view model is seeded before the child appears so its
/// `.task` does not race the fixture setup or reach a live host.
struct NotificationSettingsHarnessView: View {
    @Environment(SessionStore.self) private var session
    @Environment(AppState.self) private var appState
    @State private var prefsVM = NotificationPrefsViewModel()
    @State private var pushAuth: UNAuthorizationStatus = .authorized
    @State private var seeded = false

    var body: some View {
        ZStack {
            Color(.systemGroupedBackground).ignoresSafeArea()
            if seeded {
                NavigationStack {
                    NotificationSettingsView(
                        prefsVM: prefsVM,
                        pushAuth: $pushAuth,
                        iosSettingsURL: AppEnvironment.baseURL,
                        showPushPrompt: {}
                    )
                }
            }
        }
        .onAppear {
            session.currentUser = ScheduleFixtures.staffUser
            prefsVM.prefs = NotificationFixtureAPI.pausedPreferences
            prefsVM.catalog = NotificationFixtureAPI.staffCatalog
            appState.pushRegistrationState = .failed
            seeded = true
        }
    }
}

enum NotificationFixtureAPI {
    static var pausedPreferences: NotificationPreferences {
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        return NotificationPreferences(
            pausedUntil: formatter.string(from: Date.now.addingTimeInterval(60 * 60)),
            channels: NotificationPreferences.Channels(email: true, push: true),
            badges: true,
            categories: NotificationPreferences.Categories(
                checkoutDue: true,
                checkoutOverdue: true,
                reservation: true,
                licenseExpiry: true,
                schedule: true,
                trade: true,
                gearPrep: false
            ),
            push: [
                "checkoutDue": .standard,
                "checkoutOverdue": .standard,
                "reservation": .standard,
                "gearPrep": .off,
                "schedule": .standard,
                "trade": .standard,
                "timeOff": .standard,
                "licenseExpiry": .silent,
                "itemReports": .standard,
            ],
            quietHours: NotificationQuietHours(
                enabled: true,
                start: "22:00",
                end: "07:00",
                days: [0, 1, 2, 3, 4],
                allowUrgent: true
            )
        )
    }

    /// Mirrors the server catalog for a Staff account (`catalogForRole("STAFF")`).
    static let staffCatalog: [NotificationCategoryEntry] = [
        entry("checkoutDue", "Checkout due reminders", "gear", .standard),
        entry("checkoutOverdue", "Checkout overdue alerts", "gear", .standard, urgent: true),
        entry("reservation", "Reservation updates", "gear", .standard),
        entry("gearPrep", "Gear prep nudges", "gear", .silent),
        entry("schedule", "Schedule updates", "schedule", .silent),
        entry("trade", "Trade updates", "schedule", .standard),
        entry("timeOff", "Time-off decisions", "schedule", .standard),
        entry("licenseExpiry", "License expiry reminders", "account", .silent),
        entry("itemReports", "Damaged and lost item reports", "admin", .standard, push: false),
    ]

    private static func entry(
        _ id: String,
        _ label: String,
        _ group: String,
        _ defaultLevel: NotificationPushLevel,
        push: Bool = true,
        urgent: Bool = false
    ) -> NotificationCategoryEntry {
        NotificationCategoryEntry(
            id: id,
            label: label,
            description: label,
            group: group,
            defaultLevel: defaultLevel,
            push: push,
            urgent: urgent
        )
    }
}

/// Global search with a query already committed. The point of the capture is
/// the result list -- items, reservations, checkouts, and people ranked into
/// one set of destinations -- so the fixture answers all four searches the
/// service fans out to.
struct GlobalSearchHarnessView: View {
    @Environment(SessionStore.self) private var session

    var body: some View {
        GlobalSearchSheet()
            .onAppear { session.currentUser = ScheduleFixtures.staffUser }
    }
}

/// The real `ItemsView`, not the synthetic performance list. The `items`
/// scenario renders a hand-built List of AssetRow for scroll measurement; this
/// one is the shipping screen with its search, filters, and row treatments.
struct ItemsListHarnessView: View {
    @Environment(SessionStore.self) private var session

    var body: some View {
        ItemsView()
            .onAppear { session.currentUser = ScheduleFixtures.staffUser }
    }
}

/// The real `ReportsView` against canned utilization and activity payloads.
/// Swift Charts failures are invisible to a compiler and to model tests -- an
/// empty series renders a blank box that still builds -- so this exists to be
/// looked at.
struct ReportsHarnessView: View {
    @Environment(SessionStore.self) private var session

    var body: some View {
        NavigationStack {
            ReportsView()
        }
        .onAppear { session.currentUser = ScheduleFixtures.staffUser }
    }
}

/// Renders the real `ItemDetailView` against a canned asset so its edit sheet
/// can be captured. Pushed in a stack for the same reason booking detail is.
struct ItemDetailHarnessView: View {
    @Environment(SessionStore.self) private var session

    var body: some View {
        NavigationStack {
            ItemDetailView(assetId: AssetFixtureAPI.assetId)
        }
        .onAppear { session.currentUser = ScheduleFixtures.staffUser }
    }
}

/// The reservation composer with its QR cover seeded open. The simulator has no
/// camera, so what this captures is the permission priming a first-time user
/// meets -- which is the state worth reviewing anyway, since the viewfinder
/// itself is the system's.
struct CreateBookingScannerHarnessView: View {
    @Environment(SessionStore.self) private var session
    @State private var isPresented = true
    @State private var viewModel = CreateBookingViewModel()

    var body: some View {
        Color(.systemGroupedBackground)
            .ignoresSafeArea()
            .sheet(isPresented: $isPresented) {
                CreateBookingSheet(vm: viewModel)
            }
            .onAppear { session.currentUser = ScheduleFixtures.staffUser }
    }
}

/// Renders the real `BookingDetailView` against a canned booking. Wrapped in a
/// `NavigationStack` because the screen is normally pushed, and its toolbar and
/// title are half of what a review is looking at.
struct BookingDetailHarnessView: View {
    @Environment(SessionStore.self) private var session

    var body: some View {
        NavigationStack {
            BookingDetailView(bookingId: AppRuntimeMode.CaptureSeed.bookingEditReservation
                ? "up1"
                : BookingFixtureAPI.bookingId)
        }
        .onAppear { session.currentUser = ScheduleFixtures.staffUser }
    }
}

/// Renders the real Bookings tab as a Student. The fixture honors the
/// requester's query parameter so the committed Mine default and the shared
/// All default produce a meaningful before/after capture.
struct StudentBookingsHarnessView: View {
    @Environment(SessionStore.self) private var session

    var body: some View {
        BookingsView()
            .onAppear { session.currentUser = TradeBoardFixtures.student }
    }
}

private struct PerformanceItemsView: View {
    private let assets = PerformanceFixtures.assets

    var body: some View {
        NavigationStack {
            List(assets) { asset in
                AssetRow(asset: asset)
                    .listRowSeparator(.hidden)
                    .listRowBackground(Color.clear)
                    .accessibilityIdentifier(asset.id)
            }
            .listStyle(.plain)
            .scrollContentBackground(.hidden)
            .background(Color(.systemGroupedBackground))
            .navigationTitle("Performance Items")
            .accessibilityIdentifier("performance-items-list")
        }
    }
}

@MainActor
private struct PerformanceEquipmentView: View {
    private let fixtures: [Asset]
    @State private var viewModel: CreateBookingViewModel

    init() {
        let fixtures = PerformanceFixtures.assets
        let persistence = PerformanceDraftPersistence()
        let viewModel = CreateBookingViewModel(
            draftPersistence: persistence,
            performsRemoteAssetSearch: false
        )
        viewModel.availableAssets = fixtures
        viewModel.assetTotal = fixtures.count
        viewModel.popularItemOrder = fixtures.map(\.id)
        viewModel.selectedLocationId = PerformanceFixtures.location.id
        viewModel.options = FormOptions(
            locations: [FormOption(id: PerformanceFixtures.location.id, name: PerformanceFixtures.location.name)],
            users: [],
            bulkSkus: PerformanceFixtures.bulkSkus
        )
        self.fixtures = fixtures
        _viewModel = State(initialValue: viewModel)
    }

    var body: some View {
        NavigationStack {
            CreateBookingEquipmentPicker(vm: viewModel, onReview: {})
                .navigationTitle("Performance Equipment")
                .accessibilityIdentifier("performance-equipment-picker")
        }
        .onChange(of: viewModel.assetSearch) { _, search in
            let query = search.trimmingCharacters(in: .whitespacesAndNewlines)
            viewModel.availableAssets = query.isEmpty
                ? fixtures
                : fixtures.filter {
                    [$0.assetTag, $0.name, $0.brand, $0.model]
                        .compactMap { $0 }
                        .joined(separator: " ")
                        .localizedCaseInsensitiveContains(query)
                }
            viewModel.assetTotal = viewModel.availableAssets.count
        }
    }
}

@MainActor
private struct PerformanceGuideView: View {
    var body: some View {
        NavigationStack {
            ScrollView {
                NativeMarkdownArticle(markdown: PerformanceFixtures.guideMarkdown)
                    .padding(.horizontal, 24)
                    .padding(.vertical, 16)
                    .frame(maxWidth: 720, alignment: .leading)
                    .frame(maxWidth: .infinity)
            }
            .background(Color(.systemBackground))
            .navigationTitle("Performance Guide")
            .navigationBarTitleDisplayMode(.inline)
            .accessibilityIdentifier("performance-guide-article")
        }
    }
}

// MARK: - Fixture API

/// Serves canned API responses for the Resources harness scenarios.
///
/// Registered on `APIClient`'s session only when a fixture scenario is active,
/// so the real views, view models, and `Codable` decode paths all run unchanged
/// against representative payloads — no signed-in session and no network.
final class FixtureAPIProtocol: URLProtocol, @unchecked Sendable {
    /// Claims every `/api/` request in a fixture scenario, not just the mapped
    /// paths. An unmapped call would otherwise reach the real host, 401, and
    /// broadcast a session expiry that signs the fixture user out mid-capture.
    override class func canInit(with request: URLRequest) -> Bool {
        guard AppRuntimeMode.usesFixtureAPI else { return false }
        return request.url?.path.hasPrefix("/api/") == true
    }

    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }

    override func startLoading() {
        guard let url = request.url else {
            client?.urlProtocol(self, didFailWithError: URLError(.unsupportedURL))
            return
        }

        // Unmapped paths answer 404, never 401: `APIError.notFound` stays local
        // to the caller, while a 401 would tear down the harness session.
        let mapped = Self.body(for: request)
        let payload = mapped ?? Data(#"{"error":"Not served by the fixture harness"}"#.utf8)
        let response = HTTPURLResponse(
            url: url,
            statusCode: mapped == nil ? 404 : 200,
            httpVersion: "HTTP/1.1",
            headerFields: ["Content-Type": "application/json"]
        )!

        let delay = AppRuntimeMode.fixtureResponseDelayMilliseconds
        guard delay > 0 else {
            deliver(response, payload)
            return
        }
        // `HTTPURLResponse` and `Data` are Sendable; the protocol instance is
        // reached weakly so a cancelled load simply drops the delivery.
        DispatchQueue.global().asyncAfter(deadline: .now() + .milliseconds(delay)) { [weak self] in
            self?.deliver(response, payload)
        }
    }

    override func stopLoading() {}

    private func deliver(_ response: HTTPURLResponse, _ payload: Data) {
        client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
        client?.urlProtocol(self, didLoad: payload)
        client?.urlProtocolDidFinishLoading(self)
    }

    private static func body(for request: URLRequest) -> Data? {
        guard let path = request.url?.path else { return nil }
        if path == "/api/me/profile-completion", request.httpMethod == "GET",
           [.welcomeStudent, .welcomeStaff, .welcomeApparel].contains(AppRuntimeMode.performanceScenario) {
            return WelcomeHarnessFixture.response
        }
        switch path {
        case "/api/resources": return FixtureAPI.guides
        case let path where path.hasPrefix("/api/resources/"):
            let slug = String(path.dropFirst("/api/resources/".count))
            return FixtureAPI.guideDetail(slug: slug)
        case "/api/users":
            if AppRuntimeMode.performanceScenario == .searchPartial { return nil }
            return AppRuntimeMode.performanceScenario == .search
                ? SearchFixtureAPI.people
                : FixtureAPI.users
        case "/api/licenses":
            return AppRuntimeMode.performanceScenario == .resourcesLicensesOpen
                ? FixtureAPI.openLicenses
                : FixtureAPI.licenses
        case "/api/licenses/my":
            return AppRuntimeMode.performanceScenario == .resourcesLicensesOpen
                ? FixtureAPI.noLicense
                : FixtureAPI.myLicense
        case "/api/me":
            return AppRuntimeMode.performanceScenario == .previewChrome
                ? PreviewChromeFixtures.me
                : ScheduleFixtureAPI.me
        // Lets the login capture reach the password step without a real host.
        case "/api/auth/discover": return AuthFixtureAPI.discoverPassword
        case "/api/me/passkeys": return PasskeyFixtureAPI.passkeys
        case "/api/dashboard":
            switch AppRuntimeMode.performanceScenario {
            case .homeAllClear: return HomeFixtureAPI.allClearDashboard
            case .homeAgenda: return HomeFixtureAPI.agendaDashboard
            default: return HomeFixtureAPI.dashboard
            }
        case "/api/users/\(ScoreboardFixtureAPI.userId)/scoreboard":
            return ScoreboardFixtureAPI.scoreboard(for: request)
        case "/api/users/\(ScoreboardFixtureAPI.userId)":
            return ProfileFixtureAPI.userDetail
        case "/api/badges/user/\(ScoreboardFixtureAPI.userId)":
            return ProfileFixtureAPI.badgeProfile
        case "/api/shift-trades": return TradeBoardFixtureAPI.trades
        case "/api/schedule/open-work": return TradeBoardFixtureAPI.openWork
        case "/api/shift-groups": return ScheduleFixtureAPI.shiftGroups(for: request)
        case "/api/calendar-events": return ScheduleFixtureAPI.calendarEvents(for: request)
        case "/api/my-shifts": return ScheduleFixtureAPI.myShifts(for: request)
        case "/api/bookings": return BookingFixtureAPI.list(for: request)
        case let path where path.hasPrefix("/api/bookings/"):
            let bookingId = String(path.dropFirst("/api/bookings/".count))
            return BookingFixtureAPI.booking(for: bookingId)
        case "/api/availability/check": return BookingFixtureAPI.availability
        case let path where path.hasPrefix("/api/assets/"):
            let assetId = String(path.dropFirst("/api/assets/".count))
            return AssetFixtureAPI.asset(for: assetId)
        case "/api/assets": return SearchFixtureAPI.assets(for: request)
        case "/api/reports/utilization": return ReportsFixtureAPI.utilization
        case "/api/reports/checkouts": return ReportsFixtureAPI.checkouts
        case "/api/reservations": return SearchFixtureAPI.reservations
        case "/api/kits": return ReservationFixtureAPI.kits
        case "/api/form-options": return ReservationFixtureAPI.formOptions
        // Left unmapped in the partial scenario so the protocol answers 404 and
        // those two sources throw, exactly as a real outage would.
        case "/api/checkouts":
            return AppRuntimeMode.performanceScenario == .searchPartial ? nil : SearchFixtureAPI.checkouts
        default: return nil
        }
    }
}

/// Pickup rooms and a callable kit so New Reservation Details can be captured
/// without a live `/api/form-options` or kit catalog.
enum ReservationFixtureAPI {
    static var formOptions: Data {
        Data(#"""
        {"data":{
          "locations":[
            {"id":"loc-1","name":"Camp Randall"},
            {"id":"loc-kc","name":"Kohl Center"}
          ],
          "users":[
            {"id":"fixture-staff","name":"Bucky Badger","avatarUrl":null}
          ],
          "bulkSkus":[
            {"id":"sku-sony-battery","name":"Sony Battery","category":"Batteries","unit":"each",
             "locationId":"loc-1","binQrCodeValue":null,"trackByNumber":true,
             "categoryName":"Batteries","imageUrl":null,"currentQuantity":24,"availableQuantity":18}
          ]
        }}
        """#.utf8)
    }

    static var kits: Data {
        Data(#"""
        {"data":[
          {"id":"kit-slow-1","name":"Slow 1","sportCode":"FB","gamedayRole":"SLOW1","_count":{"members":4,"bulkMembers":2}}
        ],"suggestedKitId":null}
        """#.utf8)
    }
}

/// The account-discovery answer that sends Login to its password step.
enum AuthFixtureAPI {
    static var discoverPassword: Data {
        #"{"flow":"password"}"#.data(using: .utf8)!
    }
}

/// Passkey metadata covering the three states the list has to distinguish: a
/// synced credential, one that dies with this device, and one enrolled but
/// never used. Dates are relative to launch so "Used" never freezes at an
/// authored day.
enum PasskeyFixtureAPI {
    private static func isoString(daysAgo: Int) -> String {
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime]
        return formatter.string(from: Calendar.current.date(byAdding: .day, value: -daysAgo, to: Date()) ?? Date())
    }

    static var passkeys: Data {
        """
        {"data":[
          {"id":"passkey-1","name":"iPhone","createdAt":"\(isoString(daysAgo: 41))","lastUsedAt":"\(isoString(daysAgo: 1))","deviceType":"multiDevice","backedUp":true},
          {"id":"passkey-2","name":"Chrome on macOS","createdAt":"\(isoString(daysAgo: 12))","lastUsedAt":"\(isoString(daysAgo: 5))","deviceType":"singleDevice","backedUp":false},
          {"id":"passkey-3","name":"Front desk iPad","createdAt":"\(isoString(daysAgo: 2))","lastUsedAt":null,"deviceType":"multiDevice","backedUp":true}
        ]}
        """.data(using: .utf8)!
    }
}

/// Report payloads sized so every element of the screen has something to draw:
/// a status mix with more than one slice, a custody block, and a daily trend
/// long enough to read as a line rather than a dot.
enum ReportsFixtureAPI {
    static var utilization: Data {
        // No `data` envelope: unlike the other routes served here, the report
        // endpoints decode straight into their model.
        Data("""
        {
          "days":30,"activeAssets":186,"partialFailures":null,"totalAssets":214,
          "statusCounts":{"AVAILABLE":142,"CHECKED_OUT":48,"RESERVED":16,"MAINTENANCE":6,"RETIRED":2},
          "custody":{"utilizationRate":0.63,"custodyDays":1184.5,"assetsUsed":134,
                     "checkoutCount":417,"idleCount":52,"neverCheckedOutCount":28,
                     "topUsed":[
                       {"assetId":"a-1","assetTag":"CAM-014","name":"Sony FX3","checkouts":38,
                        "custodyDays":112.5,"utilizationRate":0.81},
                       {"assetId":"a-2","assetTag":"AUD-007","name":"Sennheiser MKE 600","checkouts":31,
                        "custodyDays":88.0,"utilizationRate":0.72},
                       {"assetId":"a-3","assetTag":"SUP-031","name":"Manfrotto 504X Tripod","checkouts":27,
                        "custodyDays":74.5,"utilizationRate":0.64}
                     ]}
        }
        """.utf8)
    }

    static var checkouts: Data {
        let calendar = Calendar.current
        let today = calendar.startOfDay(for: Date())
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        formatter.timeZone = .current
        // A shape with a visible weekly rhythm rather than noise, so the chart
        // reads as a real gear room: quiet midweek, heavy on event days.
        let counts = [4, 6, 3, 9, 21, 27, 11, 5, 7, 4, 12, 24, 31, 14,
                      6, 5, 8, 10, 19, 29, 12, 7, 4, 6, 11, 22, 26, 13, 8, 9]
        let points = counts.enumerated().map { offset, count -> String in
            let day = calendar.date(byAdding: .day, value: offset - (counts.count - 1), to: today) ?? today
            return "{\"date\":\"\(formatter.string(from: day))\",\"count\":\(count)}"
        }.joined(separator: ",")
        return Data("""
        {
          "days":30,"partialFailures":null,"totalCheckouts":417,
          "previousTotalCheckouts":362,"overdueCheckouts":3,
          "dailyTrend":[\(points)]
        }
        """.utf8)
    }

}

/// Search fans out to four endpoints at once, so a result list only looks real
/// if every one of them answers. Items, an upcoming reservation, an open
/// checkout, and people all match the same query on purpose -- a search that
/// returns one kind of thing does not exercise the ranking this screen exists
/// to show. `/api/users` is already served above and is reused as-is.
enum SearchFixtureAPI {
    /// Mirrors `AppRuntimeMode.CaptureSeed.searchQuery`, which is what the
    /// view actually reads; kept here so the fixture data and the typed query
    /// stay described in one place.
    static let query = "football"

    static let people = Data("""
    {"total":3,"limit":50,"offset":0,"data":[
      {"id":"u-avery","name":"Avery Nakamura","email":"avery.nakamura@wisc.edu","role":"STAFF",
       "title":"Football Video Lead","primaryArea":"VIDEO","active":true},
      {"id":"u-priya","name":"Priya Ramachandran","email":"priya.ramachandran@wisc.edu","role":"STUDENT",
       "title":"Football Photo","primaryArea":"PHOTO","active":true},
      {"id":"u-marcus","name":"Marcus Webb","email":"marcus.webb@wisc.edu","role":"STUDENT",
       "title":"Football Social","primaryArea":"SOCIAL","active":true}
    ]}
    """.utf8)

    private static func iso(_ minutes: Int) -> String {
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime]
        return formatter.string(from: Date.now.addingTimeInterval(TimeInterval(minutes * 60)))
    }

    private static func asset(
        id: String,
        tag: String,
        name: String,
        categoryId: String,
        category: String,
        departmentId: String,
        department: String,
        status: String,
        favorited: Bool = false
    ) -> String {
        """
        {"id":"\(id)","assetTag":"\(tag)","name":"\(name)","brand":"Sony","model":"FX3",
         "serialNumber":"SERIAL-\(id)","imageUrl":null,"computedStatus":"\(status)",
         "location":{"id":"loc-1","name":"Camp Randall Creative Desk"},
         "category":{"id":"\(categoryId)","name":"\(category)"},"department":{"id":"\(departmentId)","name":"\(department)"},
         "activeBooking":null,"purchaseDate":"2025-03-14","purchasePrice":"3899.00",
         "residualValue":"2100.00","isFavorited":\(favorited ? "true" : "false")}
        """
    }

    private static let family = """
    {"id":"sku-football-battery","kind":"BULK","name":"Football battery family","category":"Batteries",
     "unit":"battery","trackByNumber":true,"onHandQuantity":8,"availableQuantity":5,
     "checkedOutQuantity":3,"lostQuantity":0,"retiredQuantity":0,"matchedUnitNumber":null,
     "matchedUnitStatus":null,"matchedUnitHolder":null,"matchedUnitHolderAvatarUrl":null,
     "matchedUnitDueAt":null,"matchedUnitBookingTitle":null,"matchedUnitBookingId":null,"units":null,
     "imageUrl":null,"locationName":"Camp Randall Creative Desk","locationId":"loc-1",
     "categoryId":"cat-batteries","departmentId":"dep-video","departmentName":"Video",
     "binQrCodeValue":"BIN-FOOTBALL-BATTERY"}
    """

    static func assets(for request: URLRequest) -> Data {
        let queryItems = URLComponents(url: request.url ?? URL(fileURLWithPath: "/"), resolvingAgainstBaseURL: false)?.queryItems ?? []
        let requestedLimit = Int(queryItems.first(where: { $0.name == "limit" })?.value ?? "10") ?? 10
        let requestedOffset = Int(queryItems.first(where: { $0.name == "offset" })?.value ?? "0") ?? 0
        let rows: [(id: String, kind: String, payload: String)] = [
            ("a-1", "asset", asset(id: "a-1", tag: "CAM-014", name: "A-cam body", categoryId: "cat-camera", category: "Cameras", departmentId: "dep-video", department: "Video", status: "CHECKED_OUT")),
            ("a-5", "asset", asset(id: "a-5", tag: "LENS-032", name: "Football 70–200mm", categoryId: "cat-lens", category: "Lenses", departmentId: "dep-photo", department: "Photo", status: "AVAILABLE", favorited: true)),
            ("a-2", "asset", asset(id: "a-2", tag: "CAM-015", name: "Football camera 02", categoryId: "cat-camera", category: "Cameras", departmentId: "dep-video", department: "Video", status: "AVAILABLE")),
            ("a-3", "asset", asset(id: "a-3", tag: "CAM-016", name: "Football camera 03", categoryId: "cat-camera", category: "Cameras", departmentId: "dep-video", department: "Video", status: "AVAILABLE")),
            ("a-4", "asset", asset(id: "a-4", tag: "CAM-017", name: "Football camera 04", categoryId: "cat-camera", category: "Cameras", departmentId: "dep-video", department: "Video", status: "AVAILABLE")),
            ("a-6", "asset", asset(id: "a-6", tag: "LENS-033", name: "Football 24–70mm", categoryId: "cat-lens", category: "Lenses", departmentId: "dep-photo", department: "Photo", status: "AVAILABLE")),
            ("a-7", "asset", asset(id: "a-7", tag: "AUD-007", name: "Football field recorder", categoryId: "cat-audio", category: "Audio", departmentId: "dep-audio", department: "Audio", status: "CHECKED_OUT")),
            ("a-8", "asset", asset(id: "a-8", tag: "AUD-008", name: "Football wireless set", categoryId: "cat-audio", category: "Audio", departmentId: "dep-audio", department: "Audio", status: "AVAILABLE")),
            ("a-9", "asset", asset(id: "a-9", tag: "TRI-021", name: "Football sideline tripod", categoryId: "cat-support", category: "Support", departmentId: "dep-video", department: "Video", status: "AVAILABLE")),
            ("sku-football-battery", "family", family),
            ("a-10", "asset", asset(id: "a-10", tag: "MON-010", name: "Football field monitor", categoryId: "cat-monitor", category: "Monitors", departmentId: "dep-video", department: "Video", status: "AVAILABLE")),
            ("a-11", "asset", asset(id: "a-11", tag: "CAM-018", name: "Football camera 11", categoryId: "cat-camera", category: "Cameras", departmentId: "dep-video", department: "Video", status: "AVAILABLE")),
            ("a-12", "asset", asset(id: "a-12", tag: "CAM-019", name: "Football camera 12", categoryId: "cat-camera", category: "Cameras", departmentId: "dep-video", department: "Video", status: "AVAILABLE")),
        ]
        let page = Array(rows.dropFirst(max(0, requestedOffset)).prefix(max(1, requestedLimit)))
        let assets = page.filter { $0.kind == "asset" }.map(\.payload).joined(separator: ",")
        let families = page.filter { $0.kind == "family" }.map(\.payload).joined(separator: ",")
        let order = page.map { "\"\($0.kind == "family" ? "bulk-\($0.id)" : $0.id)\"" }.joined(separator: ",")
        return Data("{\"data\":[\(assets)],\"bulkItems\":[\(families)],\"itemOrder\":[\(order)],\"total\":\(rows.count),\"limit\":\(requestedLimit),\"offset\":\(requestedOffset)}".utf8)
    }

    static var reservations: Data {
        Data("""
        {"data":[
          {"id":"rs-1","kind":"RESERVATION","title":"Football vs Ohio State — photo","status":"BOOKED",
           "startsAt":"\(iso(2880))","endsAt":"\(iso(3240))","notes":null,"refNumber":"RS-1180",
           "requester":{"id":"u-priya","name":"Priya Ramachandran","email":null,"avatarUrl":null},
           "location":{"id":"loc-1","name":"Camp Randall Creative Desk"},
           "serializedItems":[],"bulkItems":[],"event":null,"events":[],
           "allowedActions":[],"updatedAt":"\(iso(-600))","pickupKioskDevice":null}
        ],"total":1,"limit":10,"offset":0}
        """.utf8)
    }

    static var checkouts: Data {
        Data("""
        {"data":[
          {"id":"\(BookingFixtureAPI.bookingId)","kind":"CHECKOUT","title":"Football fall camp — video",
           "status":"OPEN","startsAt":"\(iso(-120))","endsAt":"\(iso(180))","notes":null,
           "refNumber":"CO-2418",
           "requester":{"id":"u-avery","name":"Avery Nakamura","email":null,"avatarUrl":null},
           "location":{"id":"loc-1","name":"Camp Randall Creative Desk"},
           "serializedItems":[],"bulkItems":[],"event":null,"events":[],
           "allowedActions":[],"updatedAt":"\(iso(-30))","pickupKioskDevice":null}
        ],"total":1,"limit":10,"offset":0}
        """.utf8)
    }
}

/// One camera body, carrying the fields the edit sheet actually writes to --
/// name, serial, and notes -- plus enough identity for the detail screen behind
/// the sheet to look like a real item rather than a blank form.
enum AssetFixtureAPI {
    static let assetId = "asset-fixture-1"

    private static let linkedSearchAssets: [String: (tag: String, name: String)] = [
        "a-1": ("CAM-014", "A-cam body"),
        "a-2": ("CAM-015", "Football camera 02"),
        "a-3": ("CAM-016", "Football camera 03"),
        "a-4": ("CAM-017", "Football camera 04"),
        "a-5": ("LENS-032", "Football 70–200mm"),
        "a-6": ("LENS-033", "Football 24–70mm"),
        "a-7": ("AUD-007", "Football field recorder"),
        "a-8": ("AUD-008", "Football wireless set"),
        "a-9": ("TRI-021", "Football sideline tripod"),
        "a-10": ("MON-010", "Football field monitor"),
        "a-11": ("CAM-018", "Football camera 11"),
        "a-12": ("CAM-019", "Football camera 12"),
    ]

    static func asset(for id: String) -> Data? {
        guard id == assetId || linkedSearchAssets[id] != nil else { return nil }
        guard let detail = linkedSearchAssets[id] else { return asset }

        var payload = String(decoding: asset, as: UTF8.self)
        payload = payload.replacingOccurrences(of: "\"id\":\"\(assetId)\"", with: "\"id\":\"\(id)\"")
        payload = payload.replacingOccurrences(of: "\"assetTag\":\"CAM-014\"", with: "\"assetTag\":\"\(detail.tag)\"")
        payload = payload.replacingOccurrences(of: "\"name\":\"A-cam body\"", with: "\"name\":\"\(detail.name)\"")
        payload = payload.replacingOccurrences(of: "\"qrCodeValue\":\"CAM-014\"", with: "\"qrCodeValue\":\"\(detail.tag)\"")
        return Data(payload.utf8)
    }

    private static var asset: Data {
        Data("""
        {"data":{
          "id":"\(assetId)","assetTag":"CAM-014","name":"A-cam body",
          "brand":"Sony","model":"FX3","serialNumber":"FX3-88120",
          "imageUrl":null,"qrCodeValue":"CAM-014","linkUrl":null,
          "computedStatus":"AVAILABLE",
          "location":{"id":"loc-1","name":"Camp Randall Creative Desk"},
          "category":{"id":"cat-1","name":"Cameras"},
          "department":{"id":"dep-1","name":"Video"},
          "activeBooking":null,"upcomingReservations":[],"history":[],
          "parentAsset":null,"accessories":null,"metadata":null,
          "purchaseDate":"2025-03-14","purchasePrice":"3899.00","residualValue":"2100.00",
          "notes":"Shutter count checked at the start of the season. Ships with the cage attached.",
          "isFavorited":false
        }}
        """.utf8)
    }
}

/// One open checkout, sized so the detail screen has something to say in every
/// block it renders: a requester, a location, both serialized and bulk gear, a
/// linked event, and the actions an open checkout actually allows.
enum BookingFixtureAPI {
    static let bookingId = "bk-fixture-1"

    private static let linkedDashboardBookings: [String: (title: String, status: String, kind: String)] = [
        "od1": ("Volleyball baseline kit", "OPEN", "CHECKOUT"),
        "dt1": ("Football fall camp — video", "OPEN", "CHECKOUT"),
        "dt2": ("Women’s soccer portraits", "OPEN", "CHECKOUT"),
        "up1": ("Ohio State photo kit", "BOOKED", "RESERVATION"),
        "up2": ("Hockey road audio kit", "BOOKED", "RESERVATION"),
        "up3": ("Kohl Center studio shoot", "BOOKED", "RESERVATION"),
        "bk-student-own": ("Student camera kit", "OPEN", "CHECKOUT"),
        "bk-team-reservation": ("Volleyball photo package", "BOOKED", "RESERVATION"),
        "bk-team-pickup": ("Field audio pickup", "PENDING_PICKUP", "CHECKOUT"),
    ]

    static func booking(for id: String) -> Data? {
        if id == "\(bookingId)/nudge" { return Data(#"{"success":true}"#.utf8) }
        guard id == bookingId || linkedDashboardBookings[id] != nil else { return nil }
        guard let detail = linkedDashboardBookings[id] else {
            return AppRuntimeMode.performanceScenario == .bookingOverdue ? overdueBooking : booking
        }

        var payload = String(decoding: booking, as: UTF8.self)
        payload = payload.replacingOccurrences(of: "\"id\":\"\(bookingId)\"", with: "\"id\":\"\(id)\"")
        payload = payload.replacingOccurrences(of: "\"title\":\"Volleyball vs Nebraska\"", with: "\"title\":\"\(detail.title)\"")
        payload = payload.replacingOccurrences(of: "\"status\":\"OPEN\"", with: "\"status\":\"\(detail.status)\"")
        payload = payload.replacingOccurrences(of: "\"kind\":\"CHECKOUT\"", with: "\"kind\":\"\(detail.kind)\"")
        return Data(payload.utf8)
    }

    private static let studentListReferenceDate: Date = {
        let now = Date.now
        let calendar = Calendar.current
        let components = calendar.dateComponents([.year, .month, .day, .hour], from: now)
        return calendar.date(from: components) ?? now
    }()

    private static func iso(_ minutes: Int) -> String {
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime]
        return formatter.string(from: Date.now.addingTimeInterval(TimeInterval(minutes * 60)))
    }

    private static func studentISO(_ minutes: Int) -> String {
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime]
        return formatter.string(from: studentListReferenceDate.addingTimeInterval(TimeInterval(minutes * 60)))
    }

    /// Two hours past due, so the Nudge action is on screen.
    private static var overdueBooking: Data {
        bookingPayload(startsInMinutes: -360, endsInMinutes: -120, allowedActions: #"["extend","edit","nudge"]"#)
    }

    private static var booking: Data {
        bookingPayload(startsInMinutes: -120, endsInMinutes: 180, allowedActions: #"["extend","edit","cancel"]"#)
    }

    private static func bookingPayload(startsInMinutes: Int, endsInMinutes: Int, allowedActions: String) -> Data {
        Data("""
        {"data":{
          "id":"\(bookingId)","kind":"CHECKOUT","title":"Volleyball vs Nebraska","status":"OPEN",
          "startsAt":"\(iso(startsInMinutes))","endsAt":"\(iso(endsInMinutes))",
          "notes":"Two bodies on the baseline, one roaming. Return through the gear room, not the loading dock.",
          "refNumber":"CO-2418",
          "requester":{"id":"u-avery","name":"Avery Nakamura","email":"avery.nakamura@wisc.edu","avatarUrl":null},
          "location":{"id":"loc-1","name":"Camp Randall Creative Desk"},
          "serializedItems":[
            {"id":"si-1","assetId":"a-1","allocationStatus":"CHECKED_OUT",
             "asset":{"id":"a-1","assetTag":"CAM-014","name":"Sony FX3","brand":"Sony","model":"FX3",
                      "serialNumber":"FX3-88120","imageUrl":null}},
            {"id":"si-2","assetId":"a-2","allocationStatus":"CHECKED_OUT",
             "asset":{"id":"a-2","assetTag":"AUD-007","name":"Sennheiser MKE 600","brand":"Sennheiser",
                      "model":"MKE 600","serialNumber":"MKE-4471","imageUrl":null}}
          ],
          "bulkItems":[
            {"id":"bi-1","plannedQuantity":4,"checkedOutQuantity":4,"checkedInQuantity":0,
             "bulkSku":{"id":"sku-1","name":"V-Mount Battery","unit":"battery","imageUrl":null,
                        "trackByNumber":true},
             "unitAllocations":null}
          ],
          "event":{"id":"ev-1","summary":"Volleyball vs Nebraska","sportCode":"VB",
                   "opponent":"Nebraska","isHome":true},
          "events":[{"id":"ev-1","summary":"Volleyball vs Nebraska","sportCode":"VB",
                     "opponent":"Nebraska","isHome":true}],
          "allowedActions":\(allowedActions),
          "updatedAt":"\(iso(-30))",
          "pickupKioskDevice":null
        }}
        """.utf8)
    }

    /// An upcoming booking for one checked-out camera. It begins two hours
    /// after the current due time, leaving useful extension room while still
    /// giving Booking Detail a concrete next-use boundary to explain.
    static var availability: Data {
        Data("""
        {
          "conflicts":[
            {"assetId":"a-5","conflictingBookingId":"bk-conflict","conflictingBookingTitle":"VB vs Milwaukee",
             "conflictingBookingRequesterName":"Erik Role","conflictingBookingKind":"CHECKOUT",
             "conflictingBookingStatus":"OPEN",
             "startsAt":"\(iso(-60))","endsAt":"\(iso(360))"}
          ],"shortages":[],"unavailableAssets":[],
          "upcomingCommitments":[
            {"assetId":"a-1","bookingId":"bk-next","bookingTitle":"Football vs Ohio State",
             "bookingKind":"RESERVATION","kind":"RESERVATION","status":"BOOKED",
             "startsAt":"\(iso(300))","endsAt":"\(iso(480))",
             "requesterName":"Jordan Lee","locationId":"loc-1",
             "locationName":"Camp Randall Creative Desk"}
          ],
          "turnaroundRisks":[],"bulkTurnaroundRisks":[]
        }
        """.utf8)
    }

    private static func listBooking(
        id: String,
        kind: String,
        title: String,
        status: String,
        requesterId: String,
        requesterName: String,
        startsIn: Int,
        endsIn: Int,
        sportCode: String? = nil,
        // Server-owned row actions. Defaults to none so team rows keep showing
        // a student what they may not do; the student's own OPEN checkout gets
        // the pair the checkout matrix in `booking-rules.ts` actually grants.
        allowedActions: [String] = []
    ) -> String {
        let sportJSON = sportCode.map { "\"\($0)\"" } ?? "null"
        let actionsJSON = allowedActions.map { "\"\($0)\"" }.joined(separator: ",")
        return """
        {"id":"\(id)","kind":"\(kind)","title":"\(title)","status":"\(status)",
         "startsAt":"\(studentISO(startsIn))","endsAt":"\(studentISO(endsIn))","notes":null,"refNumber":null,
         "requester":{"id":"\(requesterId)","name":"\(requesterName)","email":null,"avatarUrl":null},
         "location":{"id":"loc-1","name":"Camp Randall Creative Desk"},
         "serializedItems":[],"bulkItems":[],
         "event":{"id":"event-\(id)","summary":"\(title)","sportCode":\(sportJSON),"opponent":null,"isHome":null},
         "allowedActions":[\(actionsJSON)],"updatedAt":"\(studentISO(-15))","pickupKioskDevice":null}
        """
    }

    static func list(for request: URLRequest) -> Data {
        let ownOnly = request.url?.query?.contains("requester_id=fixture-student") == true
        let rows = [
            listBooking(
                id: "bk-student-own", kind: "CHECKOUT", title: "Student camera kit", status: "OPEN",
                requesterId: "fixture-student", requesterName: "Rowan Diaz", startsIn: -120, endsIn: 240,
                sportCode: "VB",
                // OPEN checkout, owned by the caller: edit and extend, no
                // cancel. Matches the checkout state x action matrix in
                // `src/lib/services/booking-rules.ts`.
                allowedActions: ["edit", "extend"]
            ),
            listBooking(
                id: "bk-team-reservation", kind: "RESERVATION", title: "Volleyball photo package", status: "BOOKED",
                requesterId: "u-avery", requesterName: "Avery Nakamura", startsIn: 120, endsIn: 420,
                sportCode: "VB"
            ),
            listBooking(
                id: "bk-team-pickup", kind: "CHECKOUT", title: "Field audio pickup", status: "PENDING_PICKUP",
                requesterId: "u-jordan", requesterName: "Jordan Lee", startsIn: -30, endsIn: 300,
                sportCode: "SOC"
            ),
        ]
        let visibleRows = ownOnly ? [rows[0]] : rows
        return Data("{\"data\":[\(visibleRows.joined(separator: ","))],\"total\":\(visibleRows.count),\"limit\":30,\"offset\":0}".utf8)
    }
}

private enum FixtureAPI {
    static func guideDetail(slug: String) -> Data? {
        let details: [String: (id: String, title: String, type: String, category: String, summary: String, authorId: String, authorName: String, markdown: String)] = [
            "key-contacts": ("g1", "Key contacts", "CONTACTS", "Contacts", "Escalation numbers, vendor contacts, and internal owners.", "u1", "Media Ops", "# Key contacts\n\nCall the media operations lead first for venue, gear-room, or access issues. Escalate urgent event coverage issues to the on-call producer."),
            "camp-randall": ("g2", "Camp Randall building numbers", "BUILDING_NUMBERS", "Building Numbers", "Gate codes, dock access, and elevator notes.", "u2", "Erik Role", "# Camp Randall building numbers\n\nUse the Creative Desk entrance for routine gear movement. Call venue operations before changing dock access or elevator routing."),
            "media-drive": ("g3", "Media Drive overview", "MEDIA_DRIVE", "Media Drive", "Where footage lands and how it is named.", "u1", "Media Ops", "# Media Drive overview\n\nCreate the event folder before ingest, preserve the camera-card source name, and verify the transfer before formatting media."),
            "card-offload-sop": ("g4", "Card offload SOP", "SOP", "SOP", "The standard offload and verification pass after a shoot.", "u3", "Jordan Lee", "# Card offload SOP\n\nCopy the card to the event folder, compare the source and destination counts, then mark the transfer verified before returning the card."),
        ]
        guard let detail = details[slug] else { return nil }
        return Data("""
        { "data": {
          "id": "\(detail.id)", "title": "\(detail.title)", "slug": "\(slug)",
          "type": "\(detail.type)", "category": "\(detail.category)",
          "summary": "\(detail.summary)", "searchText": "\(detail.title)",
          "markdown": "\(detail.markdown.replacingOccurrences(of: "\n", with: "\\n"))",
          "featured": false, "featuredRank": null, "lastVerifiedAt": null,
          "lastVerifiedBy": null, "personalizationReason": "General", "published": true,
          "createdAt": "2026-07-01T12:00:00.000Z", "updatedAt": "2026-08-14T15:04:00.000Z",
          "author": { "id": "\(detail.authorId)", "name": "\(detail.authorName)" }
        } }
        """.utf8)
    }

    static let guides = json("""
    { "data": [
      { "id": "g1", "title": "Key contacts", "slug": "key-contacts", "type": "CONTACTS",
        "category": "Contacts", "summary": "Escalation numbers, vendor contacts, and internal owners.",
        "searchText": "contacts phone escalation", "markdown": "", "featured": true,
        "personalizationReason": "Your area", "published": true, "updatedAt": "2026-08-14T15:04:00.000Z",
        "author": { "id": "u1", "name": "Media Ops" } },
      { "id": "g2", "title": "Camp Randall building numbers", "slug": "camp-randall", "type": "BUILDING_NUMBERS",
        "category": "Building Numbers", "summary": "Gate codes, dock access, and elevator notes.",
        "searchText": "building rooms dock", "markdown": "", "published": true,
        "personalizationReason": "General", "updatedAt": "2026-08-09T18:20:00.000Z",
        "author": { "id": "u2", "name": "Erik Role" } },
      { "id": "g3", "title": "Media Drive overview", "slug": "media-drive", "type": "MEDIA_DRIVE",
        "category": "Media Drive", "summary": "Where footage lands and how it is named.",
        "searchText": "media drive paths naming", "markdown": "", "published": true,
        "personalizationReason": "General", "updatedAt": "2026-08-02T12:00:00.000Z",
        "author": { "id": "u1", "name": "Media Ops" } },
      { "id": "g4", "title": "Card offload SOP", "slug": "card-offload-sop", "type": "SOP",
        "category": "SOP", "summary": "The standard offload and verification pass after a shoot.",
        "searchText": "offload sop cards verify", "markdown": "", "published": true,
        "personalizationReason": "Your area", "updatedAt": "2026-07-28T09:45:00.000Z",
        "author": { "id": "u3", "name": "Jordan Lee" } },
      { "id": "g5", "title": "Wireless audio troubleshooting", "slug": "wireless-audio", "type": "TROUBLESHOOTING",
        "category": "Troubleshooting", "summary": "Dropouts, interference, and battery symptoms.",
        "searchText": "audio wireless dropouts", "markdown": "", "published": false,
        "personalizationReason": "General", "updatedAt": "2026-07-21T22:10:00.000Z",
        "author": { "id": "u2", "name": "Erik Role" } }
    ] }
    """)

    static let users = json("""
    { "total": 5, "limit": 50, "offset": 0, "data": [
      { "id": "u1", "name": "Alex Rivera", "email": "alex.rivera@wisc.edu", "role": "STAFF",
        "title": "Photo Lead", "primaryArea": "PHOTO", "active": true },
      { "id": "u2", "name": "Erik Role", "email": "erik.role@wisc.edu", "role": "ADMIN",
        "title": "Creative Director", "primaryArea": "VIDEO", "active": true },
      { "id": "u3", "name": "Jordan Lee", "email": "jordan.lee@wisc.edu", "role": "STUDENT",
        "gradYear": 2027, "primaryArea": "VIDEO", "active": true },
      { "id": "u4", "name": "Sam Okonkwo", "email": "sam.okonkwo@wisc.edu", "role": "STUDENT",
        "gradYear": 2026, "primaryArea": "PHOTO", "active": true },
      { "id": "u5", "name": "Riley Chen", "email": "riley.chen@wisc.edu", "role": "STUDENT",
        "gradYear": 2025, "primaryArea": "GRAPHICS", "active": false }
    ] }
    """)

    static let licenses = json("""
    { "data": [
      { "id": "l1", "code": "PM-AAAA-1111", "label": "Photo Mechanic Seat 1", "status": "PARTIAL",
        "expiresAt": "2026-12-31T00:00:00.000Z",
        "claims": [ { "id": "c1", "userId": "u3", "claimedAt": "2026-08-16T14:00:00.000Z", "releasedAt": null,
                      "user": { "id": "u3", "name": "Jordan Lee" } } ] },
      { "id": "l2", "code": "PM-BBBB-2222", "label": "Photo Mechanic Seat 2", "status": "AVAILABLE",
        "expiresAt": "2026-12-31T00:00:00.000Z", "claims": [] },
      { "id": "l3", "code": "PM-CCCC-3333", "label": "Photo Mechanic Seat 3", "status": "RETIRED",
        "expiresAt": "2026-01-31T00:00:00.000Z", "claims": [] }
    ] }
    """)

    static let myLicense = json("""
    { "data": { "id": "l1", "claimId": "c1", "code": "PM-AAAA-1111",
                "label": "Photo Mechanic Seat 1", "expiresAt": "2026-12-31T00:00:00.000Z",
                "claimedAt": "2026-08-16T14:00:00.000Z" } }
    """)

    /// Nobody holds a slot, so every claimable row shows its Claim button. Seat
    /// 2 expires inside the 30-day window and Seat 4 has already lapsed, which
    /// is what proves the per-row expiry line still appears once it is worth
    /// acting on. Dates are built relative to launch so the window is exercised
    /// whenever the capture runs, not only in a particular month.
    static var openLicenses: Data {
        json("""
        { "data": [
          { "id": "l1", "code": "PM-AAAA-1111", "label": "Photo Mechanic Seat 1", "status": "AVAILABLE",
            "expiresAt": "\(utcMidnight(daysFromNow: 134))", "claims": [] },
          { "id": "l2", "code": "PM-BBBB-2222", "label": "Photo Mechanic Seat 2", "status": "PARTIAL",
            "expiresAt": "\(utcMidnight(daysFromNow: 12))",
            "claims": [ { "id": "c2", "userId": "u4", "claimedAt": "\(utcMidnight(daysFromNow: -3))", "releasedAt": null,
                          "user": { "id": "u4", "name": "Sam Okonkwo" } } ] },
          { "id": "l3", "code": "PM-CCCC-3333", "label": "Photo Mechanic Seat 3", "status": "CLAIMED",
            "expiresAt": "\(utcMidnight(daysFromNow: 134))",
            "claims": [ { "id": "c3", "userId": "u3", "claimedAt": "\(utcMidnight(daysFromNow: -5))", "releasedAt": null,
                          "user": { "id": "u3", "name": "Jordan Lee" } },
                        { "id": "c4", "userId": "u5", "claimedAt": "\(utcMidnight(daysFromNow: -2))", "releasedAt": null,
                          "user": { "id": "u5", "name": "Riley Chen" } } ] },
          { "id": "l4", "code": "PM-DDDD-4444", "label": "Photo Mechanic Seat 4", "status": "RETIRED",
            "expiresAt": "\(utcMidnight(daysFromNow: -201))", "claims": [] }
        ] }
        """)
    }

    static let noLicense = json("""
    { "data": null }
    """)

    /// Expiries are calendar dates encoded at UTC midnight, matching the
    /// storage contract in `src/lib/license-dates.ts`.
    private static func utcMidnight(daysFromNow days: Int) -> String {
        var utc = Calendar(identifier: .gregorian)
        utc.timeZone = TimeZone(identifier: "UTC")!
        let day = utc.startOfDay(for: Date().addingTimeInterval(Double(days) * 86_400))
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        formatter.timeZone = TimeZone(identifier: "UTC")
        return formatter.string(from: day)
    }

    private static func json(_ literal: String) -> Data {
        Data(literal.utf8)
    }
}

private enum PerformanceFixtures {
    /// Exercises every block kind the guide reader can draw. Shaped after the
    /// templates in src/app/(app)/resources/new/_components/NewGuideClient.tsx.
    static let guideMarkdown = """
    # Key contacts

    Use this Guide for phone numbers, escalation contacts, and internal owners.
    Reach the desk at [av-desk@wisc.edu](mailto:av-desk@wisc.edu) or
    [555-555-5555](tel:+15555555555).

    > [!WARNING]
    > Do not unplug the media drive mid-transfer.

    > [!TIP]
    > Put the owner in the table so people know who fixes stale details.

    ## Emergency

    | Contact | Role | Phone | When to use |
    | --- | :-: | ---: | --- |
    | Building desk | Facilities | `555-555-5555` | Power, doors, or HVAC |
    | Media Ops | On-call staff | `555-000-1111` | Anything that blocks a shoot |

    ## Rig reference

    ![Camera shelf, second bay from the left](https://example.invalid/rig.png)

    ## Steps

    1. Pull the kit and check the case tag.
    2. Confirm the card is formatted.
       - Use the in-camera format, not the desktop one.
    3. Log the checkout at the kiosk.

    - [x] Batteries charged
    - [ ] Lens cloth packed

    ## Copyable values

    ```text
    /Volumes/MediaDrive/2026/Projects
    ```

    ## Walkthrough

    ```embed
    https://youtu.be/dQw4w9WgXcQ
    ```

    Formatting check: **bold**, _italic_, ~~struck~~, and `inline code`.

    ---

    | Field | Value |
    | --- | --- |
    | Maintainer | Media Ops |
    | Last verified | 2026-08-18 |
    """

    static let location = AssetLocation(id: "performance-location", name: "Camp Randall")
    private static let categoryNames = ["Cameras", "Lenses", "Audio", "Lighting"]

    static let assets: [Asset] = (0..<300).map { index in
        let categoryName = categoryNames[index % categoryNames.count]
        return Asset(
            id: String(format: "performance-asset-%03d", index),
            assetTag: String(format: "PERF-%04d", index),
            name: "Performance \(categoryName.dropLast()) \(index)",
            brand: index.isMultiple(of: 2) ? "Sony" : "Canon",
            model: "Model \(index)",
            serialNumber: String(format: "SERIAL-%06d", index),
            imageUrl: nil,
            computedStatus: .available,
            location: location,
            category: AssetCategory(id: categoryName.lowercased(), name: categoryName),
            department: nil,
            activeBooking: nil,
            purchaseDate: nil,
            purchasePrice: nil,
            residualValue: nil,
            isFavorited: index.isMultiple(of: 7)
        )
    }

    static let bulkSkus: [FormBulkSku] = (0..<20).map { index in
        FormBulkSku(
            id: "performance-bulk-\(index)",
            name: "Performance Battery \(index)",
            category: "Batteries",
            unit: "each",
            locationId: location.id,
            binQrCodeValue: nil,
            trackByNumber: index.isMultiple(of: 2),
            categoryName: "Batteries",
            imageUrl: nil,
            currentQuantity: 20,
            availableQuantity: 15
        )
    }
}
// MARK: - Schedule harness

/// Renders the real `ScheduleView` against canned events and shifts. The
/// fixture session is seeded as STAFF so the crew-coverage chips and the
/// past-events filter — both role-gated — are actually exercised.
struct ScheduleHarnessView: View {
    @Environment(SessionStore.self) private var session
    @Environment(AppState.self) private var appState

    var body: some View {
        ScheduleView()
            .onAppear {
                session.currentUser = ScheduleFixtures.staffUser
                // Non-zero so the Trade Board badge is actually on screen when
                // the toolbar is being looked at.
                appState.openTradeCount = 3
            }
    }
}

/// Renders the real `HomeView` against a canned dashboard.
struct HomeHarnessView: View {
    @Environment(SessionStore.self) private var session

    var body: some View {
        HomeView()
            .onAppear { session.currentUser = ScheduleFixtures.staffUser }
    }
}

/// Renders the native profile Scoreboard against a canned season payload. The
/// profile entry point is intentionally bypassed here: the capture should
/// inspect the Scoreboard surface itself without depending on profile data.
struct ScoreboardHarnessView: View {
    @Environment(SessionStore.self) private var session

    var body: some View {
        NavigationStack {
            ScoreboardView(userId: ScoreboardFixtureAPI.userId)
        }
        .onAppear { session.currentUser = ScheduleFixtures.staffUser }
    }
}

/// The Home dashboard payload. Sized on purpose: more gear and shifts than the
/// queue's per-lane caps show, so truncation is visible, and a staff draft with
/// an otherwise-empty personal queue, so the all-clear contradiction reproduces.
enum HomeFixtureAPI {
    // Keep paired captures stable within the hour, matching the Bookings
    // fixture. Normal launches still follow the current day rather than an
    // authored date that eventually becomes historical data.
    private static let referenceDate = Calendar.current.dateInterval(of: .hour, for: .now)?.start ?? .now

    private static func iso(_ minutes: Int) -> String {
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime]
        return formatter.string(from: referenceDate.addingTimeInterval(TimeInterval(minutes * 60)))
    }

    private static func booking(
        _ id: String, _ title: String, _ status: String, _ kind: String,
        startsIn: Int, endsIn: Int, items: Int, overdue: Bool = false
    ) -> String {
        """
        { "id": "\(id)", "kind": "\(kind)", "title": "\(title)", "refNumber": null,
          "eventId": null, "eventIds": [], "linkedEventId": null, "sportCode": null,
          "requesterUserId": "fixture-staff", "requesterName": "Bucky Badger",
          "requesterInitials": "BB", "requesterAvatarUrl": null,
          "locationName": "Media Ops Cage", "startsAt": "\(iso(startsIn))",
          "endsAt": "\(iso(endsIn))", "itemCount": \(items),
          "status": "\(status)", "isOverdue": \(overdue) }
        """
    }

    private static func eventWork(
        _ id: String, summary: String, opponent: String, isHome: Bool,
        startsIn: Int, gear: String?
    ) -> String {
        """
        { "id": "\(id)",
          "event": { "id": "\(id)", "summary": "\(summary)", "startsAt": "\(iso(startsIn))",
                     "endsAt": "\(iso(startsIn + 150))", "allDay": false, "sportCode": "VB",
                     "opponent": "\(opponent)", "isHome": \(isHome), "site": "\(isHome ? "HOME" : "AWAY")",
                     "locationId": "loc-fh", "locationName": "UW Field House" },
          "shift": { "id": "sh-\(id)", "area": "VIDEO", "workerType": "FT",
                     "startsAt": "\(iso(startsIn - 90))", "endsAt": "\(iso(startsIn + 150))",
                     "callStartsAt": null, "callEndsAt": null },
          "gearStatus": "\(gear == nil ? "none" : "reserved")",
          "gearBookings": [\(gear ?? "")],
          "needsGear": \(gear == nil) }
        """
    }

    /// Worked events across the week: tonight with nothing reserved, tomorrow
    /// with its reservation folded into the event row, plus a return.
    static var agendaDashboard: Data {
        let linkedGear = booking("r-ev2", "Volleyball at Minnesota kit", "BOOKED", "RESERVATION",
                                 startsIn: 1_380, endsIn: 1_800, items: 5)
            .replacingOccurrences(of: "\"linkedEventId\": null", with: "\"linkedEventId\": \"ev2\"")
        let returnSoon = booking("co1", "Hockey road audio kit", "OPEN", "CHECKOUT",
                                 startsIn: -1_440, endsIn: 2_880, items: 4)
        let work = [
            eventWork("ev1", summary: "Volleyball vs Nebraska", opponent: "Nebraska", isHome: true,
                      startsIn: 120, gear: nil),
            eventWork("ev2", summary: "Volleyball at Minnesota", opponent: "Minnesota", isHome: false,
                      startsIn: 1_560, gear: linkedGear),
            eventWork("ev3", summary: "Volleyball vs Purdue", opponent: "Purdue", isHome: true,
                      startsIn: 4_440, gear: nil),
        ].joined(separator: ",")
        return Data("""
        { "data": {
          "role": "STAFF",
          "stats": { "checkedOut": 1, "overdue": 0, "reserved": 1, "dueToday": 0 },
          "myCheckouts": { "total": 1, "overdue": 0, "items": [\(returnSoon)] },
          "teamCheckouts": { "total": 0, "overdue": 0, "items": [] },
          "teamReservations": { "total": 0, "items": [] },
          "pendingPickups": { "total": 0, "items": [] },
          "myReservations": [\(linkedGear)],
          "overdueCount": 0,
          "overdueItems": [],
          "myShifts": [],
          "upcomingEvents": [],
          "drafts": [],
          "flaggedItems": [],
          "lostBulkUnits": [],
          "myEventWork": [\(work)]
        } }
        """.utf8)
    }

    /// Nothing personal outstanding, one staff draft waiting.
    static var allClearDashboard: Data {
        Data("""
        { "data": {
          "role": "STAFF",
          "stats": { "checkedOut": 0, "overdue": 0, "reserved": 0, "dueToday": 0 },
          "myCheckouts": { "total": 0, "overdue": 0, "items": [] },
          "teamCheckouts": { "total": 0, "overdue": 0, "items": [] },
          "teamReservations": { "total": 0, "items": [] },
          "pendingPickups": { "total": 0, "items": [] },
          "myReservations": [], "overdueCount": 0, "overdueItems": [],
          "myShifts": [], "upcomingEvents": [],
          "drafts": [ { "id": "d1", "kind": "RESERVATION", "title": "Hockey B-roll kit",
                        "itemCount": 6, "updatedAt": "\(iso(-90))" } ],
          "flaggedItems": [], "lostBulkUnits": [], "myEventWork": []
        } }
        """.utf8)
    }

    static var dashboard: Data {
        let overdue = [
            booking("od1", "Volleyball baseline kit", "OPEN", "CHECKOUT",
                    startsIn: -300, endsIn: -60, items: 4, overdue: true),
        ]
        let dueToday = [
            booking("dt1", "Football fall camp — video", "OPEN", "CHECKOUT",
                    startsIn: -120, endsIn: 45, items: 6),
            booking("dt2", "Women’s soccer portraits", "OPEN", "CHECKOUT",
                    startsIn: -90, endsIn: 120, items: 3),
        ]
        let upcoming = [
            booking("up1", "Ohio State photo kit", "BOOKED", "RESERVATION",
                    startsIn: 1_440, endsIn: 1_680, items: 5),
            booking("up2", "Hockey road audio kit", "BOOKED", "RESERVATION",
                    startsIn: 2_880, endsIn: 3_240, items: 4),
            booking("up3", "Kohl Center studio shoot", "BOOKED", "RESERVATION",
                    startsIn: 4_320, endsIn: 4_500, items: 7),
        ]
        let checkouts = (overdue + dueToday + upcoming).joined(separator: ",")
        return Data("""
        { "data": {
          "role": "STAFF",
          "stats": { "checkedOut": 3, "overdue": 1, "reserved": 3, "dueToday": 2 },
          "myCheckouts": { "total": 6, "overdue": 1, "items": [\(checkouts)] },
          "teamCheckouts": { "total": 0, "overdue": 0, "items": [] },
          "teamReservations": { "total": 0, "items": [] },
          "pendingPickups": { "total": 0, "items": [] },
          "myReservations": [],
          "overdueCount": 1,
          "overdueItems": [],
          "myShifts": [],
          "upcomingEvents": [],
          "drafts": [ { "id": "d1", "kind": "RESERVATION", "title": "Hockey B-roll kit",
                        "itemCount": 6, "updatedAt": "\(iso(-90))" } ],
          "flaggedItems": [],
          "lostBulkUnits": [],
          "myEventWork": []
        } }
        """.utf8)
    }
}

/// A worked season for the Scoreboard capture. The route narrows its own
/// breakdowns and game list by the sport and result filters while events worked
/// stays a season-wide count, so this fixture answers the query rather than
    /// returning one canned payload -- a fixture that ignored the query would hide
/// the exact filtering behaviour a capture exists to show.
enum ScoreboardFixtureAPI {
    static let userId = "fixture-staff"

    /// Counted over the whole season by the server, filters or not. Deliberately
    /// larger than the resolved-game count: most worked events never get a result.
    private static let eventsWorked = 38

    private struct Game {
        let id: String
        let startsAt: String
        let result: String
        let sportCode: String
        let sportLabel: String
        let opponent: String
        let site: String
        let venue: String
        let areas: [String]
    }

    /// A full season, newest first, in the order the route returns. Sized and
    /// shaped for what the screen has to survive: four months so the game list
    /// groups, more opponents and venues than a table shows at once, 27 games so
    /// the first page does not reach the end, and Men's Basketball winless on
    /// purpose -- a sport that vanishes from a wins-only read is what proves a
    /// filter menu is reading its options from the wrong place.
    private static let games: [Game] = [
        Game(id: "score-0", startsAt: "2026-12-10T01:00:00.000Z", result: "TIE", sportCode: "SOC",
             sportLabel: "Soccer", opponent: "Marquette", site: "HOME",
             venue: "McClimon Complex", areas: ["VIDEO"]),
        Game(id: "score-1", startsAt: "2026-12-05T18:00:00.000Z", result: "WIN", sportCode: "FB",
             sportLabel: "Football", opponent: "Iowa", site: "HOME",
             venue: "Camp Randall Stadium", areas: ["VIDEO", "PHOTO"]),
        Game(id: "score-2", startsAt: "2026-11-28T19:00:00.000Z", result: "WIN", sportCode: "WBB",
             sportLabel: "Women's Basketball", opponent: "Michigan", site: "HOME",
             venue: "Kohl Center", areas: ["PHOTO"]),
        Game(id: "score-3", startsAt: "2026-11-25T01:00:00.000Z", result: "LOSS", sportCode: "MBB",
             sportLabel: "Men's Basketball", opponent: "Marquette", site: "NEUTRAL",
             venue: "Fiserv Forum", areas: ["VIDEO", "SOCIAL"]),
        Game(id: "score-4", startsAt: "2026-11-21T19:30:00.000Z", result: "LOSS", sportCode: "FB",
             sportLabel: "Football", opponent: "Nebraska", site: "AWAY",
             venue: "Memorial Stadium", areas: ["VIDEO"]),
        Game(id: "score-5", startsAt: "2026-11-18T00:00:00.000Z", result: "WIN", sportCode: "VB",
             sportLabel: "Volleyball", opponent: "Purdue", site: "HOME",
             venue: "UW Field House", areas: ["VIDEO"]),
        Game(id: "score-6", startsAt: "2026-11-14T17:00:00.000Z", result: "WIN", sportCode: "FB",
             sportLabel: "Football", opponent: "Ohio State", site: "HOME",
             venue: "Camp Randall Stadium", areas: ["LIVE_PRODUCTION"]),
        Game(id: "score-7", startsAt: "2026-11-11T23:00:00.000Z", result: "LOSS", sportCode: "WBB",
             sportLabel: "Women's Basketball", opponent: "Indiana", site: "AWAY",
             venue: "Assembly Hall", areas: ["SOCIAL"]),
        Game(id: "score-8", startsAt: "2026-11-07T20:00:00.000Z", result: "LOSS", sportCode: "VB",
             sportLabel: "Volleyball", opponent: "Nebraska", site: "AWAY",
             venue: "Devaney Center", areas: ["VIDEO"]),
        Game(id: "score-9", startsAt: "2026-11-04T22:00:00.000Z", result: "WIN", sportCode: "SOC",
             sportLabel: "Soccer", opponent: "Minnesota", site: "HOME",
             venue: "McClimon Complex", areas: ["PHOTO", "GRAPHICS"]),
        Game(id: "score-10", startsAt: "2026-10-31T18:00:00.000Z", result: "LOSS", sportCode: "VB",
             sportLabel: "Volleyball", opponent: "Ohio State", site: "AWAY",
             venue: "Covelli Center", areas: ["VIDEO", "GRAPHICS"]),
        Game(id: "score-11", startsAt: "2026-10-28T00:30:00.000Z", result: "LOSS", sportCode: "MBB",
             sportLabel: "Men's Basketball", opponent: "Iowa", site: "HOME",
             venue: "Kohl Center", areas: ["VIDEO"]),
        Game(id: "score-12", startsAt: "2026-10-24T16:00:00.000Z", result: "WIN", sportCode: "FB",
             sportLabel: "Football", opponent: "Minnesota", site: "HOME",
             venue: "Camp Randall Stadium", areas: ["VIDEO"]),
        Game(id: "score-13", startsAt: "2026-10-21T23:00:00.000Z", result: "WIN", sportCode: "WBB",
             sportLabel: "Women's Basketball", opponent: "Purdue", site: "HOME",
             venue: "Kohl Center", areas: ["PHOTO"]),
        Game(id: "score-14", startsAt: "2026-10-17T18:00:00.000Z", result: "LOSS", sportCode: "SOC",
             sportLabel: "Soccer", opponent: "Michigan", site: "AWAY",
             venue: "U-M Soccer Stadium", areas: ["PHOTO"]),
        Game(id: "score-15", startsAt: "2026-10-14T00:00:00.000Z", result: "WIN", sportCode: "VB",
             sportLabel: "Volleyball", opponent: "Michigan", site: "HOME",
             venue: "UW Field House", areas: ["VIDEO", "SOCIAL"]),
        Game(id: "score-16", startsAt: "2026-10-10T19:00:00.000Z", result: "LOSS", sportCode: "SOC",
             sportLabel: "Soccer", opponent: "Illinois", site: "AWAY",
             venue: "Demirjian Park", areas: ["PHOTO"]),
        Game(id: "score-17", startsAt: "2026-10-07T23:30:00.000Z", result: "LOSS", sportCode: "WBB",
             sportLabel: "Women's Basketball", opponent: "Michigan State", site: "AWAY",
             venue: "Breslin Center", areas: ["SOCIAL"]),
        Game(id: "score-18", startsAt: "2026-10-03T16:00:00.000Z", result: "WIN", sportCode: "FB",
             sportLabel: "Football", opponent: "Purdue", site: "HOME",
             venue: "Camp Randall Stadium", areas: ["VIDEO", "PHOTO"]),
        Game(id: "score-19", startsAt: "2026-09-30T00:00:00.000Z", result: "LOSS", sportCode: "VB",
             sportLabel: "Volleyball", opponent: "Michigan State", site: "AWAY",
             venue: "Jenison Field House", areas: ["VIDEO"]),
        Game(id: "score-20", startsAt: "2026-09-26T22:00:00.000Z", result: "WIN", sportCode: "SOC",
             sportLabel: "Soccer", opponent: "Northwestern", site: "HOME",
             venue: "McClimon Complex", areas: ["GRAPHICS"]),
        Game(id: "score-21", startsAt: "2026-09-23T00:00:00.000Z", result: "LOSS", sportCode: "MBB",
             sportLabel: "Men's Basketball", opponent: "Northwestern", site: "HOME",
             venue: "Kohl Center", areas: ["VIDEO"]),
        Game(id: "score-22", startsAt: "2026-09-19T19:00:00.000Z", result: "LOSS", sportCode: "FB",
             sportLabel: "Football", opponent: "Michigan", site: "AWAY",
             venue: "Michigan Stadium", areas: ["VIDEO", "LIVE_PRODUCTION"]),
        Game(id: "score-23", startsAt: "2026-09-16T00:00:00.000Z", result: "WIN", sportCode: "VB",
             sportLabel: "Volleyball", opponent: "Indiana", site: "HOME",
             venue: "UW Field House", areas: ["VIDEO"]),
        Game(id: "score-24", startsAt: "2026-09-12T16:00:00.000Z", result: "WIN", sportCode: "FB",
             sportLabel: "Football", opponent: "Indiana", site: "HOME",
             venue: "Camp Randall Stadium", areas: ["VIDEO", "PHOTO"]),
        Game(id: "score-25", startsAt: "2026-09-09T23:00:00.000Z", result: "WIN", sportCode: "SOC",
             sportLabel: "Soccer", opponent: "Purdue", site: "AWAY",
             venue: "Folk Field", areas: ["PHOTO"]),
        Game(id: "score-26", startsAt: "2026-09-05T16:00:00.000Z", result: "WIN", sportCode: "FB",
             sportLabel: "Football", opponent: "Marquette", site: "HOME",
             venue: "Camp Randall Stadium", areas: ["VIDEO"]),
    ]

    static func scoreboard(for request: URLRequest) -> Data {
        let query = URLComponents(url: request.url!, resolvingAgainstBaseURL: false)?.queryItems ?? []
        func value(_ name: String) -> String? {
            guard let found = query.first(where: { $0.name == name })?.value, !found.isEmpty else { return nil }
            return found
        }
        let sportCode = value("sportCode")
        let result = value("result")
        let limit = value("limit").flatMap(Int.init) ?? 25
        let offset = value("offset").flatMap(Int.init) ?? 0

        let matched = games.filter { game in
            (sportCode == nil || game.sportCode == sportCode) && (result == nil || game.result == result)
        }
        let wins = matched.filter { $0.result == "WIN" }.count
        let losses = matched.filter { $0.result == "LOSS" }.count
        let ties = matched.filter { $0.result == "TIE" }.count
        let page = Array(matched.dropFirst(offset).prefix(limit))
        let hasMore = matched.count > offset + limit

        return Data("""
        { "data": {
          "scope": {
            "key": "2026-27",
            "label": "2026–27 season",
            "startsAt": "2026-07-01T00:00:00.000Z",
            "endsAt": "2027-07-01T00:00:00.000Z",
            "timeZone": "America/Chicago"
          },
          "summary": {
            "eventsWorked": \(eventsWorked),
            "wins": \(wins),
            "losses": \(losses),
            "ties": \(ties),
            "games": \(matched.count),
            "winRate": \(rate(wins: wins, losses: losses, ties: ties))
          },
          "bySport": [\(buckets(matched) { ($0.sportCode, $0.sportLabel) })],
          "byOpponent": [\(buckets(matched) { ($0.opponent, $0.opponent) })],
          "bySite": [\(buckets(matched, order: ["HOME", "AWAY", "NEUTRAL"]) { ($0.site, siteLabel($0.site)) })],
          "byVenue": [\(buckets(matched) { ($0.venue, $0.venue) })],
          "events": [\(page.map(eventJSON).joined(separator: ","))],
          "nextCursor": \(hasMore ? "\"\(offset + limit)\"" : "null")
        } }
        """.utf8)
    }

    private static func siteLabel(_ site: String) -> String {
        switch site {
        case "HOME": "Home"
        case "AWAY": "Away"
        default: "Neutral"
        }
    }

    private static func rate(wins: Int, losses: Int, ties: Int) -> String {
        let games = wins + losses + ties
        guard games > 0 else { return "null" }
        return "\(((Double(wins) + Double(ties) / 2) / Double(games) * 1000).rounded() / 10)"
    }

    /// Same shape the route builds: most games first, then label, except sites,
    /// which keep their fixed Home/Away/Neutral order.
    private static func buckets(
        _ games: [Game],
        order: [String] = [],
        dimension: (Game) -> (key: String, label: String)
    ) -> String {
        var labels: [String: String] = [:]
        var wins: [String: Int] = [:]
        var losses: [String: Int] = [:]
        var ties: [String: Int] = [:]
        var keys: [String] = []
        for game in games {
            let bucket = dimension(game)
            if labels[bucket.key] == nil {
                labels[bucket.key] = bucket.label
                keys.append(bucket.key)
            }
            if game.result == "WIN" {
                wins[bucket.key, default: 0] += 1
            } else if game.result == "LOSS" {
                losses[bucket.key, default: 0] += 1
            } else {
                ties[bucket.key, default: 0] += 1
            }
        }
        let sorted = keys.sorted { first, second in
            if !order.isEmpty {
                return (order.firstIndex(of: first) ?? order.count) < (order.firstIndex(of: second) ?? order.count)
            }
            let firstGames = (wins[first] ?? 0) + (losses[first] ?? 0) + (ties[first] ?? 0)
            let secondGames = (wins[second] ?? 0) + (losses[second] ?? 0) + (ties[second] ?? 0)
            if firstGames != secondGames { return firstGames > secondGames }
            return (labels[first] ?? first) < (labels[second] ?? second)
        }
        return sorted.map { key in
            let won = wins[key] ?? 0
            let lost = losses[key] ?? 0
            let tied = ties[key] ?? 0
            return """
            {"key":"\(key)","label":"\(labels[key] ?? key)","wins":\(won),"losses":\(lost),\
            "ties":\(tied),"games":\(won + lost + tied),"winRate":\(rate(wins: won, losses: lost, ties: tied))}
            """
        }.joined(separator: ",")
    }

    private static func eventJSON(_ game: Game) -> String {
        let areas = game.areas.map { "\"\($0)\"" }.joined(separator: ",")
        return """
        {"id":"\(game.id)","startsAt":"\(game.startsAt)","allDay":false,"result":"\(game.result)",\
        "sportCode":"\(game.sportCode)","sportLabel":"\(game.sportLabel)","opponent":"\(game.opponent)",\
        "site":"\(game.site)","venue":"\(game.venue)","shiftAreas":[\(areas)]}
        """
    }
}

/// The current user's Profile against canned payloads. The Scoreboard entry is
/// a row in a stack of cards, so it can only be reviewed next to the Next Up
/// card above it and the badge shelf below it.
struct ProfileHarnessView: View {
    @Environment(SessionStore.self) private var session
    @State private var seeded = false

    var body: some View {
        // Profile loads its own detail and badges from `session.currentUser` in
        // a `.task`, which starts alongside `onAppear` -- seeding the session
        // there raced the load and left the screen with no identity to fetch.
        // The placeholder has to be a real view: an empty `Group` never appears,
        // so the seeding never ran and the screen stayed blank.
        ZStack {
            Color(.systemGroupedBackground).ignoresSafeArea()
            if seeded { ProfileView() }
        }
        .onAppear {
            session.currentUser = ScheduleFixtures.staffUser
            seeded = true
        }
    }
}

enum ProfileFixtureAPI {
    static let userDetail = Data("""
    { "data": {
      "id": "\(ScoreboardFixtureAPI.userId)",
      "name": "Jordan Lee",
      "email": "jordan.lee@wisc.edu",
      "role": "STAFF",
      "locationId": "loc-1",
      "location": "Camp Randall Stadium",
      "phone": "608-555-0134",
      "primaryArea": "LIVE_PRODUCTION",
      "avatarUrl": null,
      "active": true,
      "createdAt": "2024-08-19T14:00:00.000Z",
      "title": "Production Coordinator",
      "gradYear": null,
      "studentYearOverride": null
    } }
    """.utf8)

    /// Two earned badges and one in progress: enough for the shelf to render as
    /// it does in production without turning this fixture into a catalogue.
    static let badgeProfile = Data("""
    { "data": {
      "userId": "\(ScoreboardFixtureAPI.userId)",
      "peerVisible": true,
      "earnedCount": 2,
      "totalCount": 48,
      "disabled": false,
      "streaks": [],
      "badges": [
        \(badge(key: "first_shift", name: "First Shift", icon: "flag.checkered", earned: true,
                awardedAt: "2026-09-06T02:00:00.000Z")),
        \(badge(key: "camp_randall_regular", name: "Camp Randall Regular", icon: "building.columns", earned: true,
                awardedAt: "2026-11-15T02:00:00.000Z")),
        \(badge(key: "road_warrior", name: "Road Warrior", icon: "car.fill", earned: false, awardedAt: nil))
      ]
    } }
    """.utf8)

    private static func badge(
        key: String,
        name: String,
        icon: String,
        earned: Bool,
        awardedAt: String?
    ) -> String {
        let awarded = awardedAt.map { "\"\($0)\"" } ?? "null"
        return """
        {"id":"badge-\(key)","key":"\(key)","name":"\(name)","description":"Fixture badge for capture.",
         "icon":"\(icon)","category":"MILESTONE","kind":"AUTOMATIC","trigger":"shift:completed","threshold":1,
         "ruleKey":"\(key)","active":true,"sortOrder":1,"earned":\(earned),"awardedAt":\(awarded),
         "source":null,"note":null,"awardedByName":null,"progressCurrent":\(earned ? 1 : 0),"progressTarget":1,
         "servedRarity":null}
        """
    }
}

private enum PreviewChromeFixtures {
    private static let previewExpiresAt = Date.now.timeIntervalSince1970 * 1_000 + 7_200_000

    static let previewUser = CurrentUser(
        id: "fixture-admin",
        name: "Erik Role",
        email: "erik.role@wisc.edu",
        role: "STUDENT",
        affiliation: nil,
        collaboratorProfile: nil,
        capabilities: [],
        collaboratorPolicy: nil,
        staffingType: "ST",
        avatarUrl: nil,
        forcePasswordChange: false,
        preview: RolePreviewInfo(role: "STUDENT", expiresAt: previewExpiresAt)
    )

    static var me: Data {
        Data("""
        { "user": { "id": "fixture-admin", "name": "Erik Role",
                    "email": "erik.role@wisc.edu", "role": "STUDENT",
                    "affiliation": null, "collaboratorProfile": null,
                    "capabilities": [], "collaboratorPolicy": null,
                    "staffingType": "ST", "avatarUrl": null,
                    "forcePasswordChange": false,
                    "preview": { "actualRole": "ADMIN", "role": "STUDENT",
                                 "readOnly": true, "expiresAt": \(previewExpiresAt) } } }
        """.utf8)
    }
}

private enum ScheduleFixtures {
    static let staffUser = CurrentUser(
        id: "fixture-staff",
        name: "Bucky Badger",
        email: "bucky.badger@wisc.edu",
        role: "STAFF",
        affiliation: nil,
        collaboratorProfile: nil,
        capabilities: [],
        collaboratorPolicy: nil,
        staffingType: "ST",
        avatarUrl: nil,
        forcePasswordChange: false
    )
}

/// Builds the schedule payloads relative to the current day, so the "Today"
/// and "Tomorrow" headers and the relative-time affordances render the way a
/// real session would rather than freezing at an authored date.
enum ScheduleFixtureAPI {
    private static func isoString(_ date: Date) -> String {
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime]
        return formatter.string(from: date)
    }

    private static func at(_ dayOffset: Int, _ hour: Int, _ minute: Int = 0) -> String {
        let calendar = Calendar.current
        let day = calendar.date(byAdding: .day, value: dayOffset, to: Date.now) ?? .now
        let date = calendar.date(
            bySettingHour: hour,
            minute: minute,
            second: 0,
            of: calendar.startOfDay(for: day)
        ) ?? day
        return isoString(date)
    }

    /// Minutes from launch, snapped to a 5-minute mark so the rendered clock
    /// time still reads like a real call time.
    private static func fromNow(_ minutes: Int) -> String {
        let raw = Date.now.addingTimeInterval(TimeInterval(minutes * 60))
        let snapped = raw.timeIntervalSinceReferenceDate
        let rounded = (snapped / 300).rounded() * 300
        return isoString(Date(timeIntervalSinceReferenceDate: rounded))
    }

    /// All-day events encode a bare calendar date at UTC midnight.
    private static func allDay(_ dayOffset: Int) -> String {
        let calendar = Calendar.current
        let day = calendar.date(byAdding: .day, value: dayOffset, to: Date.now) ?? .now
        var utc = Calendar(identifier: .gregorian)
        utc.timeZone = TimeZone(identifier: "UTC") ?? .gmt
        let parts = calendar.dateComponents([.year, .month, .day], from: day)
        let date = utc.date(from: DateComponents(
            year: parts.year, month: parts.month, day: parts.day, hour: 0, minute: 0, second: 0
        )) ?? day
        return isoString(date)
    }

    /// A foreground refresh calls `/api/me`. Without this the fixture session
    /// 401s against the real host and signs itself out mid-screenshot.
    static var me: Data {
        Data("""
        { "user": { "id": "fixture-staff", "name": "Bucky Badger",
                    "email": "bucky.badger@wisc.edu", "role": "STAFF",
                    "affiliation": null, "collaboratorProfile": null,
                    "capabilities": [], "collaboratorPolicy": null,
                    "staffingType": "ST", "avatarUrl": null,
                    "forcePasswordChange": false } }
        """.utf8)
    }

    static func calendarEvents(for request: URLRequest) -> Data {
        windowed(calendarEvents, request: request, eventOf: { $0 })
    }

    static func myShifts(for request: URLRequest) -> Data {
        windowed(myShifts, request: request, eventOf: { $0["event"] as? [String: Any] })
    }

    /// Applies the Schedule's `startDate`/`endDate` window the way the routes
    /// do (the event ends after the start and starts by the end), so scrolling
    /// into earlier or later weeks loads different rows in the harness too.
    private static func windowed(
        _ data: Data,
        request: URLRequest,
        eventOf: ([String: Any]) -> [String: Any]?
    ) -> Data {
        let items = URLComponents(url: request.url!, resolvingAgainstBaseURL: false)?.queryItems ?? []
        let parser = ISO8601DateFormatter()
        func date(_ name: String) -> Date? {
            items.first(where: { $0.name == name })?.value.flatMap { parser.date(from: $0) }
        }
        let start = date("startDate")
        let end = date("endDate")
        let eventId = items.first(where: { $0.name == "eventId" })?.value
        if let eventId,
           let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
           let rows = object["data"] as? [[String: Any]] {
            let kept = rows.filter { ($0["id"] as? String) == eventId }
            return (try? JSONSerialization.data(withJSONObject: ["data": kept, "total": kept.count])) ?? data
        }
        guard start != nil || end != nil,
              let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let rows = object["data"] as? [[String: Any]] else { return data }
        let fractional = ISO8601DateFormatter()
        fractional.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        func parse(_ value: Any?) -> Date? {
            guard let text = value as? String else { return nil }
            return parser.date(from: text) ?? fractional.date(from: text)
        }
        let kept = rows.filter { row in
            guard let event = eventOf(row),
                  let startsAt = parse(event["startsAt"]),
                  let endsAt = parse(event["endsAt"]) else { return false }
            if let start, endsAt <= start { return false }
            if let end, startsAt > end { return false }
            return true
        }
        let payload: [String: Any] = ["data": kept, "total": kept.count]
        return (try? JSONSerialization.data(withJSONObject: payload)) ?? data
    }

    static var calendarEvents: Data {
        let events = """
        [
          { "id": "e20", "summary": "Men's Hockey vs Michigan", "startsAt": "\(at(-20, 19))",
            "endsAt": "\(at(-20, 22))", "allDay": false, "status": "CONFIRMED",
            "sportCode": "MHKY", "opponent": "Michigan", "isHome": true,
            "location": { "id": "loc-kc", "name": "Kohl Center" },
            "coverage": { "total": 4, "filled": 4, "percentage": 100 } },
          { "id": "e21", "summary": "Wrestling vs Iowa", "startsAt": "\(at(-9, 19))",
            "endsAt": "\(at(-9, 21))", "allDay": false, "status": "CONFIRMED",
            "sportCode": "WRES", "opponent": "Iowa", "isHome": true,
            "location": { "id": "loc-fh", "name": "UW Field House" },
            "coverage": { "total": 3, "filled": 3, "percentage": 100 } },
          { "id": "e22", "summary": "Football at Northwestern", "startsAt": "\(at(12, 11))",
            "endsAt": "\(at(12, 14, 30))", "allDay": false, "status": "CONFIRMED",
            "sportCode": "FB", "opponent": "Northwestern", "isHome": false,
            "location": null, "rawLocationText": "Ryan Field",
            "coverage": { "total": 8, "filled": 5, "percentage": 63 } },
          { "id": "e23", "summary": "Men's Basketball vs Marquette", "startsAt": "\(at(52, 19))",
            "endsAt": "\(at(52, 21, 30))", "allDay": false, "status": "CONFIRMED",
            "sportCode": "MBB", "opponent": "Marquette", "isHome": true,
            "location": { "id": "loc-kc", "name": "Kohl Center" },
            "coverage": { "total": 6, "filled": 2, "percentage": 33 } },
          { "id": "e1", "summary": "Volleyball vs Nebraska", "startsAt": "\(at(0, 11))",
            "endsAt": "\(at(0, 14))", "allDay": false, "status": "CONFIRMED",
            "sportCode": "VB", "opponent": "Nebraska", "isHome": true,
            "location": { "id": "loc-fh", "name": "UW Field House" },
            "coverage": { "total": 6, "filled": 4, "percentage": 67 },
            "combinedEvents": [{ "id": "e1b", "summary": "Volleyball vs Nebraska (TV)",
              "startsAt": "\(at(0, 11))", "endsAt": "\(at(0, 14))", "allDay": false,
              "sportCode": "VB", "opponent": "Nebraska" }] },
          { "id": "e2", "summary": "Men's Hockey at Minnesota", "startsAt": "\(at(0, 16))",
            "endsAt": "\(at(0, 19))", "allDay": false, "status": "CONFIRMED",
            "sportCode": "MHKY", "opponent": "Minnesota", "isHome": false,
            "location": null, "rawLocationText": "3M Arena at Mariucci",
            "coverage": { "total": 3, "filled": 3, "percentage": 100 } },
          { "id": "e3", "summary": "Women's Basketball vs Iowa", "startsAt": "\(at(0, 19, 30))",
            "endsAt": "\(at(0, 22))", "allDay": false, "status": "CONFIRMED",
            "sportCode": "WBB", "opponent": "Iowa", "isHome": true,
            "location": { "id": "loc-kc", "name": "Kohl Center" },
            "coverage": { "total": 5, "filled": 2, "percentage": 40 } },
          { "id": "e10", "summary": "Men's Basketball vs Duke - Rivalry Night", "startsAt": "\(at(0, 20, 30))",
            "endsAt": "\(at(0, 23))", "allDay": false, "status": "CONFIRMED",
            "sportCode": "MBB", "opponent": "Duke - Rivalry Night", "isHome": true, "site": "NEUTRAL",
            "location": null,
            "coverage": { "total": 4, "filled": 4, "percentage": 100 } },
          { "id": "e9", "summary": "Women's Soccer vs Penn State", "startsAt": "\(fromNow(-45))",
            "endsAt": "\(fromNow(75))", "allDay": false, "status": "CONFIRMED",
            "sportCode": "WSOC", "opponent": "Penn State", "isHome": true,
            "location": { "id": "loc-mc", "name": "McClimon Complex" },
            "coverage": { "total": 4, "filled": 3, "percentage": 75 } },
          { "id": "e4", "summary": "Football vs Ohio State", "startsAt": "\(at(1, 12))",
            "endsAt": "\(at(1, 15, 30))", "allDay": false, "status": "CONFIRMED",
            "sportCode": "FB", "opponent": "Ohio State", "isHome": true,
            "location": { "id": "loc-cr", "name": "Camp Randall Stadium" },
            "coverage": { "total": 12, "filled": 8, "percentage": 67 } },
          { "id": "e5", "summary": "Men's Soccer vs Indiana", "startsAt": "\(at(1, 18))",
            "endsAt": "\(at(1, 20))", "allDay": false, "status": "CONFIRMED",
            "sportCode": "MSOC", "opponent": "Indiana", "isHome": true,
            "location": { "id": "loc-mc", "name": "McClimon Complex" },
            "coverage": { "total": 4, "filled": 1, "percentage": 25 } },
          { "id": "e6", "summary": "Big Ten Swimming Championships", "startsAt": "\(allDay(2))",
            "endsAt": "\(allDay(4))", "allDay": true, "status": "CONFIRMED",
            "sportCode": "WSWIM", "opponent": null, "isHome": null,
            "location": { "id": "loc-sc", "name": "Soderholm Family Aquatic Center" },
            "coverage": { "total": 9, "filled": 5, "percentage": 56 } },
          { "id": "e7", "summary": "Softball at Michigan", "startsAt": "\(at(3, 9))",
            "endsAt": "\(at(3, 11))", "allDay": false, "status": "CONFIRMED",
            "sportCode": "SB", "opponent": "Michigan", "isHome": false,
            "location": null, "rawLocationText": "Alumni Field",
            "coverage": { "total": 2, "filled": 0, "percentage": 0 } },
          { "id": "e8", "summary": "Equipment inventory audit", "startsAt": "\(at(4, 13))",
            "endsAt": "\(at(4, 16))", "allDay": false, "status": "CONFIRMED",
            "sportCode": null, "opponent": null, "isHome": null,
            "location": { "id": "loc-cage", "name": "Media Ops Cage" },
            "coverage": { "total": 3, "filled": 3, "percentage": 100 } }
        ]
        """
        return Data("{ \"data\": \(events), \"total\": 13 }".utf8)
    }

    /// Event detail reads the crew roster from here. Keyed off the requested
    /// `eventId` so tapping different rows does not show one canned crew.
    static func shiftGroups(for request: URLRequest) -> Data {
        let eventId = URLComponents(url: request.url!, resolvingAgainstBaseURL: false)?
            .queryItems?.first(where: { $0.name == "eventId" })?.value ?? "e1"
        guard let plan = crewPlans[eventId] else {
            return Data(#"{ "data": [], "total": 0 }"#.utf8)
        }
        let shifts = plan.shifts.enumerated().map { index, shift -> String in
            let assignment = shift.worker.map { worker in
                """
                { "id": "a-\(eventId)-\(index)", "status": "\(shift.status)",
                  "user": { "id": "u-\(index)", "name": "\(worker)",
                            "primaryArea": "\(shift.area)", "avatarUrl": null,
                            "role": "STUDENT", "staffingType": "ST" } }
                """
            }
            return """
            { "id": "s-\(eventId)-\(index)", "area": "\(shift.area)", "workerType": "ST",
              "startsAt": "\(plan.startsAt)", "endsAt": "\(plan.endsAt)",
              "callStartsAt": "\(plan.callStartsAt)", "callEndsAt": null, "notes": null,
              "assignments": [\(assignment ?? "")] }
            """
        }.joined(separator: ",\n")
        let filled = plan.shifts.filter { $0.worker != nil }.count
        let total = plan.shifts.count
        let percentage = total == 0 ? 0 : Int((Double(filled) / Double(total) * 100).rounded())
        return Data("""
        { "data": [ { "id": "sg-\(eventId)", "eventId": "\(eventId)", "notes": null,
            "event": { "id": "\(eventId)", "summary": "\(plan.summary)",
                       "startsAt": "\(plan.startsAt)", "endsAt": "\(plan.endsAt)",
                       "sportCode": "\(plan.sportCode)", "isHome": true,
                       "opponent": "\(plan.opponent)", "locationId": "\(plan.locationId)" },
            "shifts": [\(shifts)],
            "coverage": { "total": \(total), "filled": \(filled), "percentage": \(percentage) } } ],
          "total": 1 }
        """.utf8)
    }

    private struct CrewSlot {
        let area: String
        let worker: String?
        var status: String { worker == nil ? "OPEN" : "CONFIRMED" }
    }

    private struct CrewPlan {
        let summary: String
        let sportCode: String
        let opponent: String
        let locationId: String
        let startsAt: String
        let endsAt: String
        let callStartsAt: String
        let shifts: [CrewSlot]
    }

    /// Two crews worth looking at: the event the fixture user works, and the
    /// live one, so detail can be captured in both temporal states.
    private static var crewPlans: [String: CrewPlan] {
        [
            "e1": CrewPlan(
                summary: "Volleyball vs Nebraska", sportCode: "VB", opponent: "Nebraska",
                locationId: "loc-fh", startsAt: at(0, 11), endsAt: at(0, 14),
                callStartsAt: at(0, 9, 30),
                shifts: [
                    CrewSlot(area: "VIDEO", worker: "Bucky Badger"),
                    CrewSlot(area: "VIDEO", worker: "Alex Rivera"),
                    CrewSlot(area: "PHOTO", worker: "Sam Chen"),
                    CrewSlot(area: "PHOTO", worker: nil),
                    CrewSlot(area: "GRAPHICS", worker: "Riley Novak"),
                    CrewSlot(area: "SOCIAL", worker: nil),
                ]
            ),
            "e9": CrewPlan(
                summary: "Women's Soccer vs Penn State", sportCode: "WSOC", opponent: "Penn State",
                locationId: "loc-mc", startsAt: fromNow(-45), endsAt: fromNow(75),
                callStartsAt: fromNow(-105),
                shifts: [
                    CrewSlot(area: "VIDEO", worker: "Priya Shah"),
                    CrewSlot(area: "PHOTO", worker: "Marcus Webb"),
                    CrewSlot(area: "GRAPHICS", worker: "Dana Kim"),
                    CrewSlot(area: "SOCIAL", worker: nil),
                ]
            ),
        ]
    }

    static var myShifts: Data {
        let shifts = """
        [
          { "id": "s0", "area": "VIDEO", "workerType": "ST", "startsAt": "\(at(-9, 18))",
            "endsAt": "\(at(-9, 21))", "status": "COMPLETED",
            "event": { "id": "e21", "summary": "Wrestling vs Iowa", "startsAt": "\(at(-9, 19))",
                       "endsAt": "\(at(-9, 21))", "sportCode": "WRES", "isHome": true,
                       "opponent": "Iowa", "locationId": "loc-fh", "locationName": "UW Field House" },
            "gear": { "status": "none", "bookings": [] } },
          { "id": "s1", "area": "CAMERA", "workerType": "ST", "startsAt": "\(at(0, 9, 30))",
            "endsAt": "\(at(0, 14, 30))", "status": "ACTIVE",
            "event": { "id": "e1", "summary": "Volleyball vs Nebraska", "startsAt": "\(at(0, 11))",
                       "endsAt": "\(at(0, 14))", "sportCode": "VB", "isHome": true,
                       "opponent": "Nebraska", "locationId": "loc-fh", "locationName": "UW Field House" },
            "gear": { "status": "checked_out",
                      "bookings": [ { "id": "b1", "status": "CHECKED_OUT", "kind": "SERIALIZED", "itemCount": 4 } ] } },
          { "id": "s1b", "area": "PHOTO", "workerType": "ST", "startsAt": "\(at(0, 10))",
            "endsAt": "\(at(0, 14))", "status": "ACTIVE",
            "event": { "id": "e1", "summary": "Volleyball vs Nebraska", "startsAt": "\(at(0, 11))",
                       "endsAt": "\(at(0, 14))", "sportCode": "VB", "isHome": true,
                       "opponent": "Nebraska", "locationId": "loc-fh", "locationName": "UW Field House" },
            "gear": { "status": "none", "bookings": [] } },
          { "id": "s2", "area": "REPLAY", "workerType": "FT", "startsAt": "\(at(1, 12))",
            "endsAt": "\(at(1, 15, 30))", "status": "ACTIVE",
            "event": { "id": "e4", "summary": "Football vs Ohio State", "startsAt": "\(at(1, 12))",
                       "endsAt": "\(at(1, 15, 30))", "sportCode": "FB", "isHome": true,
                       "opponent": "Ohio State", "locationId": "loc-cr", "locationName": "Camp Randall Stadium" },
            "gear": { "status": "pickup_ready",
                      "bookings": [ { "id": "b2", "status": "RESERVED", "kind": "SERIALIZED", "itemCount": 7 } ] } }
        ]
        """
        return Data("{ \"data\": \(shifts) }".utf8)
    }
}
// MARK: - Trade Board

/// The Trade Board against canned trades and Open Work.
///
/// The review queue is the point of the capture: before claims waited on staff
/// there was nothing to review, so the section could not be photographed at all.
/// Both scenarios render the same real sheet; only the fixture role differs.
struct TradeBoardHarnessView: View {
    @Environment(SessionStore.self) private var session

    private var isStaff: Bool { AppRuntimeMode.performanceScenario == .tradeBoardStaff }

    var body: some View {
        TradeBoardSheet(
            myShifts: [],
            currentUserId: isStaff ? TradeBoardFixtures.staff.id : TradeBoardFixtures.student.id,
            // Claim review is Admin-only, so the review-queue scenario signs
            // in as an Admin.
            currentUserRole: isStaff ? "ADMIN" : "STUDENT"
        )
        .onAppear {
            session.currentUser = isStaff ? TradeBoardFixtures.staff : TradeBoardFixtures.student
        }
    }
}

enum TradeBoardFixtures {
    static let staff = CurrentUser(
        id: "fixture-staff",
        name: "Jordan Lee",
        email: "jordan.lee@wisc.edu",
        role: "ADMIN",
        affiliation: nil,
        collaboratorProfile: nil,
        capabilities: [],
        collaboratorPolicy: nil,
        staffingType: "FT",
        avatarUrl: nil,
        forcePasswordChange: false
    )

    static let student = CurrentUser(
        id: "fixture-student",
        name: "Rowan Diaz",
        email: "rowan.diaz@wisc.edu",
        role: "STUDENT",
        affiliation: nil,
        collaboratorProfile: nil,
        capabilities: [],
        collaboratorPolicy: nil,
        staffingType: "ST",
        avatarUrl: nil,
        forcePasswordChange: false
    )
}

/// Trade and Open Work payloads built relative to launch, so the review rows
/// always read as genuinely upcoming work rather than freezing at an authored
/// date and rendering as history.
enum TradeBoardFixtureAPI {
    private static func at(_ dayOffset: Int, _ hour: Int) -> String {
        let calendar = Calendar.current
        let day = calendar.date(byAdding: .day, value: dayOffset, to: Date.now) ?? .now
        let date = calendar.date(hour: hour, of: day) ?? day
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime]
        return formatter.string(from: date)
    }

    private static func shift(
        id: String,
        area: String,
        summary: String,
        opponent: String,
        dayOffset: Int,
        hour: Int
    ) -> String {
        """
        {
          "id": "\(id)", "area": "\(area)", "workerType": "ST",
          "startsAt": "\(at(dayOffset, hour))", "endsAt": "\(at(dayOffset, hour + 4))",
          "callStartsAt": null, "callEndsAt": null,
          "shiftGroup": {
            "id": "group-\(id)", "publishedAt": "\(at(-6, 9))",
            "event": {
              "id": "event-\(id)", "summary": "\(summary)",
              "sportCode": "football", "opponent": "\(opponent)", "isHome": true,
              "startsAt": "\(at(dayOffset, hour))", "endsAt": "\(at(dayOffset, hour + 4))"
            }
          }
        }
        """
    }

    private static func trade(
        id: String,
        status: String,
        area: String,
        summary: String,
        opponent: String,
        dayOffset: Int,
        hour: Int,
        posterName: String,
        claimerName: String?,
        notes: String?,
        viewerCanClaim: Bool,
        viewerClaimReason: String?
    ) -> String {
        let claimedBy = claimerName.map {
            "{ \"id\": \"\(claimerName == "Rowan Diaz" ? "fixture-student" : "user-claimer")\", \"name\": \"\($0)\", \"primaryArea\": \"\(area)\" }"
        } ?? "null"
        let notesJSON = notes.map { "\"\($0)\"" } ?? "null"
        let reasonJSON = viewerClaimReason.map { "\"\($0)\"" } ?? "null"
        return """
        {
          "id": "\(id)", "status": "\(status)", "notes": \(notesJSON),
          "postedBy": { "id": "user-poster-\(id)", "name": "\(posterName)", "primaryArea": "\(area)" },
          "claimedBy": \(claimedBy),
          "shiftAssignment": {
            "id": "assignment-\(id)",
            "shift": \(shift(id: "shift-\(id)", area: area, summary: summary, opponent: opponent, dayOffset: dayOffset, hour: hour)),
            "user": { "id": "user-poster-\(id)", "name": "\(posterName)", "primaryArea": "\(area)" }
          },
          "postedAt": "\(at(-2, 10))", "claimedAt": \(status == "CLAIMED" ? "\"\(at(-1, 14))\"" : "null"),
          "createdAt": "\(at(-2, 10))",
          "viewerAvailabilityContext": null, "claimedByAvailabilityContext": null,
          "viewerCanClaim": \(viewerCanClaim), "viewerClaimReason": \(reasonJSON)
        }
        """
    }

    static var trades: Data? {
        let isStaff = AppRuntimeMode.performanceScenario == .tradeBoardStaff
        var rows: [String] = []

        // Two claims owed a decision. Staff see both; the student sees only the
        // one they claimed themselves, in Waiting on Staff.
        rows.append(trade(
            id: "t1", status: "CLAIMED", area: "VIDEO",
            summary: "Football vs Minnesota", opponent: "Minnesota",
            dayOffset: 5, hour: 13,
            posterName: "Avery Nakamura",
            claimerName: isStaff ? "Sam Whitfield" : "Rowan Diaz",
            notes: "Family in town that weekend.",
            viewerCanClaim: false,
            viewerClaimReason: isStaff
                ? "Sam Whitfield claimed this — waiting for staff approval"
                : "Waiting for staff to approve your claim"
        ))
        if isStaff {
            rows.append(trade(
                id: "t2", status: "CLAIMED", area: "PHOTO",
                summary: "Volleyball vs Nebraska", opponent: "Nebraska",
                dayOffset: 2, hour: 18,
                posterName: "Priya Raman", claimerName: "Marcus Bell",
                notes: nil, viewerCanClaim: false,
                viewerClaimReason: "Marcus Bell claimed this — waiting for staff approval"
            ))
        } else {
            // One post the student can still take, so Available Now is populated
            // alongside what they are waiting on.
            rows.append(trade(
                id: "t3", status: "OPEN", area: "VIDEO",
                summary: "Hockey vs Michigan", opponent: "Michigan",
                dayOffset: 8, hour: 19,
                posterName: "Priya Raman", claimerName: nil,
                notes: "Swapping for a class conflict.",
                viewerCanClaim: true, viewerClaimReason: nil
            ))
        }

        return "{ \"data\": [\(rows.joined(separator: ","))], \"total\": \(rows.count) }"
            .data(using: .utf8)
    }

    static var openWork: Data? {
        let isStaff = AppRuntimeMode.performanceScenario == .tradeBoardStaff

        let openShift = """
        {
          "id": "open-1", "kind": "open_shift", "action": "\(isStaff ? "none" : "claim")",
          "canAct": \(!isStaff), "reason": "\(isStaff ? "Open pickup is available for Student slots only" : "")",
          "score": 82, "bucket": "recommended",
          "advisoryConflict": false, "advisoryConflictNote": null,
          "availabilityContext": null, "warnings": [], "ownRequestId": null,
          "requestCount": \(isStaff ? 2 : 0),
          "shift": \(shift(id: "open-1", area: "GRAPHICS", summary: "Basketball vs Purdue", opponent: "Purdue", dayOffset: 4, hour: 17))
        }
        """

        func request(id: String, name: String, userId: String, area: String, summary: String, opponent: String, day: Int, hour: Int, note: String?) -> String {
            let noteJSON = note.map { "\"\($0)\"" } ?? "null"
            return """
            {
              "id": "\(id)", "kind": "pickup_request", "status": "REQUESTED",
              "hasConflict": \(note != nil), "conflictNote": \(noteJSON),
              "createdAt": "\(at(-1, 9))",
              "user": { "id": "\(userId)", "name": "\(name)", "primaryArea": "\(area)" },
              "shift": \(shift(id: "shift-\(id)", area: area, summary: summary, opponent: opponent, dayOffset: day, hour: hour))
            }
            """
        }

        let requests: [String] = isStaff
            ? [
                request(id: "req-1", name: "Dana Okafor", userId: "user-dana", area: "GRAPHICS",
                        summary: "Basketball vs Purdue", opponent: "Purdue", day: 4, hour: 17, note: nil),
                request(id: "req-2", name: "Chris Bergeron", userId: "user-chris", area: "GRAPHICS",
                        summary: "Basketball vs Purdue", opponent: "Purdue", day: 4, hour: 17,
                        note: "Prefers not to work Thursday evenings"),
            ]
            : [
                request(id: "req-3", name: "Rowan Diaz", userId: "fixture-student", area: "SOCIAL",
                        summary: "Soccer vs Ohio State", opponent: "Ohio State", day: 6, hour: 15, note: nil),
            ]

        return """
        { "data": { "openShifts": [\(openShift)], "pickupRequests": [\(requests.joined(separator: ","))] } }
        """.data(using: .utf8)
    }
}

private extension Calendar {
    func date(hour: Int, of day: Date) -> Date? {
        date(bySettingHour: hour, minute: 0, second: 0, of: startOfDay(for: day))
    }
}
#endif
