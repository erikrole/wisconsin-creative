"use client";

import { Suspense, useEffect, useState } from "react";
import WelcomeLab from "@/app/dev-welcome/WelcomeLab";

type Block = Record<string, unknown>;

function installMock() {
  const real = window.fetch.bind(window);
  const blocks: Block[] = [];
  const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { "Content-Type": "application/json" } });
  window.fetch = async (input, init) => {
    const raw = typeof input === "string" ? input : input instanceof URL ? input.href : input.url;
    const path = new URL(raw, location.origin).pathname;
    const method = (init?.method ?? "GET").toUpperCase();
    if (!path.startsWith("/api/users/dev-welcome/availability")) return real(input, init);
    if (method === "POST") {
      const body = JSON.parse(String(init?.body ?? "{}"));
      const days: number[] = body.days ?? [];
      const rows = days.map((day, i) => ({ id: `b${blocks.length + i}`, ...body, dayOfWeek: day }));
      blocks.push(...rows);
      return json({ data: rows });
    }
    if (method === "DELETE") { blocks.length = 0; return json({ data: {} }); }
    return json({ data: blocks });
  };
}

export default function PaintLab({ fontClass }: { fontClass: string }) {
  const [ready, setReady] = useState(false);
  useEffect(() => { installMock(); setReady(true); }, []);
  if (!ready) return null;
  return <Suspense><WelcomeLab fontClass={fontClass} /></Suspense>;
}
