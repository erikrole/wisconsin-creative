import { notFound } from "next/navigation";
import { Lato } from "next/font/google";
import PaintLab from "./PaintLab";

const lato = Lato({ subsets: ["latin"], weight: ["400", "700", "900"], variable: "--font-lato", display: "swap" });

// Dev-only: /dev-welcome?view=availability with its availability API mocked in the browser, so it runs with no database.
export default function Page() {
  if (process.env.NODE_ENV === "production") notFound();
  return <PaintLab fontClass={lato.variable} />;
}
