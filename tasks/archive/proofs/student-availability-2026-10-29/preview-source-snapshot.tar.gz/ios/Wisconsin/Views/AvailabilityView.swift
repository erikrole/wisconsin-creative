import SwiftUI

private let availabilityTimeZone = TimeZone(identifier: "America/Chicago") ?? .gmt
private var availabilityCalendar: Calendar {
    var calendar = Calendar(identifier: .gregorian)
    calendar.timeZone = availabilityTimeZone
    return calendar
}

private let availabilityDayNames = [
    "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday",
]

private let availabilityShortDayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]

/// Interactive editor for the weekly and one-time scheduling signals used by
/// Schedule assignment, open-shift, and trade eligibility surfaces.
struct AvailabilityView: View {
    let userId: String

    @State private var blocks: [AvailabilityBlock] = []
    @State private var selectedWeekday = availabilityCalendar.component(.weekday, from: .now) - 1
    @State private var isLoading = true
    @State private var error: String?
    @State private var editorContext: AvailabilityEditorContext?
    @State private var blockPendingDelete: AvailabilityBlock?

    private var currentBlocks: [AvailabilityBlock] { blocks.filter { !$0.isHistory } }
    private var historyBlocks: [AvailabilityBlock] { blocks.filter(\.isHistory).sorted(by: sortBlocks) }

    private var selectedDayBlocks: [AvailabilityBlock] {
        currentBlocks.filter { $0.isWeekly && $0.dayOfWeek == selectedWeekday }.sorted(by: sortBlocks)
    }

    private var datedBlocks: [AvailabilityBlock] {
        currentBlocks.filter(\.isDated).sorted(by: sortBlocks)
    }

    var body: some View {
        Group {
            if isLoading && blocks.isEmpty {
                ScrollView {
                    AvailabilityLoadingState()
                        .padding(.horizontal, 16)
                        .padding(.vertical, 12)
                }
            } else {
                List {
                    if let error {
                        Section {
                            AvailabilityErrorBanner(message: error) {
                                Task { await load() }
                            } onDismiss: {
                                self.error = nil
                            }
                            .listRowInsets(EdgeInsets())
                            .listRowBackground(Color.clear)
                        }
                    }
                    weeklySection
                    daysAwaySection
                    if !historyBlocks.isEmpty {
                        Section {
                            DisclosureGroup("History (\(historyBlocks.count))") {
                                ForEach(historyBlocks) { block in blockRow(block) }
                            }
                        }
                    }
                }
                .listStyle(.insetGrouped)
            }
        }
        .background(Color(.systemGroupedBackground))
        .navigationTitle("My Availability")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Menu {
                    Button {
                        editorContext = .newWeekly(day: selectedWeekday)
                    } label: {
                        Label("Add Class Schedule…", systemImage: "calendar.badge.clock")
                    }
                    Button {
                        editorContext = .newException(date: .now)
                    } label: {
                        Label("Add Day Away…", systemImage: "calendar.badge.exclamationmark")
                    }
                } label: {
                    Label("Add availability", systemImage: "plus")
                }
                .accessibilityLabel("Add availability")
            }
        }
        .task { await load() }
        .refreshable { await load() }
        .sheet(item: $editorContext) { context in
            AvailabilityEditorSheet(userId: userId, context: context, onStale: { await load() }) { saved in
                upsert(saved)
            }
            .environment(\.timeZone, availabilityTimeZone)
        }
        .confirmationDialog(
            "Delete availability block?",
            isPresented: deleteConfirmationBinding,
            titleVisibility: .visible,
            presenting: blockPendingDelete
        ) { block in
            Button("Delete \(block.primaryLine)", role: .destructive) {
                Task { await delete(block) }
            }
            Button("Cancel", role: .cancel) {
                blockPendingDelete = nil
            }
        } message: { block in
            Text("Staff will no longer see \(block.primaryLine) when reviewing your availability.")
        }
    }

    private var weeklySection: some View {
        Section {
            AvailabilityWeekStrip(
                selectedDay: $selectedWeekday,
                blocks: currentBlocks.filter(\.isWeekly)
            )
            .listRowInsets(EdgeInsets(top: 4, leading: 8, bottom: 4, trailing: 8))

            ForEach(selectedDayBlocks) { block in
                blockRow(block)
            }

            if selectedDayBlocks.isEmpty {
                Text("Nothing saved for \(availabilityDayNames[selectedWeekday]).")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }

            Button {
                editorContext = .newWeekly(day: selectedWeekday)
            } label: {
                Label("Add class time", systemImage: "plus")
            }
            .tint(Color.brandPrimary)
        } header: {
            Text(availabilityDayNames[selectedWeekday])
        } footer: {
            Text("Weekly times repeat in Madison time (Central). Ended terms are in History.")
        }
    }

    private var daysAwaySection: some View {
        Section {
            ForEach(datedBlocks) { block in
                blockRow(block)
            }

            if datedBlocks.isEmpty {
                Text("No days away added.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }

            Button {
                editorContext = .newException(date: .now)
            } label: {
                Label("Add day away", systemImage: "plus")
            }
            .tint(Color.brandPrimary)
        } header: {
            Text("Days away")
        } footer: {
            Text("Approved time off blocks shift pickup and trades. Other signals help staff schedule with better context.")
        }
    }

    private func blockRow(_ block: AvailabilityBlock) -> some View {
        AvailabilityBlockRow(block: block, onEdit: { editorContext = .edit(block) })
            .swipeActions(edge: .trailing) {
                Button(role: .destructive) {
                    blockPendingDelete = block
                } label: {
                    Label("Delete", systemImage: "trash")
                }
                Button {
                    editorContext = .edit(block)
                } label: {
                    Label("Edit", systemImage: "pencil")
                }
                .tint(.gray)
            }
            .contextMenu {
                Button("Edit…", systemImage: "pencil") { editorContext = .edit(block) }
                Button("Delete", systemImage: "trash", role: .destructive) { blockPendingDelete = block }
            }
    }

    private func sortBlocks(_ lhs: AvailabilityBlock, _ rhs: AvailabilityBlock) -> Bool {
        let lhsDate = lhs.dateValue ?? ""
        let rhsDate = rhs.dateValue ?? ""
        if lhsDate != rhsDate { return lhsDate < rhsDate }
        if lhs.startsAt != rhs.startsAt { return lhs.startsAt < rhs.startsAt }
        return lhs.endsAt < rhs.endsAt
    }

    private func load() async {
        isLoading = true
        error = nil
        do {
            blocks = try await APIClient.shared.availabilityBlocks(userId: userId)
        } catch {
            self.error = error.localizedDescription
        }
        isLoading = false
    }

    private func upsert(_ block: AvailabilityBlock) {
        if let index = blocks.firstIndex(where: { $0.id == block.id }) {
            blocks[index] = block
        } else {
            blocks.append(block)
        }
        if let day = block.dayOfWeek { selectedWeekday = day }
    }

    private func delete(_ block: AvailabilityBlock) async {
        do {
            try await APIClient.shared.deleteAvailabilityBlock(userId: userId, blockId: block.id)
            blocks.removeAll { $0.id == block.id }
            blockPendingDelete = nil
            Haptics.success()
        } catch {
            self.error = error.localizedDescription
            blockPendingDelete = nil
            Haptics.warning()
        }
    }

    private var deleteConfirmationBinding: Binding<Bool> {
        Binding(
            get: { blockPendingDelete != nil },
            set: { if !$0 { blockPendingDelete = nil } }
        )
    }
}

private struct AvailabilityLoadingState: View {
    var body: some View {
        VStack(spacing: 16) {
            ForEach([120, 260, 150], id: \.self) { height in
                RoundedRectangle(cornerRadius: 20)
                    .fill(Color(.secondarySystemGroupedBackground))
                    .frame(height: CGFloat(height))
                    .overlay(alignment: .topLeading) {
                        VStack(alignment: .leading, spacing: 10) {
                            RoundedRectangle(cornerRadius: 4)
                                .fill(Color(.tertiarySystemFill))
                                .frame(width: 140, height: 18)
                            RoundedRectangle(cornerRadius: 4)
                                .fill(Color(.tertiarySystemFill))
                                .frame(width: 220, height: 12)
                        }
                        .padding(16)
                    }
            }
        }
        .accessibilityElement()
        .accessibilityLabel("Loading availability")
    }
}

private struct AvailabilityWeekStrip: View {
    @Binding var selectedDay: Int
    let blocks: [AvailabilityBlock]

    var body: some View {
        HStack(spacing: 4) {
            ForEach(0..<7, id: \.self) { day in
                let count = blocks.filter { $0.dayOfWeek == day }.count
                let isSelected = day == selectedDay
                Button {
                    selectedDay = day
                    Haptics.selection()
                } label: {
                    VStack(spacing: 5) {
                        Text(availabilityShortDayNames[day])
                            .font(.subheadline.weight(isSelected ? .semibold : .regular))
                            .foregroundStyle(isSelected ? Color.white : Color.primary)
                        Circle()
                            .fill(count > 0 ? (isSelected ? Color.white : Color.secondary) : Color.clear)
                            .frame(width: 5, height: 5)
                    }
                    .frame(maxWidth: .infinity, minHeight: 52)
                    .background(
                        RoundedRectangle(cornerRadius: 12, style: .continuous)
                            .fill(isSelected ? Color.brandPrimary : Color.clear)
                    )
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .accessibilityLabel("\(availabilityDayNames[day]), \(count) saved \(count == 1 ? "window" : "windows")")
                .accessibilityAddTraits(isSelected ? .isSelected : [])
            }
        }
    }
}

private struct AvailabilityBlockRow: View {
    let block: AvailabilityBlock
    let onEdit: () -> Void

    var body: some View {
        Button(action: onEdit) {
            HStack(alignment: .firstTextBaseline, spacing: 10) {
                Circle()
                    .fill(markerColor)
                    .frame(width: 8, height: 8)
                    .accessibilityHidden(true)
                VStack(alignment: .leading, spacing: 2) {
                    Text(block.primaryLine)
                        .font(.body)
                        .foregroundStyle(.primary)
                    Text(block.secondaryLine)
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                    if let note = block.reviewNote, !note.isEmpty {
                        Text("Staff note: \(note)")
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                    }
                    if let statusLine = block.statusLine {
                        Text(statusLine)
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                    }
                }
                Spacer(minLength: 8)
                if block.hasCustomLabel {
                    Text(block.intentMetadata.label)
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
            }
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }

    /// Color only where it carries status: preferred is green, a pending
    /// request is orange, approved time off is the one red. Everything else is
    /// a quiet gray dot.
    private var markerColor: Color {
        switch block.normalizedIntent {
        case "PREFER": return Color.statusText(.green)
        case "TIME_OFF": return Color.statusText(block.statusTone)
        default: return Color(.tertiaryLabel)
        }
    }
}

private struct AvailabilityErrorBanner: View {
    let message: String
    let onRetry: () -> Void
    let onDismiss: () -> Void

    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: "exclamationmark.triangle.fill")
                .foregroundStyle(Color.statusText(.red))
            Text(message)
                .font(.footnote)
                .lineLimit(2)
            Spacer(minLength: 8)
            Button("Retry", action: onRetry)
                .font(.footnote.weight(.semibold))
            Button(action: onDismiss) {
                Image(systemName: "xmark")
                    .frame(width: 32, height: 32)
            }
            .accessibilityLabel("Dismiss availability error")
        }
        .padding(12)
        .background(Color.statusBackground(.red), in: RoundedRectangle(cornerRadius: 14))
    }
}

private struct AvailabilityEditorContext: Identifiable {
    let id: String
    let block: AvailabilityBlock?
    let suggestedKind: AvailabilityEditorKind
    let suggestedDay: Int
    let suggestedDate: Date

    static func newWeekly(day: Int) -> Self {
        Self(id: UUID().uuidString, block: nil, suggestedKind: .weekly, suggestedDay: day, suggestedDate: .now)
    }

    static func newException(date: Date) -> Self {
        Self(
            id: UUID().uuidString,
            block: nil,
            suggestedKind: .adHoc,
            suggestedDay: availabilityCalendar.component(.weekday, from: date) - 1,
            suggestedDate: date
        )
    }

    static func edit(_ block: AvailabilityBlock) -> Self {
        Self(
            id: block.id,
            block: block,
            suggestedKind: block.isDated ? .adHoc : .weekly,
            suggestedDay: block.dayOfWeek ?? 1,
            suggestedDate: block.parsedDate ?? .now
        )
    }
}

private struct AvailabilityEditorSheet: View {
    let userId: String
    let context: AvailabilityEditorContext
    let onStale: () async -> Void
    let onSaved: (AvailabilityBlock) -> Void

    @Environment(\.dismiss) private var dismiss
    @Environment(SessionStore.self) private var session
    @State private var kind: AvailabilityEditorKind
    @State private var intent: AvailabilityEditorIntent
    @State private var dayOfWeek: Int
    @State private var date: Date
    @State private var dateEnd: Date
    @State private var isDateRange: Bool
    @State private var allDay: Bool
    @State private var startMinutes: Int
    @State private var endMinutes: Int
    @State private var label: String
    @State private var usesTermDates: Bool
    @State private var termStartDate: Date
    @State private var termEndDate: Date
    @State private var semesterLabel: String
    @State private var createRequestId = UUID().uuidString
    @State private var isSaving = false
    @State private var error: String?

    init(userId: String, context: AvailabilityEditorContext, onStale: @escaping () async -> Void, onSaved: @escaping (AvailabilityBlock) -> Void) {
        self.userId = userId
        self.context = context
        self.onStale = onStale
        self.onSaved = onSaved
        let block = context.block
        _kind = State(initialValue: block?.editorKind ?? context.suggestedKind)
        _intent = State(initialValue: block?.editorIntent ?? .cannotWork)
        _dayOfWeek = State(initialValue: block?.dayOfWeek ?? context.suggestedDay)
        _date = State(initialValue: block?.parsedDate ?? context.suggestedDate)
        _dateEnd = State(initialValue: block?.parsedDateEndsOn ?? block?.parsedDate ?? context.suggestedDate)
        _isDateRange = State(initialValue: {
            guard let start = block?.parsedDate, let end = block?.parsedDateEndsOn else { return false }
            return !availabilityCalendar.isDate(start, inSameDayAs: end)
        }())
        _allDay = State(initialValue: block?.allDay == true)
        _startMinutes = State(initialValue: Self.minutes(block?.startsAt) ?? 9 * 60)
        _endMinutes = State(initialValue: Self.minutes(block?.endsAt) ?? 10 * 60)
        _label = State(initialValue: block?.label ?? "")
        _usesTermDates = State(initialValue: block?.semesterStartsOn != nil || block?.semesterEndsOn != nil)
        _termStartDate = State(initialValue: block?.parsedSemesterStart ?? context.suggestedDate)
        _termEndDate = State(initialValue: block?.parsedSemesterEnd ?? availabilityCalendar.date(byAdding: .month, value: 4, to: context.suggestedDate) ?? context.suggestedDate)
        _semesterLabel = State(initialValue: block?.semesterLabel ?? "")
    }

    private static let timePresets: [(title: String, detail: String, start: Int, end: Int)] = [
        ("Morning", "8 AM – 12 PM", 8 * 60, 12 * 60),
        ("Afternoon", "12 – 5 PM", 12 * 60, 17 * 60),
        ("Evening", "5 – 10 PM", 17 * 60, 22 * 60),
        ("School day", "8 AM – 5 PM", 8 * 60, 17 * 60),
    ]

    private func editorCard<Content: View>(_ title: String, @ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(title)
                .font(.headline)
            content()
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(16)
        .background(Color.cardSurface, in: RoundedRectangle(cornerRadius: Brand.Radius.lg, style: .continuous))
    }

    private var timeOptions: [Int] {
        Array(Set(Array(stride(from: 0, through: 23 * 60 + 45, by: 15)) + [startMinutes, endMinutes])).sorted()
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 14) {
                    editorCard("What is this?") {
                        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 8) {
                            ForEach(AvailabilityEditorIntent.allCases) { option in
                                ChipButton(
                                    title: option.label,
                                    systemImage: option.systemImage,
                                    isSelected: intent == option,
                                    tint: Color.statusText(.purple)
                                ) {
                                    intent = option
                                    Haptics.selection()
                                }
                            }
                        }
                        Text(intent == .timeOff && context.block != nil && session.currentUser?.role == "STUDENT"
                             ? "Saving changes sends this request back to staff for review."
                             : intent.detail)
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                    }

                    editorCard("When") {
                        HStack(spacing: 8) {
                            ForEach(AvailabilityEditorKind.allCases) { option in
                                ChipButton(
                                    title: option.label,
                                    isSelected: kind == option,
                                    tint: Color.statusText(.purple)
                                ) {
                                    kindSelection.wrappedValue = option
                                    Haptics.selection()
                                }
                            }
                        }

                        if kind == .weekly {
                            LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 8), count: 4), spacing: 8) {
                                ForEach(0..<7, id: \.self) { index in
                                    ChipButton(
                                        title: String(availabilityDayNames[index].prefix(3)),
                                        isSelected: dayOfWeek == index,
                                        tint: Color.statusText(.purple)
                                    ) {
                                        dayOfWeek = index
                                        Haptics.selection()
                                    }
                                }
                            }
                        } else {
                            DatePicker("From", selection: $date, displayedComponents: .date)
                            Toggle("Multiple days", isOn: $isDateRange)
                            if isDateRange {
                                DatePicker("Through", selection: $dateEnd, displayedComponents: .date)
                            }
                            Toggle("All day", isOn: $allDay)
                            if allDay {
                                Text(intent.allDayDetail)
                                    .font(.footnote)
                                    .foregroundStyle(.secondary)
                            }
                        }
                    }
                    .tint(Color.statusText(.purple))

                    if kind == .weekly || !allDay {
                        editorCard("Time") {
                            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 8) {
                                ForEach(Self.timePresets, id: \.title) { preset in
                                    ChipButton(
                                        title: preset.title,
                                        detail: preset.detail,
                                        isSelected: startMinutes == preset.start && endMinutes == preset.end,
                                        tint: Color.statusText(.purple)
                                    ) {
                                        startMinutes = preset.start
                                        endMinutes = preset.end
                                        Haptics.selection()
                                    }
                                }
                            }
                            HStack(alignment: .firstTextBaseline) {
                                Text("Starts").font(.subheadline.weight(.semibold))
                                Picker("Starts", selection: $startMinutes) {
                                    ForEach(timeOptions, id: \.self) { minutes in
                                        Text(Self.timeLabel(minutes)).tag(minutes)
                                    }
                                }
                                .labelsHidden()
                                .fixedSize()
                                Spacer(minLength: 8)
                                Text("Ends").font(.subheadline.weight(.semibold))
                                Picker("Ends", selection: $endMinutes) {
                                    ForEach(timeOptions, id: \.self) { minutes in
                                        Text(Self.timeLabel(minutes)).tag(minutes)
                                    }
                                }
                                .labelsHidden()
                                .fixedSize()
                            }
                            .tint(Color.statusText(.purple))
                        }
                    }

                    if kind == .weekly {
                        editorCard("Class term (optional)") {
                            Toggle("Limit to term dates", isOn: $usesTermDates)
                                .tint(Color.statusText(.purple))
                            if usesTermDates {
                                TextField("Term name (optional)", text: $semesterLabel)
                                DatePicker("Starts", selection: $termStartDate, displayedComponents: .date)
                                DatePicker("Ends", selection: $termEndDate, displayedComponents: .date)
                            }
                            Text("Use this when the class only blocks work during a specific semester or session.")
                                .font(.footnote)
                                .foregroundStyle(.secondary)
                        }
                    }

                    editorCard("Label") {
                        TextField(intent.labelPlaceholder, text: $label)
                        if kind == .weekly {
                            Text(usesTermDates ? "Repeats every \(availabilityDayNames[dayOfWeek]) during the selected term." : "Repeats every \(availabilityDayNames[dayOfWeek]) until you remove it.")
                                .font(.footnote)
                                .foregroundStyle(.secondary)
                        } else if isDateRange {
                            Text("Applies to every selected date in the range.")
                                .font(.footnote)
                                .foregroundStyle(.secondary)
                        } else {
                            Text("Applies only to the selected date.")
                                .font(.footnote)
                                .foregroundStyle(.secondary)
                        }
                    }

                    if let error {
                        Label(error, systemImage: "exclamationmark.triangle.fill")
                            .font(.footnote)
                            .foregroundStyle(Color.statusText(.red))
                    }
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 12)
            }
            .background(Color(.systemGroupedBackground))
            .safeAreaInset(edge: .bottom) {
                Button {
                    Task { await save() }
                } label: {
                    Group {
                        if isSaving {
                            ProgressView().tint(.white)
                        } else {
                            Text(context.block == nil ? "Add" : "Save").font(.headline)
                        }
                    }
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity, minHeight: 56)
                    .background(Color.statusText(.purple), in: RoundedRectangle(cornerRadius: 16))
                }
                .buttonStyle(.plain)
                .disabled(isSaving)
                .padding(.horizontal, 16)
                .padding(.vertical, 10)
                .background(.bar)
            }
            .navigationTitle(context.block == nil ? (kind == .weekly ? "Add Class Schedule" : "Add Day Away") : "Edit Availability")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                        .disabled(isSaving)
                }
            }
            .interactiveDismissDisabled(isSaving)
            .onChange(of: startMinutes) { _, newValue in
                adjustEndTime(after: newValue)
            }
            .onChange(of: date) { _, newValue in
                if dateEnd < newValue {
                    dateEnd = newValue
                }
            }
            .onChange(of: termStartDate) { _, newValue in
                if termEndDate < newValue {
                    termEndDate = newValue
                }
            }
        }
    }

    private var kindSelection: Binding<AvailabilityEditorKind> {
        Binding(
            get: { kind },
            set: { newValue in
                kind = newValue
                if newValue == .weekly {
                    isDateRange = false
                    allDay = false
                }
            }
        )
    }

    private func adjustEndTime(after newValue: Int) {
        guard endMinutes <= newValue else { return }
        let proposedEnd = newValue + 60
        let latestEnd = 23 * 60 + 45
        endMinutes = proposedEnd > latestEnd ? latestEnd : proposedEnd
    }

    private func save() async {
        guard !isSaving else { return }
        guard allDay || startMinutes < endMinutes else {
            error = "Start time must be before end time"
            Haptics.warning()
            return
        }
        if kind == .adHoc && isDateRange && dateEnd < date {
            error = "The through date must be on or after the from date"
            Haptics.warning()
            return
        }
        if kind == .weekly && usesTermDates && termEndDate < termStartDate {
            error = "The term end date must be on or after the start date"
            Haptics.warning()
            return
        }
        isSaving = true
        error = nil
        let trimmed = label.trimmingCharacters(in: .whitespacesAndNewlines)
        let trimmedSemesterLabel = semesterLabel.trimmingCharacters(in: .whitespacesAndNewlines)
        let startsAt = kind == .adHoc && allDay ? "00:00" : Self.hhmm(startMinutes)
        let endsAt = kind == .adHoc && allDay ? "23:59" : Self.hhmm(endMinutes)
        let startDate = kind == .adHoc ? Self.yyyyMMdd(date) : nil
        let endDate = kind == .adHoc ? Self.yyyyMMdd(isDateRange ? dateEnd : date) : nil
        let termLabel = kind == .weekly && usesTermDates && !trimmedSemesterLabel.isEmpty ? trimmedSemesterLabel : nil
        let termStart = kind == .weekly && usesTermDates ? Self.yyyyMMdd(termStartDate) : nil
        let termEnd = kind == .weekly && usesTermDates ? Self.yyyyMMdd(termEndDate) : nil
        do {
            let saved: AvailabilityBlock
            if let block = context.block {
                saved = try await APIClient.shared.updateAvailabilityBlock(
                    userId: userId,
                    blockId: block.id,
                    expectedUpdatedAt: block.updatedAt,
                    kind: kind.rawValue,
                    intent: intent.rawValue,
                    dayOfWeek: dayOfWeek,
                    date: startDate,
                    dateEndsOn: endDate,
                    allDay: kind == .adHoc && allDay,
                    startsAt: startsAt,
                    endsAt: endsAt,
                    label: trimmed.isEmpty ? nil : trimmed,
                    semesterLabel: termLabel,
                    semesterStartsOn: termStart,
                    semesterEndsOn: termEnd
                )
            } else {
                saved = try await APIClient.shared.createAvailabilityBlock(
                    userId: userId,
                    requestId: createRequestId,
                    kind: kind.rawValue,
                    intent: intent.rawValue,
                    dayOfWeek: dayOfWeek,
                    date: startDate,
                    dateEndsOn: endDate,
                    allDay: kind == .adHoc && allDay,
                    startsAt: startsAt,
                    endsAt: endsAt,
                    label: trimmed.isEmpty ? nil : trimmed,
                    semesterLabel: termLabel,
                    semesterStartsOn: termStart,
                    semesterEndsOn: termEnd
                )
            }
            onSaved(saved)
            Haptics.success()
            dismiss()
        } catch {
            if case APIError.conflict = error { await onStale() }
            self.error = error.localizedDescription
            Haptics.warning()
        }
        isSaving = false
    }

    private static func minutes(_ value: String?) -> Int? {
        guard let value else { return nil }
        let parts = value.split(separator: ":").compactMap { Int($0) }
        guard parts.count == 2 else { return nil }
        return parts[0] * 60 + parts[1]
    }

    private static func hhmm(_ minutes: Int) -> String {
        String(format: "%02d:%02d", minutes / 60, minutes % 60)
    }

    private static func timeLabel(_ minutes: Int) -> String {
        let date = availabilityCalendar.date(bySettingHour: minutes / 60, minute: minutes % 60, second: 0, of: .now) ?? .now
        let formatter = DateFormatter()
        formatter.timeZone = availabilityTimeZone
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }

    private static func yyyyMMdd(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.timeZone = availabilityTimeZone
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter.string(from: date)
    }
}

enum AvailabilityEditorKind: String, CaseIterable, Identifiable {
    case weekly = "WEEKLY"
    case adHoc = "AD_HOC"

    var id: String { rawValue }
    var label: String { self == .weekly ? "Weekly" : "One-time" }
}

enum AvailabilityEditorIntent: String, CaseIterable, Identifiable {
    case cannotWork = "CANNOT_WORK"
    case prefer = "PREFER"
    case dislike = "DISLIKE"
    case timeOff = "TIME_OFF"

    var id: String { rawValue }

    var label: String {
        switch self {
        case .cannotWork: "Cannot work"
        case .prefer: "Prefer"
        case .dislike: "Avoid if possible"
        case .timeOff: "Time off"
        }
    }

    var detail: String {
        switch self {
        case .cannotWork: "Warns staff that you are unavailable during this window."
        case .prefer: "Helps staff spot shifts you would like to work."
        case .dislike: "Marks this window as less ideal without blocking assignment."
        case .timeOff: "Requests time off. Approved time off blocks pickup and trade actions."
        }
    }

    var allDayDetail: String {
        switch self {
        case .cannotWork: "Use this for travel, visitors, or any day you cannot work at all."
        case .prefer: "Marks the entire day as preferred when staff are choosing coverage."
        case .dislike: "Marks the entire day as less ideal without blocking assignment."
        case .timeOff: "Requests the entire day off for staff review."
        }
    }

    var labelPlaceholder: String {
        switch self {
        case .cannotWork: "Label (optional), e.g. CHEM 101"
        case .prefer: "Label (optional), e.g. Prefer photo shifts"
        case .dislike: "Label (optional), e.g. Lab conflict"
        case .timeOff: "Reason (optional), e.g. Family trip"
        }
    }

    var systemImage: String {
        switch self {
        case .cannotWork: "calendar.badge.exclamationmark"
        case .prefer: "checkmark.circle"
        case .dislike: "exclamationmark.triangle"
        case .timeOff: "hand.raised"
        }
    }
}

struct AvailabilityIntentMetadata {
    let label: String
    let tone: StatusTone
}

extension AvailabilityBlock {
    var normalizedKind: String { kind ?? "WEEKLY" }
    var normalizedIntent: String { intent ?? "CANNOT_WORK" }
    var normalizedStatus: String { status ?? "APPROVED" }
    var editorKind: AvailabilityEditorKind { normalizedKind == "AD_HOC" ? .adHoc : .weekly }
    var editorIntent: AvailabilityEditorIntent { AvailabilityEditorIntent(rawValue: normalizedIntent) ?? .cannotWork }

    var isHistory: Bool {
        if normalizedIntent == "TIME_OFF" && normalizedStatus == "DENIED" { return true }
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.timeZone = availabilityTimeZone
        formatter.dateFormat = "yyyy-MM-dd"
        let end = isDated ? dateEndValue : semesterEndsOn.map { String($0.prefix(10)) }
        return end.map { $0 < formatter.string(from: .now) } ?? false
    }

    var isWeekly: Bool { normalizedKind != "AD_HOC" && dayOfWeek != nil }
    var isDated: Bool { normalizedKind == "AD_HOC" || dateValue != nil }
    var isApprovedTimeOff: Bool { normalizedIntent == "TIME_OFF" && normalizedStatus == "APPROVED" }
    var isPreference: Bool { normalizedIntent == "PREFER" }

    var isAdvisory: Bool {
        normalizedIntent == "CANNOT_WORK" || normalizedIntent == "DISLIKE" ||
            (normalizedIntent == "TIME_OFF" && normalizedStatus == "PENDING")
    }

    var intentMetadata: AvailabilityIntentMetadata {
        switch normalizedIntent {
        case "PREFER": AvailabilityIntentMetadata(label: "Prefer", tone: .green)
        case "DISLIKE": AvailabilityIntentMetadata(label: "Avoid", tone: .orange)
        case "TIME_OFF": AvailabilityIntentMetadata(label: "Time off", tone: statusTone)
        default: AvailabilityIntentMetadata(label: "Cannot work", tone: .orange)
        }
    }

    var statusTone: StatusTone {
        switch normalizedStatus {
        case "APPROVED": normalizedIntent == "TIME_OFF" ? .red : .green
        case "PENDING": .orange
        default: .gray
        }
    }

    var hasCustomLabel: Bool { !(label ?? "").isEmpty }

    var primaryLine: String {
        if let label, !label.isEmpty { return label }
        return intentMetadata.label
    }

    var secondaryLine: String {
        var parts: [String] = []
        if isWeekly, let dayOfWeek { parts.append(availabilityDayNames[dayOfWeek]) }
        if let displayDateRange { parts.append(displayDateRange) }
        if normalizedAllDay {
            parts.append("All day")
        } else {
            parts.append("\(displayTime(startsAt)) to \(displayTime(endsAt))")
        }
        if let semesterLabel, !semesterLabel.isEmpty { parts.append(semesterLabel) }
        return parts.joined(separator: " · ")
    }

    var statusLine: String? {
        guard normalizedIntent == "TIME_OFF" else { return nil }
        return switch normalizedStatus {
        case "APPROVED": "Approved time off"
        case "PENDING": "Pending staff review"
        case "DENIED": "Denied"
        default: nil
        }
    }

    var dateValue: String? {
        guard let date, !date.isEmpty else { return nil }
        return date.count >= 10 ? String(date.prefix(10)) : date
    }

    var dateEndValue: String? {
        guard let dateEndsOn, !dateEndsOn.isEmpty else { return dateValue }
        return dateEndsOn.count >= 10 ? String(dateEndsOn.prefix(10)) : dateEndsOn
    }

    var normalizedAllDay: Bool { allDay == true }

    private func parsedDateValue(_ value: String?) -> Date? {
        guard let value, !value.isEmpty else { return nil }
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.timeZone = availabilityTimeZone
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter.date(from: String(value.prefix(10)))
    }

    var parsedDate: Date? {
        parsedDateValue(dateValue)
    }

    var parsedDateEndsOn: Date? {
        parsedDateValue(dateEndValue)
    }

    var parsedSemesterStart: Date? {
        parsedDateValue(semesterStartsOn)
    }

    var parsedSemesterEnd: Date? {
        parsedDateValue(semesterEndsOn)
    }

    var displayDate: String? {
        guard let parsedDate else { return dateValue }
        return formatDisplayDate(parsedDate)
    }

    var displayDateRange: String? {
        guard let parsedDate else { return dateValue }
        guard let parsedDateEndsOn,
              !availabilityCalendar.isDate(parsedDate, inSameDayAs: parsedDateEndsOn)
        else { return formatDisplayDate(parsedDate) }
        return "\(formatDisplayDate(parsedDate)) – \(formatDisplayDate(parsedDateEndsOn))"
    }

    private func formatDisplayDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.timeZone = availabilityTimeZone
        formatter.setLocalizedDateFormatFromTemplate(
            availabilityCalendar.component(.year, from: date) == availabilityCalendar.component(.year, from: .now)
                ? "EEEMMMd" : "EEEMMMdyyyy"
        )
        return formatter.string(from: date)
    }

    private func displayTime(_ value: String) -> String {
        let parts = value.split(separator: ":").compactMap { Int($0) }
        guard parts.count == 2,
              let date = availabilityCalendar.date(bySettingHour: parts[0], minute: parts[1], second: 0, of: .now)
        else { return value }
        let formatter = DateFormatter()
        formatter.timeZone = availabilityTimeZone
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }
}
