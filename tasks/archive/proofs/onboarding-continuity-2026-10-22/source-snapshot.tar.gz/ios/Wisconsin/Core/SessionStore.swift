import SwiftUI
import os

private let sessionPerformanceLog = Logger(subsystem: "com.erikrole.Wisconsin", category: "Launch")

private func elapsedMilliseconds(since start: Date) -> Int {
    Int(Date().timeIntervalSince(start) * 1_000)
}

/// A lightweight cache of the last authenticated user, stored in UserDefaults.
/// It lets the app draw the correct shell (tab bar + Home's own skeleton) on
/// the next cold launch without first blocking on the `/me` round-trip. The
/// auth **cookie** in `HTTPCookieStorage` remains the real credential and
/// source of truth; this snapshot is only a UI hint and never gates access.
/// `restoreSession()` revalidates on every launch and clears this on a
/// confirmed 401, so a revoked session bounces to Login.
private enum SessionSnapshot {
    private static let key = "WisconsinSessionSnapshot"

    static func load() -> CurrentUser? {
        guard let data = UserDefaults.standard.data(forKey: key) else { return nil }
        return try? JSONDecoder().decode(CurrentUser.self, from: data)
    }

    static func save(_ user: CurrentUser) {
        guard let data = try? JSONEncoder().encode(user) else { return }
        UserDefaults.standard.set(data, forKey: key)
    }

    static func clear() {
        UserDefaults.standard.removeObject(forKey: key)
    }
}

@MainActor
@Observable
final class SessionStore {
    var currentUser: CurrentUser?
    var isLoading = false
    var isRestoring = true
    var error: String?
    var isOffline = false
    /// A cold launch with no cached session could not reach the server, so we
    /// cannot yet say whether the stored cookie is valid. Held on the launch
    /// screen with a retry instead of guessing "signed out".
    private(set) var restoreFailed = false
    /// Neutral, non-error sign-in context (for example an expired session).
    var notice: String?
    var rolePreviewError: String?
    private(set) var isRolePreviewActionInFlight = false
    private(set) var isInitialSessionValidationInFlight = true

    /// True when this launch optimistically seeded `currentUser` from a stored
    /// snapshot, so the app shell rendered before `/me` confirmed the session.
    private var didSeedFromSnapshot = false
#if DEBUG
    private var didForceRestoreOffline = false
#endif
    private var authRequests = LatestRequestGeneration()
    private let authMutations = AuthMutationQueue()

    var usedOptimisticSessionSnapshot: Bool { didSeedFromSnapshot }

    init() {
        if AppRuntimeMode.isPerformanceTesting {
            isRestoring = false
            isInitialSessionValidationInFlight = false
        }
        // Optimistic launch: if the last session left a snapshot, render the
        // app shell immediately (Home shows its own skeleton while fresh data
        // loads) instead of blocking the entire UI on the /me round-trip. No
        // cached *content* is shown — only the shell and the device owner's own
        // identity. `restoreSession()` validates in the background and bounces
        // to Login on a confirmed 401. Users mid forced-password-change take
        // the strict path so they can't slip past that gate.
        if !AppRuntimeMode.isPerformanceTesting,
           let snapshot = SessionSnapshot.load(),
           !snapshot.forcePasswordChange, !snapshot.onboardingRequired {
            currentUser = snapshot
            isRestoring = false
            didSeedFromSnapshot = true
        }
#if DEBUG
        if ProcessInfo.processInfo.environment["GT_SHOW_SESSION_EXPIRED"] == "1" {
            notice = "Your session expired. Sign in again to continue."
        }
#endif
        if !AppRuntimeMode.isPerformanceTesting {
            let restoreToken = authRequests.begin()
            Task { await restoreSession(requestToken: restoreToken) }
        }
        // Listen for global 401s posted from APIClient and route the user back to login.
        NotificationCenter.default.addObserver(
            forName: .sessionDidExpire,
            object: nil,
            queue: .main
        ) { [weak self] notification in
            let requestBoundary = notification.object as? UUID
            Task { @MainActor in
                guard let self,
                      let requestBoundary,
                      authSessionBoundary.owns(requestBoundary),
                      self.currentUser != nil else { return }
                authSessionBoundary.advance()
                BrandAssetDownload.removeTemporaryFiles()
                self.authRequests.invalidate()
                self.isRestoring = false
                self.isInitialSessionValidationInFlight = false
                self.didSeedFromSnapshot = false
                self.currentUser = nil
                SessionSnapshot.clear()
                self.rolePreviewError = nil
                self.isRolePreviewActionInFlight = false
                self.notice = "Your session expired. Sign in again to continue."
            }
        }
        NotificationCenter.default.addObserver(
            forName: .collaboratorPolicyMayHaveChanged,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            Task { @MainActor in await self?.refreshCurrentUser() }
        }
    }

    func login(email: String, password: String) async {
        let mutation = authMutations.enqueue { [weak self] in
            guard let self else { return }
            let requestToken = self.authRequests.begin()
            self.isLoading = true
            self.error = nil
            do {
                let user = try await APIClient.shared.login(email: email, password: password)
                guard self.authRequests.owns(requestToken) else { return }
                self.didSeedFromSnapshot = false
                self.publishCurrentUserIfChanged(user)
                // Not during a forced change: that password is about to be replaced.
                if !user.forcePasswordChange {
                    Task { await Self.upgradeToPasskeyAfterSignIn(password: password) }
                }
            } catch {
                guard self.authRequests.owns(requestToken) else { return }
                self.error = error.localizedDescription
            }
            if self.authRequests.owns(requestToken) { self.isLoading = false }
        }
        await mutation.value
    }

    func register(name: String, email: String, password: String) async {
        let mutation = authMutations.enqueue { [weak self] in
            guard let self else { return }
            let requestToken = self.authRequests.begin()
            self.isLoading = true
            self.error = nil
            do {
                let user = try await APIClient.shared.register(name: name, email: email, password: password)
                guard self.authRequests.owns(requestToken) else { return }
                self.didSeedFromSnapshot = false
                self.publishCurrentUserIfChanged(user)
                Task { await Self.upgradeToPasskeyAfterSignIn(password: password) }
                self.isOffline = false
            } catch {
                guard self.authRequests.owns(requestToken) else { return }
                self.error = error.localizedDescription
            }
            if self.authRequests.owns(requestToken) { self.isLoading = false }
        }
        await mutation.value
    }

    /// After a password sign-in, asks the credential manager that filled the
    /// password (Apple Passwords, 1Password) to save a passkey for this account
    /// with no prompt. Every failure is silent: a declined upgrade, an account
    /// that already has a passkey, or a password typed by hand all leave
    /// sign-in exactly as it was. The password re-authenticates the enrollment.
    private static func upgradeToPasskeyAfterSignIn(password: String) async {
        do {
            guard let options = try await APIClient.shared.automaticPasskeyRegistrationOptions(
                currentPassword: password
            ) else { return }
            let registration = try await PasskeyService.shared.register(options: options, style: .automaticUpgrade)
            _ = try await APIClient.shared.verifyPasskeyRegistration(registration, name: nil)
        } catch {
            // Intentionally silent; see above.
        }
    }

    func loginWithPasskey() async {
        let mutation = authMutations.enqueue { [weak self] in
            guard let self else { return }
            let requestToken = self.authRequests.begin()
            self.isLoading = true
            self.error = nil
            do {
                let options = try await APIClient.shared.passkeyAuthenticationOptions()
                let assertion = try await PasskeyService.shared.authenticate(options: options)
                let user = try await APIClient.shared.verifyPasskeyAuthentication(assertion)
                guard self.authRequests.owns(requestToken) else { return }
                self.didSeedFromSnapshot = false
                self.publishCurrentUserIfChanged(user)
                self.isOffline = false
            } catch PasskeyServiceError.cancelled {
                // Dismissing the system sheet is a choice, not a failure.
            } catch {
                guard self.authRequests.owns(requestToken) else { return }
                self.error = error.localizedDescription
            }
            if self.authRequests.owns(requestToken) { self.isLoading = false }
        }
        await mutation.value
    }

    /// Arms Apple's AutoFill passkey suggestion above the keyboard while the
    /// sign-in screen is open. Deliberately passive: nothing shows as loading
    /// and no failure surfaces until a passkey is actually chosen, because most
    /// visits to this screen never touch the suggestion. Cancelling the calling
    /// task withdraws the armed request.
    func armPasskeyAutoFill() async {
        guard currentUser == nil else { return }
        do {
            let options = try await APIClient.shared.passkeyAuthenticationOptions()
            try Task.checkCancellation()
            let assertion = try await PasskeyService.shared.authenticate(
                options: options,
                presentation: .autoFill
            )
            guard !Task.isCancelled else { return }
            await completePasskeySignIn(assertion)
        } catch {
            // A withdrawn suggestion, a device without passkeys, and offline
            // arming are all routine on this path.
        }
    }

    /// Exchanges an assertion that AutoFill already produced for the shared
    /// session, on the same queue and generation guard as every other sign-in.
    private func completePasskeySignIn(_ assertion: PasskeyAssertionPayload) async {
        let mutation = authMutations.enqueue { [weak self] in
            guard let self else { return }
            let requestToken = self.authRequests.begin()
            self.isLoading = true
            self.error = nil
            do {
                let user = try await APIClient.shared.verifyPasskeyAuthentication(assertion)
                guard self.authRequests.owns(requestToken) else { return }
                self.didSeedFromSnapshot = false
                self.publishCurrentUserIfChanged(user)
                self.isOffline = false
            } catch {
                guard self.authRequests.owns(requestToken) else { return }
                self.error = error.localizedDescription
            }
            if self.authRequests.owns(requestToken) { self.isLoading = false }
        }
        await mutation.value
    }

    func completeForcedPasswordChange(currentPassword: String, newPassword: String) async {
        let mutation = authMutations.enqueue { [weak self] in
            guard let self else { return }
            let requestToken = self.authRequests.begin()
            self.isLoading = true
            self.error = nil
            do {
                try await APIClient.shared.changePassword(
                    currentPassword: currentPassword,
                    newPassword: newPassword,
                    revokeOtherSessions: true
                )
                let user = try await APIClient.shared.me()
                guard self.authRequests.owns(requestToken) else { return }
                self.didSeedFromSnapshot = false
                self.publishCurrentUserIfChanged(user)
                self.isOffline = false
            } catch {
                guard self.authRequests.owns(requestToken) else { return }
                self.error = error.localizedDescription
            }
            if self.authRequests.owns(requestToken) { self.isLoading = false }
        }
        await mutation.value
    }

    func logout() async {
        // Best-effort: a stuck server must not strand the user signed in.
        // Clear UI state before suspending, and invalidate any in-flight `/me`
        // request so it cannot repopulate the signed-out shell afterward.
        authRequests.invalidate()
        authSessionBoundary.advance()
        BrandAssetDownload.removeTemporaryFiles()
        SessionSnapshot.clear()
        didSeedFromSnapshot = false
        isInitialSessionValidationInFlight = false
        currentUser = nil
        isLoading = false
        isRestoring = false
        rolePreviewError = nil
        isRolePreviewActionInFlight = false
        PushTokenStorage.registrationAllowed = false
        let pushCleanup = pushCredentialMutations.enqueue {
            try? await APIClient.shared.revokeAllDeviceTokens()
            try? await APIClient.shared.revokeCheckoutReturnLiveActivityStartTokens()
        }
        let mutation = authMutations.enqueue {
            await pushCleanup.value
            try? await APIClient.shared.logout()
        }
        await mutation.value
    }

    func clearDeletedAccountLocally() async {
        authRequests.invalidate()
        authSessionBoundary.advance()
        BrandAssetDownload.removeTemporaryFiles()
        SessionSnapshot.clear()
        didSeedFromSnapshot = false
        isInitialSessionValidationInFlight = false
        currentUser = nil
        isLoading = false
        isRestoring = false
        rolePreviewError = nil
        isRolePreviewActionInFlight = false
        PushTokenStorage.registrationAllowed = false
        let mutation = authMutations.enqueue {
            try? await APIClient.shared.logout()
        }
        await mutation.value
    }

    /// Clear a stale auth error — call from views when the user starts typing again.
    func clearError() {
        if error != nil { error = nil }
    }

    func clearNotice() {
        if notice != nil { notice = nil }
    }

    /// Retries the blocking restore after a cold-launch network failure.
    func retryRestore() {
        guard restoreFailed else { return }
        restoreFailed = false
        isOffline = false
        isInitialSessionValidationInFlight = true
        let token = authRequests.begin()
        Task { await restoreSession(requestToken: token) }
    }

    /// Gives up on restoring and shows Login, for someone who would rather
    /// sign in than wait on a bad connection.
    func abandonRestore() {
        guard restoreFailed else { return }
        restoreFailed = false
        authRequests.invalidate()
        isInitialSessionValidationInFlight = false
        isRestoring = false
    }

    /// Starts the native Student presentation view for the underlying Admin
    /// session. The server issues the signed cookie; the following `/api/me`
    /// read publishes the effective Student shell and preview metadata.
    func startStudentRolePreview() async {
        guard currentUser?.role == "ADMIN",
              currentUser?.preview == nil,
              !isRolePreviewActionInFlight else { return }
        await mutateRolePreview(start: true)
    }

    /// Ends either a native- or web-started preview while retaining the same
    /// Admin session and identity.
    func stopRolePreview() async {
        guard currentUser?.isReadOnlyRolePreview == true,
              !isRolePreviewActionInFlight else { return }
        await mutateRolePreview(start: false)
    }

    private func mutateRolePreview(start: Bool) async {
        let mutation = authMutations.enqueue { [weak self] in
            guard let self else { return }
            let requestToken = self.authRequests.begin()
            self.isRolePreviewActionInFlight = true
            self.rolePreviewError = nil
            do {
                if start {
                    try await APIClient.shared.startStudentRolePreview()
                } else {
                    try await APIClient.shared.stopRolePreview()
                }
                let user = try await APIClient.shared.me()
                guard self.authRequests.owns(requestToken) else { return }
                self.publishCurrentUserIfChanged(user)
                self.isOffline = false
            } catch {
                guard self.authRequests.owns(requestToken) else { return }
                self.rolePreviewError = error.localizedDescription
            }
            if self.authRequests.owns(requestToken) {
                self.isRolePreviewActionInFlight = false
            }
        }
        await mutation.value
    }

    func refreshCurrentUser() async {
        guard currentUser != nil, !isInitialSessionValidationInFlight else { return }
        let requestToken = authRequests.begin()
        do {
            let user = try await APIClient.shared.me()
            guard authRequests.owns(requestToken), !Task.isCancelled else { return }
            publishCurrentUserIfChanged(user)
            isOffline = false
            error = nil
        } catch APIError.unauthorized {
            guard authRequests.owns(requestToken), !Task.isCancelled else { return }
            authSessionBoundary.advance()
            BrandAssetDownload.removeTemporaryFiles()
            authRequests.invalidate()
            SessionSnapshot.clear()
            currentUser = nil
        } catch {
            guard authRequests.owns(requestToken), !Task.isCancelled else { return }
            self.error = error.localizedDescription
        }
    }

    func applyConfirmedAvatar(_ avatarURL: String?, for userId: String) {
        guard var user = currentUser, user.id == userId else { return }
        user.avatarUrl = avatarURL
        publishCurrentUserIfChanged(user)
    }

    private func restoreSession(requestToken: UUID) async {
        let startedAt = Date()
        let signpost = AppPerformanceSignposts.begin("SessionValidation")
        let optimistic = didSeedFromSnapshot
        var result = "superseded"
        var holdForRetry = false
        defer {
            AppPerformanceSignposts.end("SessionValidation", signpost)
            isInitialSessionValidationInFlight = false
            if authRequests.owns(requestToken), !holdForRetry { isRestoring = false }
            // Distinguish the optimistic path (shell already shown) from a cold
            // blocking restore so launch timings stay comparable in Console.
            let phase = optimistic ? "launch.session.optimistic" : "launch.session.restore"
            sessionPerformanceLog.info("\(phase, privacy: .public) result=\(result, privacy: .public) durationMs=\(elapsedMilliseconds(since: startedAt), privacy: .public)")
        }
        do {
#if DEBUG
            // Review captures cannot toggle the host network per simulator.
            if ProcessInfo.processInfo.environment["GT_FORCE_RESTORE_OFFLINE"] == "1",
               !didForceRestoreOffline {
                didForceRestoreOffline = true
                try await Task.sleep(for: .seconds(1))
                throw APIError.networkError(URLError(.notConnectedToInternet))
            }
#endif
            let user = try await APIClient.shared.me()
            guard authRequests.owns(requestToken) else {
                result = "superseded"
                return
            }
            publishCurrentUserIfChanged(user)
            isOffline = false
            result = "authenticated"
        } catch APIError.unauthorized {
            guard authRequests.owns(requestToken) else {
                result = "superseded"
                return
            }
            // Confirmed revoked/expired session — drop the optimistic shell and
            // send the user to Login.
            authSessionBoundary.advance()
            BrandAssetDownload.removeTemporaryFiles()
            authRequests.invalidate()
            isRestoring = false
            isOffline = false
            SessionSnapshot.clear()
            currentUser = nil
            result = "unauthorized"
        } catch {
            guard authRequests.owns(requestToken) else {
                result = "superseded"
                return
            }
            // Network failure — don't clear session state; keep any optimistic
            // session and let the user retry.
            isOffline = true
            if currentUser == nil {
                holdForRetry = true
                restoreFailed = true
            }
            result = optimistic ? "offline-optimistic" : "offline"
        }
    }

    private func publishCurrentUserIfChanged(_ user: CurrentUser) {
        notice = nil
        if currentUser?.id != user.id {
            authSessionBoundary.advance()
            BrandAssetDownload.removeTemporaryFiles()
        }
        if currentUser != user {
            currentUser = user
        }
        SessionSnapshot.save(user)
    }
}
